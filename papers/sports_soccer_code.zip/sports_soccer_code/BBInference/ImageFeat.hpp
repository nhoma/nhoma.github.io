//
//  ImageFeat.hpp
//  BranchAndBoundCpp
//
//  Created by Namdar  on 2015-10-17.
//  Copyright © 2015 Namdar . All rights reserved.
//

#ifndef ImageFeat_hpp
#define ImageFeat_hpp

#include <stdio.h>
#include <string>
#include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"


class ImageFeat{
    // This class contains all the image features such as: lines, grass, accumulators, etc.
private:
    
    // the actual field width and height in yards
    double m_fieldWid;
    double m_fieldHeight;
    
    arma::imat m_grassAccum;
    arma::imat m_nonGrassAccum;
    
    //specifies the initial min and max value of each ray TBLR. It's an 8-dim vector
    arma::ivec m_initialTblr;
    
    //the two major orthogonal vanishing points
    arma::vec m_vpHor;
    arma::vec m_vpVer;

    // vp#Lines = the grid lines from vp#: lines ax+by+c = 0 from the # vanishing
    // point. It's and num_vp#lines x 3 matrix

    arma::mat m_vpHorLines;
    arma::mat m_vpVerLines;
    
    // the accumulators for the line pixels from each vanishing point
    arma::imat m_vpHorLinesAccum;
    arma::imat m_vpVerLinesAccum;
    
    // 3 dimensional tensor of size (y1max-y1min+1)x(y2max-y2min+1)x4
    // such that T1(i, j ,k) specifies the ray position of the kth horizontal
    // line when y1 = i and y2 = j. This corresponds to vpHor on the left
    arma::icube m_horRayPos;
    arma::imat m_horRayPosTemp;
    
    // 3 dimensional tensor of size (y3max-y3min+1)x(y4max-y4min+1)x5
    // such that T1(i, j ,k) specifies the ray position of the kth horizontal line
    // when y1 = i and y2 = j. This corresponds to vpVer on the right
    arma::icube m_verRayPos;
    arma::imat m_verRayPosTemp;
    
    // 3 dimensional tensor of size (y1max-y1min+1)x(y2max-y2min+1)x4
    // such that T1(i, j ,k) specifies the ray position of the kth horizontal
    // line when y1 = i and y2 = j. This corresponds to vpHor on the left
    arma::icube m_horRayPosEllipse;
    arma::imat m_horRayPosEllipseTemp;
    
    
    // 3 dimensional tensor of size (y3max-y3min+1)x(y4max-y4min+1)x5
    // such that T1(i, j ,k) specifies the ray position of the kth horizontal line
    // when y1 = i and y2 = j. This corresponds to vpVer on the right
    arma::icube m_verRayPosEllipse;
    arma::imat m_verRayPosEllipseTemp;
    
    // accumulator for the ellipse and circle
    arma::imat m_ellipsisAccum;
    arma::imat m_circleAccum;
    
    // Ground truth lables
    arma::ivec m_yGT;
    
    // accumulators for field and non-field
    arma::imat m_fieldAccum;
    arma::imat m_nonFieldAccum;
    
    // path to image
    std::string m_imgInfo;
    int m_gt_available;
    
public:
    
    ImageFeat();
    ImageFeat(std::string imgInfo, int gtAvailable);
    
    
    ///////////////// set methods
    
    void assignData(std::string imgInfo, int gtAvailable);
    
    // in matlab, the data are saved as raw-ascii which makes loading them very slow.
    // What we can do is to open them up one by one and save them again as arma::binary
    // this will speed up everything
    void save_as_binary(); 
    
    ///////////////// get methods
    double GetFieldWid(){return m_fieldWid;}
    double GetFieldHeight(){return m_fieldHeight;}
    arma::imat& GetGrassAccum(){ return m_grassAccum;}
    arma::imat& GetNonGrassAccum(){ return m_nonGrassAccum;}
    arma::imat& GetVpHorLinesAccum() { return m_vpHorLinesAccum;}
    arma::imat& GetVpVerLinesAccum() { return m_vpVerLinesAccum;}
    arma::icube& GetHorRayPos() { return m_horRayPos;}
    arma::icube& GetVerRayPos() { return m_verRayPos;}
    arma::ivec& GetInitialTblr(){ return m_initialTblr;}
    
    arma::imat& GetEllipsisAccum(){ return m_ellipsisAccum;}
    arma::imat& GetCircleAccum(){ return m_circleAccum;}
    arma::icube& GetHorRayPosEllipsis() { return m_horRayPosEllipse;}
    arma::icube& GetVerRayPosEllipsis() { return m_verRayPosEllipse;}
    
    arma::ivec& GetYGT(){ return m_yGT;}
    arma::imat& GetFieldAccum(){ return m_fieldAccum;}
    arma::imat& GetNonFieldAccum(){ return m_nonFieldAccum;}
    
    arma::mat& GetVerLines(){return m_vpVerLines;}
    arma::mat& GetHorLines(){return m_vpHorLines;}
    arma::vec& GetVpVer(){ return m_vpVer;}
    arma::vec& GetVpHor(){ return m_vpHor;}
    
    // extra get methods
    arma::vec GetSpecificVerLine(int rowNum);
    arma::vec GetSpecificHorLine(int rowNum);
    
    ///////////////// other methods
    
    
    
    
};




#endif /* ImageFeat_hpp */

































