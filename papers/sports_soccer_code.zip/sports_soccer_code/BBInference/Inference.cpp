//
//  main.cpp
//  BranchAndBoundCpp
//
//  Created by Namdar  on 2015-10-13.
//  Copyright (c) 2015 Namdar . All rights reserved.
//

#include <iostream>

//#include <queue>

//#include "RayIntervals.hpp"
#include "ImageFeat.hpp"
#include "BranchAndBoundInference.hpp"
//#include "Potentials.hpp"
//#include "ReadDirectory.h"

#include <string>
#include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"


/////////////////////////////////////////////////////////////////////////////


int main(int argc, char** argv)
{
    
    /*
    std::string experiment = "GLE";
    arma::vec w = {1,1,1,1,1};
    std::string data_dir("/u/namdar/soccer/data/cvpr/playing");
    arma::ivec labels;
    
    // read all the image files in the img directory. save their paths
    std::string pattern = "*.jpg";
    std::vector<std::string> fileNames;
    TraverseDirectory(data_dir, pattern, fileNames,0);
    int num_imgs = fileNames.size();

    // shuffle the filenames and set a seed
    std::mt19937 randEng;
    randEng.seed(15112016);
    std::shuffle(fileNames.begin(), fileNames.end(), randEng);


    // remove the jpg from the end of fileNames
    for(int ii=0; ii< num_imgs; ++ii){
        fileNames[ii] = fileNames[ii].substr(0,fileNames[ii].find_last_of("."));
        std::cout << fileNames[ii] << std::endl;
        ImageFeat img = ImageFeat(fileNames[ii],1);
//        labels = branchAndBoundInference(img, w, experiment,1);
        std::cout << "labeling after:" << std::endl;
        std::cout << labels << std::endl;
    }
    */
    
    
    
    
    
    std::string experiment = "GVerLHorLE1E2E3";
    //std::string imgInfo = "/ais/gobi4/namdar/soccer/data/cvpr/train_val/192_rev";
    //std::string imgInfo = "/ais/gobi4/namdar/soccer/data/cvpr/train_val/176_rev";
    std::string imgInfo = "/ais/gobi4/namdar/soccer/data/cvpr/train_val/37";
    
    std::string resultsDir("/ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GLE");
    
    
    ImageFeat img = ImageFeat(imgInfo,1);
    
    arma::ivec labels;
    
    
    //arma::vec w = {1,1,-1,-1,1};
    arma::vec w = {0.276111, 0.09824, -0.276111, -0.09824,
    0.12374, 0.0222972, 0.106648, 0.43756,
    0.148027, 0.170536, 0.0748626,
    0};
    
    w = {0.0548491, 0.0626447, -0.0548491, -0.0626447,
        0.124196, 0.168202,
        0.138542, 0.200383, 0.118772,
        0};

    w = {0.0519861, 0.0621536, -0.0519861, -0.0621536, 0.126795, 0.161731, 0.230542,
        0};
            
    w = {.0540851, 0.0640292, -0.0540851, -0.0640292,
        0.0927056, 0.050253, 0.0431862, 0.173755,
        0.0976887, 0.170192, 0.0962225,
        0};
        
    w = {0.0562332, 0.0642257, -0.0562332, -0.0642257,
            0.124655, 0.16891,
            0.109943, 0.205054, 0.100987, 
            0};        
    
    w = {   4.76725384630369e-02,
            6.55928930521835e-02,
            -4.76725384630369e-02,
            -6.55928930521835e-02,
            
            //1.96841798464257e-01,
            //3.00648115394592e-01,
            
            1,1,
            
            1.09998665259624e-01,
            2.01145387556751e-01,
            9.35651493102043e-02,
            0};
    /*
    w = {0,0,0,0,
        1,1,
        1,1,1,
        0};
    
    w = [0.0540851 0.0640292 -0.0540851 -0.0640292 0.0927056 0.050253 0.0431862 0.173755 0.0976887 0.170192 0.0962225 ]
    w = {0.0498927, 0.060597, -0.0498927, -0.060597,
        0.129063, 0.161909, ,0.240211,
        0};
        
    
        */
    
    /*
    bool status = w.load(baseDir + resultsDir + "/" + "weights.dat");
    if(status == false){
        std::cout << "ERROR!! EXITING!! either exp name wrong or experiment"
                << " not done!" << std::endl;
        exit(1);

    }
    */
    
    
    labels = branchAndBoundInference(img, w, experiment,0, imgInfo);
    std::cout << labels << std::endl;
    std::cout << "yGT: " << std::endl;
    std::cout << img.GetYGT() << std::endl;
    std::cout << "**************" << std::endl;
    //w = {1, 1, 1,0 };
    //labels = branchAndBoundInference(img, w);
    //std::cout << labels << std::endl;
    
    arma::vec verSign;
    verSign.ones(7);
    arma::vec horSign;
    horSign.ones(10);
    
    arma::ivec tblr;
    tblr = {labels(0), labels(0), labels(1), labels(1),
            labels(2),labels(2),labels(3),labels(3)};
    
    
    arma::ivec yGT;
    yGT = img.GetYGT();
    tblr = {yGT(0), yGT(0), yGT(1), yGT(1),
            yGT(2),yGT(2),yGT(3),yGT(3)};            
    
    
    Potentials pot;
    pot.SetLines(img, tblr, verSign, horSign);
    /*
    std::cout << "**************" << std::endl;
    std::cout << "Ver Lines: " << std::endl << pot.GetVerLines() << std::endl;
    std::cout << "Sum Ver Lines: " << std::endl << sum(pot.GetVerLines()) << std::endl;
    std::cout << "Hor Lines: " << std::endl<< pot.GetHorLines() << std::endl;
    std::cout << "Sum Hor Lines: " << std::endl<< sum(pot.GetHorLines()) << std::endl;
    */
    
    return 0;

}





