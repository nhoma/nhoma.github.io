//
//  RayIntervals.hpp
//  BranchAndBoundCpp
//
//  Created by Namdar  on 2015-10-17.
//  Copyright © 2015 Namdar . All rights reserved.
//

#ifndef RayIntervals_hpp
#define RayIntervals_hpp

#include <stdio.h>

#ifdef __APPLE__
#include <armadillo>
#else
#include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"
#endif


class RayIntervals{
    // This class contains a hypothesis set for the intervals in the form of an 8-dim
    // vector of TBLR and the upper bound for this hypothesis
private:
    double m_bound;
    // an 8-dimensional vector [T_min, T_max, B_min, B_max,L_min, L_max, R_min, R_max]
    arma::ivec m_tblr;
    
    // a 4-dimensional vector of the form [T_max-T_min+1, ...]. It contains the
    // number of rays for each ray in the hypothesis set
    arma::ivec m_rayLen;
    
public:
    // Constructors
    RayIntervals();
    
    RayIntervals(double newBound);
    
    RayIntervals(arma::ivec newTblr);
    
    RayIntervals(arma::ivec newTblr, double newBound);
    
    // Get methods
    double GetBound() const { return m_bound; }
    
    arma::ivec GetTblr() const { return m_tblr; }
    
    arma::ivec GetRayLen() const { return m_rayLen; }
    
    // Set Methods
    
    void SetBound(double newBound);
    
    void SetTblr(arma::ivec &newTblr);
    
    arma::ivec SetRayLen();
    
    
    
    // Other methods
    arma::uword findSplitIndex();
    
    
    // operator overloading for comparing the score of each hypothesis set
    bool operator< (const  RayIntervals&) const;
    
};






#endif /* RayIntervals_hpp */
