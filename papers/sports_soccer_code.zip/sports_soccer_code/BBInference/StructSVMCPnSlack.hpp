#ifndef StructSVMCPnSlack_hpp
#define StructSVMCPnSlack_hpp




struct InputData {
        const char* dir;
        char* InputModel;
        char* OutputModel;
        char* DataFile;
        int MaxIterations;
        int ItCounter;
        double C;
        double time;
        char* message;
        std::string resultsDir; // where the results of the experiment go
        std::string feat; // features
        std::string pattern;
        std::string data_dir;
        int num_threads;
        int fold;
};


arma::vec learnSSVM(struct InputData& inp);
//int learnSSVM(struct InputData& inp);
int ParseInput(int argc, char** argv, struct InputData &OD);

#endif /* StructSVMCPnSlack_hpp */