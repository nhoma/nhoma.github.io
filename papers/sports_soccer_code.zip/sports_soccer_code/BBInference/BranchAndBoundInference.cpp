//
//  BranchAndBoundInference.cpp
//  BranchAndBoundCpp
//
//  Created by Namdar  on 2015-10-17.
//  Copyright © 2015 Namdar . All rights reserved.
//

#include "BranchAndBoundInference.hpp"



////////////////////////////// Inference Code /////////////////////////////////

int branchAndBoundInference(ImageFeat &img, int gtAvailable){
    
    //arma::vec w = {1, 1, 1, 0};
    //std::string experiment("GLE");
    //branchAndBoundInference(img, w, experiment, gtAvailable);
    
    return 0;
    
}

arma::ivec branchAndBoundInference(ImageFeat &img, arma::vec &w, std::string &experiment, int gtAvailable, std::string imgInfo){
    
    //std::cout << imgInfo << std::endl;
    
    BBOutput output;
    output = branchAndBoundInferenceMoreInfo(img, w, experiment, gtAvailable);
        
    return output.labeling;
    
}

BBOutput branchAndBoundInferenceMoreInfo(ImageFeat &img, arma::vec &w, std::string &experiment, int gtAvailable){
    // input:
    //      w = a vector of weights for the features and the loss. If there are
    //          n features, w has size n+1. For inference the last element of w
    //          corresponding to the loss should be zero.
    // exp: specifies the features we'll use
    /* e.g.
        G : w1*grass \\ grass is grass inside and non grass
        GL : w1*grass + w2*sum(verlines + horlines)
        GLE : w1*grass + w2*sum(verlines + horlines) +w3*ellipsis
        GVerLHorL: w1*grass + w2*sum(verlines) + w3*(horlines)
        GVerLHorLE: w1*grass + w2*sum(verlines) + w3*(horlines) +w4*ellipsis
    */
        
    // output: return more info
    //      arma::ivec labeling : vector of labeling
    
    
	
	CPrecisionTimer CTmr;
	CTmr.Start();
	
    // construct an initial set of hypotheses
    RayIntervals rays = RayIntervals( img.GetInitialTblr() );
    
    
    //std::cout << rays.GetRayLen() << std::endl;
    
    // get the maximum length of the intervals for TBLR
    int maxLen = rays.GetRayLen().max();
    
    //std::cout << maxLen << std::endl;
        
    // Contains the potentials
    
    Potentials pot;

    InferenceLoss loss = InferenceLoss();

    //Initialize two RayInterval objects for the branch and bound
    RayIntervals raysOne = rays;
    RayIntervals raysTwo = rays;
    
    // two TBLR vectors used for splitting
    arma::ivec tblrOne;
    arma::ivec tblrTwo;
    
    // initilize a priorty queue
    std::priority_queue< RayIntervals> prQ;
    
    // Declare the midpoint variable
    int mid;
    
    // declare ind which corresponds to the splitting dimension
    arma::uword ind;
        
    //an intermidairy variable for bound
    double bound = 0;
    
    // iteration
    int iter = 0;
    
    
    
    //////////////////////////////// iterations
    while ( maxLen > 1 ) {
        
        
        iter = iter+1;

      
        // split along the largest coordinate
        ind = rays.findSplitIndex();
     
        tblrOne = rays.GetTblr();
        tblrTwo = tblrOne;

        if ( ind == 0) { //split T
            mid = floor( (tblrOne(0)+tblrOne(1)) / 2 );
            tblrOne(1) = mid;
            tblrTwo(0) = mid+1;
            
        }
        else if ( ind == 1 ){ // split B
            
            mid = floor( (tblrOne(2)+tblrOne(3)) / 2 );
            tblrOne(3) = mid;
            tblrTwo(2) = mid+1;
            
            
        }else if ( ind == 2 ){ // split L
            
            mid = floor( (tblrOne(4)+tblrOne(5)) / 2 );
            tblrOne(5) = mid;
            tblrTwo(4) = mid+1;
            
        }
        else if ( ind == 3 ){ // split R
            
            mid = floor( (tblrOne(6)+tblrOne(7)) / 2 );
            tblrOne(7) = mid;
            tblrTwo(6) = mid+1;
            
        }
  
        raysOne.SetTblr( tblrOne );
        raysTwo.SetTblr( tblrTwo );
        
        
        ////////// compute the bounds for each hypothesis set
        
   
        ///////////////// FIRST HYPOTHESIS SET //////////////////////////

        bound = computeBound(img, pot, tblrOne, w, loss, experiment, gtAvailable);
        
        raysOne.SetBound( bound );

        ///////////////// SECOND HYPOTHESIS SET //////////////////////////
        
        bound = computeBound(img, pot, tblrTwo, w, loss, experiment,gtAvailable);

        raysTwo.SetBound( bound );

        
        // add both hypothesis sets to the queue
        
        prQ.push(raysOne);
        prQ.push(raysTwo);
        
        // retrieve the state with the maximum score
        rays = prQ.top();
        prQ.pop();
        
        //std::cout << prQ.size() << std::endl;
        
        raysOne = rays;
        raysTwo = rays;
        

        
        maxLen = rays.GetRayLen().max();

        
    }


    //std::cout << "There number of iterations: " << iter << std::endl;
    //std::cout << " The final score is: " << std::endl << rays.GetBound() << std::endl;
    //std::cout << "The chosen states are: " << rays.GetTblr() << std::endl;
    
    arma::ivec tempLabeling = rays.GetTblr();
    tempLabeling = {tempLabeling(0),tempLabeling(2),
                    tempLabeling(4),tempLabeling(6)};
    arma::ivec labeling = arma::conv_to< arma::ivec >::from(tempLabeling);
    
    
    BBOutput output;
    
    output.energy = rays.GetBound();
    output.iterations = iter;
    output.labeling = labeling;
    output.time = CTmr.Stop();
	
    //std::cout << "energy: " << output.energy << std::endl;
    //std::cout << "iter: " << output.iterations << std::endl;
	//std::cout << "time: " << output.time << std::endl;
    //std::cout << "labeling" << output.labeling << std::endl;
	
    return output;
    
}






double computeBound(ImageFeat &img, Potentials &pot, arma::ivec &tblr, arma::vec &w,
                InferenceLoss &loss, std::string &experiment, int gtAvailable){
        
        double bound = 0;
        
        arma::vec grassSign;
        grassSign.ones(4);
        
        arma::vec verSign;
        verSign.ones(7);
        arma::vec horSign;
        horSign.ones(10);
        
        arma::vec ellipSign;
        ellipSign.ones(3);
        
        
        
        
        
        // loss for the first hypothesis
        loss.SetLoss(img, tblr, gtAvailable);

        // find the potentials depending on what type of experiment we're running
        if( experiment.compare("G") == 0){ // only grass
        	
                grassSign = { w(0), w(1), w(2), w(3) };            
                pot.SetGrass(img, tblr, grassSign);
                
                arma::vec grass;        
                grass = pot.GetGrass();
                
                bound = w(0)*grass(0) + w(1)*grass(1)+w(2)*grass(2)+w(3)*grass(3)
                
                        + w(4)*loss.GetLoss();
        }
        
        else if( experiment.compare("GL") == 0 ){ // grass + sum(verlines+horlines)
            
			grassSign = { w(0), w(1), w(2), w(3) };            
            verSign = verSign*w(4);
            horSign = horSign*w(4);
        
                
            pot.SetGrass(img, tblr, grassSign);
            pot.SetLines(img, tblr, verSign, horSign);
            
			arma::vec grass;
            grass = pot.GetGrass();
			
            bound = w(0)*grass(0) + w(1)*grass(1) + w(2)*grass(2) + w(3)*grass(3)+
                    w(4)*(sum(pot.GetVerLines())+sum(pot.GetHorLines()))+
                    w(5)*loss.GetLoss();
			/*
			m_weight = {w[0], w[1], //grass
						w[2], 1};
			*/						
					
        }        

		else if( experiment.compare("GLE") == 0 ){ // grass,sum(verlines+horlines),sum(ellipse)
			
			grassSign = { w(0), w(1), w(2), w(3) };            
            verSign = verSign*w(4);
            horSign = horSign*w(4);
            ellipSign = { w(5), w(5), w(5) };
                
            
            pot.SetGrass(img, tblr, grassSign);
            pot.SetLines(img, tblr, verSign, horSign);
            pot.SetEllipsis(img, tblr, ellipSign);
			
			arma::vec grass;
            grass = pot.GetGrass();
            
            bound = w(0)*grass(0) + w(1)*grass(1) + w(2)*grass(2) + w(3)*grass(3)+
			
                    w(4)*(sum(pot.GetVerLines())+sum(pot.GetHorLines()))+
            
			        w(5)*sum(pot.GetEllipsis())+
            
			        w(6)*loss.GetLoss();
			/*		
			m_weight = {w[0], w[1], //grass
						w[2],
						w[3],
						1}; 
			*/
			
        }
        else if( experiment.compare("GVerLHorL") == 0 ){ // grass ,sum(verlines),sum(horlines)
            
			grassSign = { w(0), w(1), w(2), w(3) };            
            verSign = verSign*w(4);
            horSign = horSign*w(5);
            
            pot.SetGrass(img, tblr, grassSign);
            pot.SetLines(img, tblr, verSign, horSign);
        
			arma::vec grass;
            grass = pot.GetGrass();
            
            bound = w(0)*grass(0) + w(1)*grass(1) + w(2)*grass(2) + w(3)*grass(3)+

                    w(4)*sum(pot.GetVerLines())+
					
					w(5)*sum(pot.GetHorLines())+

					w(6)*loss.GetLoss();
			/*					
			m_weight = {w[0], w[1],
						w[2],
						w[3],
						1};
			*/						
        }		
        else if( experiment.compare("GVerLHorLE") == 0 ){ // grass , sum(verlines), sum(horlines), sum(ellipse)
			
			grassSign = { w(0), w(1), w(2), w(3) };            
            verSign = verSign*w(4);
            horSign = horSign*w(5);
            ellipSign = { w(6), w(6), w(6) };
            
            pot.SetGrass(img, tblr, grassSign);
            pot.SetLines(img, tblr, verSign, horSign);
            pot.SetEllipsis(img, tblr, ellipSign);
        
			arma::vec grass;
            grass = pot.GetGrass();
            
            bound = w(0)*grass(0) + w(1)*grass(1) + w(2)*grass(2) + w(3)*grass(3)+
            
                    w(4)*sum(pot.GetVerLines())+
                    
					w(5)*sum(pot.GetHorLines())+
                    
					w(6)*sum(pot.GetEllipsis())+
                    
					w(7)*loss.GetLoss();
			
			/*
			m_weight = {w[0], w[1], //grass
						w[2],
						w[3],
						w[4],
						1};
			*/						
					
        }
        else if( experiment.compare("GVerLVerMVerRHorLE") == 0 ){ // grass + sum(verlines on left)
														//sum(verlines on middle)+ sum(verlines on left)
														// + sum(horlines)+sum(ellipse)
			grassSign = { w(0), w(1), -w(0), -w(1) };            
            verSign = { w(2), w(2), w(2), w(3), w(4), w(4), w(4) };
            horSign = horSign*w(5);
            ellipSign = {w(6), w(6), w(6)};
            
            pot.SetGrass(img, tblr, grassSign);
            pot.SetLines(img, tblr, verSign, horSign);
            pot.SetEllipsis(img, tblr, ellipSign);
        
            arma::vec verLines;
            
            verLines = pot.GetVerLines();
            
			arma::vec grass;
            grass = pot.GetGrass();
            
            bound = w(0)*(grass(0)-grass(2)) + w(1)*(grass(1)-grass(3)) +

                    w(2)*(verLines(0)+verLines(1)+verLines(2))+
                    w(3)*verLines(3)+
                    w(4)*(verLines(4)+verLines(5)+verLines(6))+
                    
					w(5)*sum(pot.GetHorLines())+
                    
					w(6)*sum(pot.GetEllipsis())+
                    
					w(7)*loss.GetLoss();
			
			/*		
			m_weight = {w[0], w[1], //grass
						w[2], w[3], w[4],
						w[5],
						w[6],
						1};
			*/						
        }

        else if( experiment.compare("LE") == 0 ){ // sum(verlines+horlines),sum(ellipse)

            verSign = verSign*w(0);
            horSign = horSign*w(0);
            ellipSign = {w(1), w(1), w(1)};
            
            pot.SetLines(img, tblr, verSign, horSign);
            pot.SetEllipsis(img, tblr, ellipSign);
        
            bound = w(0)*(sum(pot.GetVerLines())+sum(pot.GetHorLines()))+
                    w(1)*sum(pot.GetEllipsis())+
                    w(2)*loss.GetLoss();
        }

        else if( experiment.compare("GVerLHorLE1E2E3")  == 0 ){  // separate ellipses
			

            
			//grassSign = { w(0), w(1), -w(0), -w(1) };
            grassSign = { w(0), w(1), w(2), w(3) };            
			verSign = verSign*w(4);
            horSign = horSign*w(5);
            ellipSign = {w(6), w(7), w(8)};
            
            pot.SetGrass(img, tblr, grassSign);
            pot.SetLines(img, tblr, verSign, horSign);
            pot.SetEllipsis(img, tblr, ellipSign);
        
        
            arma::vec ellip;
            
            ellip = pot.GetEllipsis();
        
			arma::vec grass;
            grass = pot.GetGrass();
            
            //bound = w(0)*(grass(0)-grass(2)) + w(1)*(grass(1)-grass(3)) +
            bound = w(0)*grass(0) + w(1)*grass(1) + w(2)*grass(2) + w(3)*grass(3)+
                    w(4)*sum(pot.GetVerLines())+
        
		            w(5)*sum(pot.GetHorLines())+
        
		            w(6)*ellip(0)+
                    w(7)*ellip(1)+
                    w(8)*ellip(2)+
        
		            w(9)*loss.GetLoss();

			/*
			m_weight = {w[0], w[1], //grass
						w[2],
						w[3],
						w[4],w[5], w[6],
						1}; 
			*/										
					
		}
        
        else if( experiment.compare("GVerLVerMVerRHorLE1E2E3") == 0 ){ // grass + sum(verlines on left)
														//sum(verlines on middle)+ sum(verlines on left)
														// + sum(horlines)+different ellipses
            
            grassSign = { w(0), w(1), w(2), w(3) };            
            verSign = {w(4), w(4),w(4), w(5), w(6),w(6),w(6)};
            horSign = horSign*w(7);
            ellipSign = {w(8), w(9), w(10)};
            
            pot.SetGrass(img, tblr, grassSign);
            pot.SetLines(img, tblr, verSign, horSign);
            pot.SetEllipsis(img, tblr, ellipSign);
        
            arma::vec verLines;
            verLines = pot.GetVerLines();
            arma::vec ellip;
            ellip = pot.GetEllipsis();
            arma::vec grass;
            grass = pot.GetGrass();
            
            bound = w(0)*grass(0) + w(1)*grass(1) + w(2)*grass(2) + w(3)*grass(3)+
                    
					w(4)*(verLines(0)+verLines(1)+verLines(2))+
					w(5)*verLines(3)+
					w(6)*(verLines(4)+verLines(5)+verLines(6))+
                    
					w(7)*sum(pot.GetHorLines())+
                    
					w(8)*ellip(0)+
                    w(9)*ellip(1)+
                    w(10)*ellip(2)+
                    
					w(11)*loss.GetLoss();
					
			/*					
			m_weight = {w[0], w[1], //grass
						w[2], w[3], w[4], //verL verM verR
						w[5], // horL
						w[6], w[7], w[8], // Ellipse
						 1};  					
			*/
    
        }
        else if( experiment.compare("GVerAllHorLE1E2E3") == 0 ){ // grass + sum(verlines on left)
														//sum(verlines on middle)+ sum(verlines on left)
														// + sum(horlines)+different ellipses
            
            grassSign = { w(0), w(1), -w(0), -w(1) };            
            verSign = {w(2), w(3),w(4), w(5), w(6),w(7),w(8)};
            horSign = horSign*w(9);
            ellipSign = {w(10), w(11), w(12)};
            
            pot.SetGrass(img, tblr, grassSign);
            pot.SetLines(img, tblr, verSign, horSign);
            pot.SetEllipsis(img, tblr, ellipSign);
        
            arma::vec verLines;
            verLines = pot.GetVerLines();
            arma::vec ellip;
            ellip = pot.GetEllipsis();
            arma::vec grass;
            grass = pot.GetGrass();
            
            bound = w(0)*(grass(0)-grass(2)) + w(1)*(grass(1)-grass(3)) +
            //bound = w(0)*grass(0) + w(1)*grass(1) +
                    w(2)*verLines(0)+
                    w(3)*verLines(1)+
                    w(4)*verLines(2)+
                    w(5)*verLines(3)+
                    w(6)*verLines(4)+
                    w(7)*verLines(5)+
                    w(8)*verLines(6)+

                    w(9)*sum(pot.GetHorLines())+
                    
					w(10)*ellip(0)+
                    w(11)*ellip(1)+
                    w(12)*ellip(2)+
                    
					w(13)*loss.GetLoss();

			/*					
			m_weight = {w[0], w[1], //grass
						w[2],w[3], w[4], w[5], w[6], w[7], w[8], // VerAll
						w[9], // HorL
						w[10], w[11], w[12], //ellipses
						1};  
			*/		    
    
        }
        else if( experiment.compare("GVerSymHorLESym") == 0 ){ // grass + sum(verlines on left)
														//sum(verlines on middle)+ sum(verlines on left)
														// + sum(horlines)+different ellipses
            
            grassSign = { w(0), w(1), -w(0), -w(1) };            
            verSign = {w(2), w(3),w(4), w(5), w(4),w(3),w(2)};
            horSign = horSign*w(6);
            ellipSign = {w(7), w(8), w(7)};
            
            pot.SetGrass(img, tblr, grassSign);
            pot.SetLines(img, tblr, verSign, horSign);
            pot.SetEllipsis(img, tblr, ellipSign);
        
            arma::vec verLines;
            verLines = pot.GetVerLines();
            arma::vec ellip;
            ellip = pot.GetEllipsis();
            arma::vec grass;
            grass = pot.GetGrass();
            
            bound = w(0)*(grass(0)-grass(2)) + w(1)*(grass(1)-grass(3)) +

                    w(2)*( verLines(0)+ verLines(6) ) +
                    w(3)*( verLines(1) + verLines(5) ) + 
                    w(4)*( verLines(2) + verLines(4) ) + 
                    w(5)*verLines(3)+
                    

                    w(6)*sum(pot.GetHorLines())+
                    w(7)*( ellip(0)+ellip(2) )+
                    w(8)*ellip(1)+
                    w(9)*loss.GetLoss();
		
			/*
			m_weight = {w[0], w[1], //grass
						w[2],w[3], w[4], w[5], //  symmetric ver
						w[6], // HorL
						w[7], w[8], //ellipses
						1};
			*/						
    
        }
        else if( experiment.compare("GVerSymHorSymESym") == 0 ){ // grass + sum(verlines on left)
														//sum(verlines on middle)+ sum(verlines on left)
														// + sum(horlines)+different ellipses
            
            grassSign = { w(0), w(1), -w(0), -w(1) };            
            verSign = {w(2), w(3),w(4), w(5), w(4),w(3),w(2)};
            horSign = {w(6), w(7), w(8), w(9), w(10), w(7), w(8), w(9), w(10), w(11)};
            ellipSign = {w(12), w(13), w(12)};
            
            pot.SetGrass(img, tblr, grassSign);
            pot.SetLines(img, tblr, verSign, horSign);
            pot.SetEllipsis(img, tblr, ellipSign);
        
            arma::vec verLines;
            verLines = pot.GetVerLines();
            arma::vec horLines;
            horLines = pot.GetHorLines();
            arma::vec ellip;
            ellip = pot.GetEllipsis();
            arma::vec grass;
            grass = pot.GetGrass();
            
            bound = w(0)*(grass(0)-grass(2)) + w(1)*(grass(1)-grass(3)) +

                    w(2)*( verLines(0)+ verLines(6) ) +
                    w(3)*( verLines(1) + verLines(5) ) + 
                    w(4)*( verLines(2) + verLines(4) ) + 
                    w(5)*verLines(3)+
                    
                    w(6)*horLines(0)+
                    w(7)*( horLines(1) + horLines(5) )+
                    w(8)*( horLines(2) + horLines(6) )+
                    w(9)*( horLines(3) + horLines(7) )+
                    w(10)*( horLines(4) + horLines(8) )+
                    w(11)* horLines(9) +
			        
                    w(12)*( ellip(0)+ellip(2) )+
                    w(13)*ellip(1)+
                    w(14)*loss.GetLoss();
			
			/*
			m_weight = {w[0], w[1],  //grass
						w[2],w[3], w[4], w[5], //  symmetric ver
						w[6], w[7], w[8], w[9], w[10], w[11], // symmetric Hor
						w[12], w[13], // symm ellipses
						1};  
			*/
        }
        else if( experiment.compare("GVerAllHorAllEAll") == 0 ){ 
            
            grassSign = { w(0), w(1), -w(0), -w(1) };            
            verSign = {w(2), w(3),w(4), w(5), w(6),w(7),w(8)};
            horSign = {w(9), w(10), w(11), w(12), w(13), w(14), w(15), w(16), w(17), w(18)};
            ellipSign = {w(19), w(20), w(21)};
            
            pot.SetGrass(img, tblr, grassSign);
            pot.SetLines(img, tblr, verSign, horSign);
            pot.SetEllipsis(img, tblr, ellipSign);
        
            arma::vec verLines;
            verLines = pot.GetVerLines();
            arma::vec horLines;
            horLines = pot.GetHorLines();
            arma::vec ellip;
            ellip = pot.GetEllipsis();
            arma::vec grass;
            grass = pot.GetGrass();
            
            bound = w(0)*(grass(0)-grass(2)) + w(1)*(grass(1)-grass(3)) +

					w(2)*verLines(0) +
					w(3)*verLines(1) +
					w(4)*verLines(2) +
					w(5)*verLines(3) +
					w(6)*verLines(4) +
					w(7)*verLines(5) +
					w(8)*verLines(6) +
					
					w(9)*horLines(0) +
					w(10)*horLines(1) +
					w(11)*horLines(2) +
					w(12)*horLines(3) +
					w(13)*horLines(4) +
					w(14)*horLines(5) +
					w(15)*horLines(6) +
					w(16)*horLines(7) +
					w(17)*horLines(8) +
					w(18)*horLines(9) +
			
                    
                    w(19)*ellip(0) +
					w(20)*ellip(1) +
					w(21)*ellip(2) +
                    
					w(22)*loss.GetLoss();
			
			/*
			m_weight = {w[0], w[1], //grass
						w[2],w[3], w[4], w[5], w[6], w[7], w[8], 
						w[9], w[10], w[11], w[12], w[13], w[14], w[15], w[16], w[17], w[18], 
						w[19], w[20], w[21], 
						1};
			*/						
    
        }
		else if( experiment.compare("GVerLHorLEInteraction") == 0 ){ 
			
			grassSign = { w(0), w(1), -w(0), -w(1) };            
            verSign = verSign*w(2);
            horSign = horSign*w(3);
            ellipSign = { w(4), w(4), w(4) };
            
            pot.SetGrass(img, tblr, grassSign);
            pot.SetLines(img, tblr, verSign, horSign);
            pot.SetEllipsis(img, tblr, ellipSign);
        
			arma::vec grass;
            grass = pot.GetGrass();
            
			arma::vec verLines;
            verLines = pot.GetVerLines();
            
			arma::vec horLines;
            horLines = pot.GetHorLines();
            
			arma::vec ellip;
            ellip = pot.GetEllipsis();
            
			
			// some extra definitions and computations for the interactions
			arma::vec verSign2;
			verSign2.ones(7);
			verSign2(2) = w(5);
			verSign2(3) = w(6);
			verSign2(4) = w(7);
			
	        arma::vec ellipSign2;
	        ellipSign2 = {w(5), w(6), w(7)};
			
			pot.SetLines(img, tblr, verSign2, horSign);
            pot.SetEllipsis(img, tblr, ellipSign2);
			
			arma::vec verLines2;
            verLines2 = pot.GetVerLines();
			
			arma::vec ellip2;
            ellip2 = pot.GetEllipsis();
            
			//
			
			
			
            bound = w(0)*(grass(0)-grass(2)) + w(1)*(grass(1)-grass(3)) +
            
                    w(2)*sum(verLines)+
                    
					w(3)*sum(horLines)+
                    
					w(4)*sum(ellip)+
                    
					w(5)*ellip2(0)*verLines2(2) +
					w(6)*ellip2(1)*verLines2(3) +
					w(7)*ellip2(2)*verLines2(4) +
					
					w(8)*loss.GetLoss();
			
			/*
			m_weight = {w[0], w[1], //grass
						w[2], // verL
						w[3], // horL
						w[4], //E
						w[5],
						w[6],
						w[7],
						1}; 
			*/						
					
        }

		
		
    
        return bound;
        
}




