./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/G -e G
./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GL -e GL
./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/LE -e LE
./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GLE -e GLE
./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GVerLHorL -e GVerLHorL
./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GVerLHorLE -e GVerLHorLE
./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GVerLHorLE1E2E3 -e GVerLHorLE1E2E3
./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GVerSymHorSymESym -e GVerSymHorSymESym
./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GVerAllHorLE1E2E3 -e GVerAllHorLE1E2E3
./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GVerSymHorLESym -e  GVerSymHorLESym
./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GVerLVerMVerRHorLE -e GVerLVerMVerRHorLE
./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GVerAllHorAllEAll -e GVerAllHorAllEAll


