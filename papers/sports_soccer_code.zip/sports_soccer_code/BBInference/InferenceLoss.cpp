#include "InferenceLoss.hpp"


void InferenceLoss::SetLoss(ImageFeat &img, arma::ivec &tblr, int gtAvailable){
        
    if(gtAvailable == 0){
    
        m_loss = 0;
    
    }
    else{   
        // create references matrices for field and non-field accumulators
        const arma::imat &fieldAccum = img.GetFieldAccum();
        const arma::imat &nonFieldAccum = img.GetNonFieldAccum();


        // Total number of lines from each vanishing point which is the same as the
        // number of rows and cols of the accumulators
        int nRow = fieldAccum.n_rows;
        int nCol = fieldAccum.n_cols;
    
    
    
        // get total number of field pixels and non-field pixels
        int fieldTotal = fieldAccum(nRow - 1, nCol - 1);
        int nonFieldTotal = nonFieldAccum(nRow - 1, nCol - 1);
        int N = fieldTotal + nonFieldTotal;
    
        double fieldInside = accumLookUp(fieldAccum, tblr(1), tblr(2),
                                      tblr(5), tblr(6));
        double nonFieldOutside = nonFieldTotal - accumLookUp(nonFieldAccum, tblr(0),
                                                tblr(3), tblr(4), tblr(7));

        //m_loss = 1 - (fieldInside + nonFieldOutside)/N;
        m_loss = 2 - double(fieldInside)/fieldTotal - double(nonFieldOutside)/nonFieldTotal;
    }
    
    //std::cout << "loss: " << m_loss << std::endl;
    
}