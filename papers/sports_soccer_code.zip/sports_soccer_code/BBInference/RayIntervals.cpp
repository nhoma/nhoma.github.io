//
//  RayIntervals.cpp
//  BranchAndBoundCpp
//
//  Created by Namdar  on 2015-10-17.
//  Copyright © 2015 Namdar . All rights reserved.
//

#include "RayIntervals.hpp"

///////////////////////// Constructors /////////////////////////

RayIntervals::RayIntervals(){
    m_bound = 0;
    m_tblr.zeros();
    m_rayLen = SetRayLen();
}

RayIntervals::RayIntervals(double newBound){
    m_bound = newBound;
    m_tblr.zeros();
    m_rayLen = SetRayLen();
    
}

RayIntervals::RayIntervals(arma::ivec newTblr){
    m_bound = 0;
    m_tblr = newTblr;
    m_rayLen = SetRayLen();
    
}


RayIntervals::RayIntervals(arma::ivec newTblr, double newBound){
    m_bound = newBound;
    m_tblr = newTblr;
    m_rayLen = SetRayLen();
}





///////////////////////// Set Methods //////////////////////////

void RayIntervals::SetBound(double newBound){
    m_bound = newBound;
}

void RayIntervals::SetTblr(arma::ivec &newTblr){
    // set new TBLR vector and compute the length along each ray dimension
    m_tblr = newTblr;
    m_rayLen = SetRayLen();
    
}

arma::ivec RayIntervals::SetRayLen(){
    // set ray lenghts
    
    arma::ivec rayLen;
    rayLen.zeros(4);
    
    rayLen(0) = m_tblr(1) - m_tblr(0)+1;
    rayLen(1) = m_tblr(3) - m_tblr(2)+1;
    rayLen(2) = m_tblr(5) - m_tblr(4)+1;
    rayLen(3) = m_tblr(7) - m_tblr(6)+1;
    
    return rayLen;
}


//////////////////////// Other methods ////////////////////////////

arma::uword RayIntervals::findSplitIndex(){
    // find the direction among T, B, L, R in which we do a branch.
    // 0 -> T, 1 -> B, 2 -> L, 3 -> R
    arma::uword ind;
    GetRayLen().max(ind); // this changes ind (armadillo)
    return ind;
}

////////////////////// Operator Overloading for Queue ///////////////

// operator overloading for comparing the score of each hypothesis set
bool RayIntervals::operator< (const RayIntervals &rhs) const {
    // Used for comparing the upper bounds of the hypotheis set in the priority queue
    return m_bound < rhs.m_bound;
}
