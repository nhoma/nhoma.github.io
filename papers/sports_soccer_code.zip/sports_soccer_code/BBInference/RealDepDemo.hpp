#ifndef RealDepDemo_hpp
#define RealDepDemo_hpp

#include <iostream>
#include <stdio.h>
#include "ImageFeat.hpp"
#include "BranchAndBoundInference.hpp"
#include <string>
#include <algorithm>
#include <dirent.h>
#include <fnmatch.h>
#include <vector>
#include <fstream>

#include "/u/namdar/soccer/Code/External/armadillo-6.200.3/include/armadillo"

void RealDepDemo(std::string resultsDir, std::string imgDir);
void TraverseDirectory(const std::string& path, std::string& pattern, std::vector<std::string>& fileNames);

#endif /* RealDepDemo_hpp */