#include <iostream>
#include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"


// g++ test2.cpp ImageFeat.cpp ReadDirectory.cpp -o test2 -std=c++11 -Wall -I /u/namdar/soccer/Code/External/armadillo-7.400.4/include/ -lblas -llapack -fopenmp

#include <stdio.h>
#include<fstream>
#include<string.h>
#include <vector>
#include "ImageFeat.hpp"
#include "ReadDirectory.hpp"

int main( int argc, const char** argv )
{
    
     //ImageFeat img = ImageFeat("/ais/gobi4/namdar/soccer/data/cvpr/train_val/141",1);
     //img.save_as_binary();
     
     int a = 2;
     int b = 3;
     double c;
     c = a/double(b);
     std::cout << c << std::endl;
          
     return 0;
}





