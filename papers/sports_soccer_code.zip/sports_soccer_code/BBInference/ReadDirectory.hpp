#ifndef ReadDirectory_hpp
#define ReadDirectory_hpp

#include <iostream>
#include <string>
#include <vector>
#include <dirent.h>
#include <fnmatch.h>
void TraverseDirectory(const std::string& path, const std::string& pattern,
						std::vector<std::string>& fileNames,
						bool printFilenames);

#endif /* ReadDirectory_hpp */