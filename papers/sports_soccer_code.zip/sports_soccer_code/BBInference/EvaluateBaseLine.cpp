#include "EvaluateBaseLine.hpp"






EvalOutput evaluate(std::string data_dir, std::string pattern,  int gtAvailable){

// read all the image files in the img directory. save their paths

std::vector<std::string> fileNames;
TraverseDirectory(data_dir, "*."+pattern, fileNames,1);
int num_imgs = fileNames.size();

// remove the valX from the end of fileNames
for(int ii=0; ii< num_imgs; ++ii){
    fileNames[ii] = fileNames[ii].substr(0,fileNames[ii].find_last_of("."));
    //std::cout << fileNames[ii] << std::endl;
}





// output of evaluation
EvalOutput eval_output;
eval_output.mean_iou = 0;
eval_output.med_iou = 0;
//eval_output.iou_visible.set_size(num_imgs);
eval_output.filenames = fileNames;





// create four vectors that will contain the TBLR lines. Each vector will be of
// the form [a;b;c] corresponding to ax+by+c = 0

arma::vec TL; // top left point
arma::vec TR; // top right point
arma::vec BR; // bottom right point
arma::vec BL; // bottom right point


arma::mat H; // homography matrix

              
// a vector containing the IOUs for all the images               
arma::vec IOU(num_imgs);
//arma::vec IOU_visible(num_imgs);

                                
// initialize the image info which will be used to read the image features
std::string imgInfo;

// holds all the predictions and gts for the images                              


std::string imgName;


arma::mat corners;

// we have annotated gt or not
//int gtAvailable = 0; 
                                
for(int ii = 0; ii < num_imgs; ++ii){
        
        std::cout << "Image :" << ii+1 << "/" << num_imgs << std::endl;
        std::cout << "Pattern :" << pattern << std::endl;
        
        
  
        // the path to an image  
        imgInfo = fileNames[ii];
      
                                                
        if(gtAvailable == 1){

                
                // now find the intersection points.
                // a rectangle can be specified by two x coordinate values and 2 y
                // cooridinate values
                
                corners.load(imgInfo+"."+pattern);
                
                TL = arma::conv_to<arma::vec>::from(corners.row(0));
                TR = arma::conv_to<arma::vec>::from(corners.row(1));
                BR = arma::conv_to<arma::vec>::from(corners.row(2));
                BL = arma::conv_to<arma::vec>::from(corners.row(3));
                
                
                TL = TL/TL(2);
                TR = TR/TR(2);
                BR = BR/BR(2);
                BL = BL/BL(2);
                
                                                
                // load the homography matrix
                H.load(imgInfo+".homographyMatrix");
                //H_inv.load(imgInfo+".invHomographyMatrix");
                
                                            
                // intersection over union metric        
                IOU(ii) = unionIntersectionMetric(TL, TR, BR, BL, H);
                std::cout << "IOU" << std::endl;
                std::cout << IOU(ii) << std::endl;                
                

        }        
        
        
}


if(gtAvailable == 1){
        

        
        //arma::vec mean_iou(1); // used for writing to file
        
        // find mean IOU
        eval_output.mean_iou = arma::mean(IOU);
        std::cout <<  "Mean Interesction over Union = " << eval_output.mean_iou <<  std::endl;
        eval_output.med_iou = arma::median(IOU);
        std::cout <<  "Median Interesction over Union = " << eval_output.med_iou <<  std::endl;
        
        //eval_output.iou_visible = IOU_visible;        
        // find mean IOU
        //eval_output.mean_iou_visible = arma::mean(IOU_visible);
        //std::cout <<  "Mean Interesction over Union Visible = " << eval_output.mean_iou_visible <<  std::endl;
        
        //arma::vec med_iou(1); // used for writing to file
        //eval_output.med_iou_visible = arma::median(IOU_visible);
        //std::cout <<  "Median Interesction over Union Visible = " << eval_output.med_iou_visible <<  std::endl;

                
}



return eval_output;

}

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
using namespace ClipperLib;

void addPoint(int x, int y, Path *path)
{
    IntPoint ip;
    ip.X = x;
    ip.Y = y;
    path->push_back(ip);
}



double unionIntersectionMetric(arma::vec TL, arma::vec TR, arma::vec BR, arma::vec BL, arma::mat H){
// this function computes the intersection/union of a test image
// rect:corresponds to x1,x2,y1,y2 which
// are the coordinates defining the rectangle of the projected field

double score = 0;
double inter; //area of intersection
double uni; // area of union

//model cooridinates
double x1 = 0;
double x2 = 114.83;
double y1 = 0;
double y2 = 74.37;


// find the projection of these points on the model field. reassign them
// TL and BR
TL = H*TL;
TR = H*TR;                
BR = H*BR;
BL = H*BL;

// normalize the projected points
TL = TL/TL(2);
TR = TR/TR(2);
BR = BR/BR(2);
BL = BL/BL(2);


Paths truth;

Path p;
addPoint(x1, y1, &p);
addPoint(x2, y1, &p);
addPoint(x2, y2, &p);
addPoint(x1, y2, &p);
addPoint(x1, y1, &p);
truth.push_back(p);


Paths proj;

Path p2;
addPoint(TL(0), TL(1), &p2);
addPoint(TR(0), TR(1), &p2);
addPoint(BR(0), BR(1), &p2);
addPoint(BL(0), BL(1), &p2);
addPoint(TL(0), TL(1), &p2);
proj.push_back(p2);

Clipper c;

c.AddPaths(truth, ptSubject, true);
c.AddPaths(proj, ptClip, true);

Paths inter_path;
Paths uni_path;
c.Execute(ctIntersection, inter_path, pftNonZero, pftNonZero);
c.Execute(ctUnion, uni_path, pftNonZero, pftNonZero);

inter = Area(inter_path.at(0));
uni = Area(uni_path.at(0));
//std::cout << inter << std::endl;


//std::cout << uni << std::endl;

score = inter/uni;

return score;

}




