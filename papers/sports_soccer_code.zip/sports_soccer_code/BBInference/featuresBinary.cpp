// This function reads the raw ascii data produced by matlab and saves them as
// binary for fast retrieval later in learning an inference

#include <iostream>
#include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"


// g++ featuresBinary.cpp ImageFeat.cpp ReadDirectory.cpp -o featuresBinary -std=c++11 -Wall -I /u/namdar/soccer/Code/External/armadillo-7.400.4/include/ -lblas -llapack -fopenmp

#include <stdio.h>
#include<fstream>
#include<string.h>
#include <vector>
#include "ImageFeat.hpp"
#include "ReadDirectory.hpp"

int main( int argc, const char** argv )
{
    
    std::string train_dir("/u/namdar/soccer/data/cvpr/train_val");
    std::string test_dir("/u/namdar/soccer/data/cvpr/test");
    
    
    // read all the image files in the img directory. save their paths
    std::string pattern = "*.jpg";
    std::vector<std::string> train_fileNames;
    TraverseDirectory(train_dir, pattern, train_fileNames,0);
    int num_train_imgs = train_fileNames.size();

    std::vector<std::string> test_fileNames;
    TraverseDirectory(test_dir, pattern, test_fileNames,0);
    int num_test_imgs = test_fileNames.size();
    
         
    for(int ii=0; ii< num_train_imgs; ++ii){
        train_fileNames[ii] = train_fileNames[ii].substr(0,train_fileNames[ii].find_last_of("."));
        std::cout << train_fileNames[ii] << std::endl;
        ImageFeat img = ImageFeat(train_fileNames[ii],1);
        img.save_as_binary();        
    }
    
        for(int ii=0; ii< num_test_imgs; ++ii){
        test_fileNames[ii] = test_fileNames[ii].substr(0,test_fileNames[ii].find_last_of("."));
        std::cout << test_fileNames[ii] << std::endl;
        ImageFeat img = ImageFeat(test_fileNames[ii],1);
        img.save_as_binary();        
    }
    
     

          
     return 0;
}