#ifndef InferenceLoss_hpp
#define InferenceLoss_hpp

#include <stdio.h>
#include "PotentialsHelpFunctions.hpp"
#include "ImageFeat.hpp"

#ifdef __APPLE__
#include <armadillo>
#else
#include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"
#endif



class InferenceLoss{
private:
    double m_loss;
public:
    InferenceLoss(){};
    
    double GetLoss() const { return m_loss; }
    // compute an upper bound for the loss function
    void SetLoss(ImageFeat &img, arma::ivec &tblr , int gtAvailable);
    

};

#endif /* InferenceLoss_hpp */