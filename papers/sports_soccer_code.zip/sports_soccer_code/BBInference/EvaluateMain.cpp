#include "Evaluate.hpp"


int main(int argc, char** argv) {

//-r : where the required info are and results will be stored
//-i : where te images and features are
    
    
std::string data_dir("/u/namdar/soccer/data/cvpr/train_val");
std::string resultsDir("/u/namdar/soccer/data/cvpr/hockey_results/eval_test2");
EvalOutput eval_out;

arma::vec w;
w = {   2.49936194896130e-02,
   6.17021957664645e-02,
  -2.49936194896130e-02,
  -6.17021957664645e-02,
   3.60365523159768e-01,
   2.51866114171625e-01,
   0};    


        
eval_out = evaluate(data_dir, w, "GLE", "*.jpg",  1);


/*
eval_out.energy.save(resultsDir + "/" + "train_energy.dat", arma::raw_ascii);
eval_out.iterations.save(resultsDir + "/" + "train_iterations.dat", arma::raw_ascii);
eval_out.time.save(resultsDir + "/" + "train_time.dat", arma::raw_ascii);
eval_out.iou.save(resultsDir + "/" + "train_iou.dat", arma::raw_ascii);
eval_out.preds.save(resultsDir + "/" + "train_preds.dat", arma::raw_ascii);

// save the img names in the order they appear

std::ofstream fid2;
fid2.open(resultsDir + "/" + "train_fileNames.txt");
for(int ii=0; ii<eval_out.filenames.size(); ii++){
        fid2 << eval_out.filenames[ii] << std::endl;
}
fid2.close();
*/

return 0;

}