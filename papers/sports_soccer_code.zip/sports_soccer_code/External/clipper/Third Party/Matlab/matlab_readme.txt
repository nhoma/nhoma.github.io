To compile your own mexfile run the command:

mex clipper.cpp mexclipper.cpp
