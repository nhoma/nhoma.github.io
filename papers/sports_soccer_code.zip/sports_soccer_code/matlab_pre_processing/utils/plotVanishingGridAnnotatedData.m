function plotVanishingGridAnnotatedData(horLines, verLines,doPause, im,...
    col, style, l_size)
    
    
    
    if ~isempty(im)
        %figure;
        axis ij;
        %im = imread('images/sample4.jpg');
    
        imagesc(im)
        xlim([-5000,5000]);
        ylim([-100,1000])
    end
        
    hold on;
    
    %rectangle('Position', [0,0,wid,h], 'LineWidth', 3, 'EdgeColor','k')
    
    %L = vp1_lines([1,100],:); % inefficient, change it
    L = horLines; % inefficient, change it
    for i = 1:size(L,1)
        
        if doPause == 1
            pause
        end
        x=  linspace(-5000, 5000,500);
        y = -L(i,1)/L(i,2)*x - L(i,3)/L(i,2);
        plot(x,y,col, 'LineWidth', l_size, 'LineStyle', style);
        
        
    end
    
    
    
    %L = vp2_lines([1,100],:); % inefficient, change it
    L = verLines; % inefficient, change it
    for i = 1:size(L,1)
        
        if doPause == 1
            pause
        end
        y=  linspace(-100, 1000,400);
        x = -L(i,2)/L(i,1)*y - L(i,3)/L(i,1);
        plot(x,y, col, 'LineWidth', l_size, 'LineStyle', style);
        
        
    end
    


end

