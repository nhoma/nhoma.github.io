function plotFieldHomography(yy1, yy2, yy3, yy4, vpHorLines, vpVerLines, im)

field_wid = 114.83;
field_h = 74.37;

L_top = vpHorLines(yy1,:);
L_bottom = vpHorLines(yy2,:);
L_left = vpVerLines(yy3,:);
L_right = vpVerLines(yy4,:);


% get the structure of the model field
s = getFieldStruct(0, field_wid, field_h);

% corners have the format top-left, top-right, bottom-right, bottom-left
corners_field = cross([L_top; L_top; L_bottom; L_bottom], [L_left; L_right;...
    L_right; L_left]);
corners_field = hnormalise(corners_field);
corners_field = corners_field(:,1:2);


% corners from the model. Rows 8 and 17 correspond to the upper and lower
% sidelines
corners_model = [s.points(8,1),s.points(8,3);...
    s.points(8,2),s.points(8,4);...
    s.points(17,2),s.points(17,4);...
    s.points(17,1),s.points(17,3)];


% create a transformation matrix
tform = fitgeotrans(corners_field, corners_model, 'Projective');



%%% Find predicted line segments from the intersection of the rays in the image

ver_lines = [L_left; L_right];



hor_lines = [L_top; L_bottom];


%points.image = findImagePredictedLineSegments(ver_lines, hor_lines);
points.image = [corners_field, ones(size(corners_field,1),1)];


%%% apply a homography to the image points

points.transformed = tform.T'* points.image';
points.transformed = hnormalise(points.transformed');

% convert the transformed points into a plottable format
points.transformed = changePointsFormat(points.transformed);

%%%
xWorldLimits = [-10,field_wid+10];
yWorldLimits = [-10,field_h+10];


R = imref2d([720, 1280], xWorldLimits, yWorldLimits);

[B, BI] = imwarp(im, tform, 'cubic','OutputView',R, 'FillValues', 255);

figure;
imshow(B, BI)

xlim([-10, field_wid+10])
ylim([-10, field_h+10])

col = 'b';
style = ':';
l_size = 5;
plotField(s.points, col, style, l_size)