function P = changePointsFormat(P)
% this funtion changes the points fomat from [x1 y1;x2 y2] to the format [x1 x2 y1 y2]

[nrows, ~] = size(P);

P = [P(1:2:nrows-1,1), P(2:2:nrows,1), P(1:2:nrows-1,2), P(2:2:nrows,2)];


end