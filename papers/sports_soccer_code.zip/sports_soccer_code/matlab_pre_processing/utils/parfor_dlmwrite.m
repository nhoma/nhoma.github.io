function parfor_dlmwrite(data_dir, split, im_name,...
            vpVer, vpHor, A_grass, A_non_grass, vpHorLines, vpVerLines, ...
            A_hor_lines, A_ver_lines, Y, T_hor, T_ver, TE1, TE2, ...
            A_ellipse, A_circle, y_gt, fieldAccum, nonFieldAccum, H)

disp('Saving')
vpVer = vpVer';
vpHor = vpHor';
dlmwrite([data_dir, split,filesep, im_name,'.','vpVer'] , vpVer)
dlmwrite([data_dir, split,filesep, im_name,'.','vpHor'] , vpHor)


% grass and non-grass accumulators
dlmwrite([data_dir, split,filesep, im_name,'.','grassAccum'] , uint16(A_grass))
dlmwrite([data_dir, split,filesep, im_name,'.','nonGrassAccum'] , uint16(A_non_grass))


% dlmwrite the equations of the lines from the vanishing points
dlmwrite([data_dir, split,filesep, im_name,'.','vpHorLines'] , vpHorLines)
dlmwrite([data_dir, split,filesep, im_name,'.','vpVerLines'] , vpVerLines)

% accumulators for line accumulators
dlmwrite([data_dir, split,filesep, im_name,'.','vpHorLinesAccum'] , uint16(A_hor_lines))
dlmwrite([data_dir, split,filesep, im_name,'.','vpVerLinesAccum'] , uint16(A_ver_lines))

%
temp = [Y.y1, Y.y2, Y.y3, Y.y4]; % corresponds to T B L R
dlmwrite([data_dir, split,filesep, im_name,'.','initialTblr'] , uint16(temp'))


% cross ratio tensors for lines
tempT1 =  T_hor(Y.y1(1):Y.y1(2), Y.y2(1):Y.y2(2),:);
tempT1 = reshape(tempT1, [Y.y1(2)-Y.y1(1)+1, (Y.y2(2)-Y.y2(1)+1)*4]);

tempT2 =  T_ver(Y.y3(1):Y.y3(2), Y.y4(1):Y.y4(2),:);
tempT2 = reshape(tempT2, [Y.y3(2)-Y.y3(1)+1, (Y.y4(2)-Y.y4(1)+1)*5]);

dlmwrite([data_dir, split,filesep, im_name,'.','horLinesCR'] , uint16(tempT1))
dlmwrite([data_dir, split,filesep, im_name,'.','verLinesCR'] , uint16(tempT2))

% cross ratio tensors for ellipse
tempT1 =  TE1(Y.y1(1):Y.y1(2), Y.y2(1):Y.y2(2),:);
tempT1 = reshape(tempT1, [Y.y1(2)-Y.y1(1)+1, (Y.y2(2)-Y.y2(1)+1)*4]);

tempT2 =  TE2(Y.y3(1):Y.y3(2), Y.y4(1):Y.y4(2),:);
tempT2 = reshape(tempT2, [Y.y3(2)-Y.y3(1)+1, (Y.y4(2)-Y.y4(1)+1)*8]);

dlmwrite([data_dir, split,filesep, im_name,'.','horEllipsisCR'] , uint16(tempT1))
dlmwrite([data_dir, split,filesep, im_name,'.','verEllipsisCR'] , uint16(tempT2))

% ellipse accumulator
dlmwrite([data_dir, split,filesep, im_name,'.','ellipsisAccum'] , uint16(A_ellipse))

% ellipse accumulator
dlmwrite([data_dir, split,filesep, im_name,'.','circleAccum'] , uint16(A_circle))

% dlmwrite the ground truth labels
dlmwrite([data_dir, split,filesep, im_name,'.','labelsGT'] , uint16(y_gt'))

% dlmwrite field and non-field accumulators
dlmwrite([data_dir, split,filesep, im_name,'.','fieldAccum'] , uint16(fieldAccum))
dlmwrite([data_dir, split,filesep, im_name,'.','nonFieldAccum'] , uint16(nonFieldAccum))

% dlmwrite the true homography
dlmwrite([data_dir, split,filesep, im_name,'.','homographyMatrix'] , H)
dlmwrite([data_dir, split,filesep, im_name,'.','invHomographyMatrix'] , inv(H))


end