function [y1, y2, y3, y4] = findTheMissingLabelsCREstGrid(annot, vpVer, vpHor,vpVerLines, vpHorLines, rayNumbers)
% this funcion finds the missing y1, ..., y4 using cross ratios of the
% lines we have on a grid

% input:
% annot : the annotation structure
% vpHorLines and vpVerLines have the form [a b c] in each row and are the
% grid lines from vpHor and vpVer respectively


% output:
% the predicted values for the missing y1, y2, y3, y4

%%

y1 = 0;
y2 = 0;
y3 = 0;
y4 = 0;


%%
fieldWid = 114.83; % in yards
fieldH = 74.37;

s = getFieldStruct(0, fieldWid , fieldH);

verX = unique(s.points(:, [1,2])); %the x -coordiante of vertical lines
horY = unique(s.points(:,[3,4]));  %the y -coordiante of horizontal lines
horY = [zeros(7,1);horY(1:end-1); horY(2:end)];



%%
foundLines = annot.lines.foundLines;
%foundLines = setdiff(foundLines, [7])
%vpVer = annot.vp.ver;
%vpHor = annot.vp.hor;

verLines = annot.lines.img(foundLines(foundLines <= 7),:);
horLines = annot.lines.img(foundLines(foundLines > 7),:);


%%
%{
ystar = vpHor(2); % vp1 is to the left and we pass a horizontal line through it.
                % So the line has equation L: y = ystar. Next we see for each
                % line from vp2, at what x-value it intersects L. These x-values 
                % construct the horizontal grid.
horGrid = -ystar*vpVerLines(:,2)./vpVerLines(:,1)-vpVerLines(:,3)./vpVerLines(:,1);
%}
% for vpHor
p = vpVer + [0, 50];

L = cross([vpHor,1], [p,1]);

horGrid = cross(vpVerLines,repmat(L, size(vpVerLines,1), 1));
horGrid = horGrid(:, 1:2)./repmat(horGrid(:,3), 1,2);
        % col 1 corresponds to x values and col 2 to y values of the grid


% similarly for vp2
xstar = vpVer(1); 
verGrid = -xstar*vpHorLines(:,1)./vpHorLines(:,2)-vpHorLines(:,3)./vpHorLines(:,2);


%% check whether y1 is annotated

% create a grid from a line L passing through vpHor and through the verLines.
% This line l could be arbitray but I require it to pass through vpHor and 
% a point above vpVer(2). Note that in the image this point falls below
% vpVer. Since vpHor(2) could be negative, I want to make sure that the
% line passing through vpHor and vpVerLines are above vpVer
% call this point p


if ~ismember(8, foundLines)
   
    % find which vertical lines have been found
    indHor = foundLines(foundLines > 7);
    
    % Pick the two annotated lines with the largest norm
    xx = horLines(:, 4) - horLines(:, 5);
    yy = horLines(:, 6) - horLines(:, 7);
   
    lengths = sqrt(xx.^2+yy.^2);
    [~,ind] = sort(lengths, 'descend');
    
    indHor = indHor(sort(ind(1:2)));
    
    % now get the ray number of the two annotated lines with the largest
    % norms from left to right
    
    indC = rayNumbers(indHor(1));
    indD = rayNumbers(indHor(2));
    
    
    C = verGrid(indC);
    D = verGrid(indD);
    B = verGrid(1:indC-1);
    A = vpVer(2);
    
    cr = (abs(A-C)/abs(A-D))*(abs(B-D)./abs(B-C));
    
    crTruth = abs(horY(indHor(2))-horY(8))/abs(horY(indHor(1))-horY(8));
    
    temp = abs(crTruth - cr);
    [~, idx] = min(temp); %index of closest value
    
    y1 = idx;
    
end



%% check whether y2 is annotated
if ~ismember(17, foundLines)
   
    % find which vertical lines have been found
    indHor = foundLines(foundLines > 7);
    
    % Pick the two annotated lines with the largest norm
    xx = horLines(:, 4) - horLines(:, 5);
    yy = horLines(:, 6) - horLines(:, 7);
   
    lengths = sqrt(xx.^2+yy.^2);
    [~,ind] = sort(lengths, 'descend');
    
    indHor = indHor(sort(ind(1:2)));
    
    % now get the ray number of the two annotated lines with the largest
    % norms from left to right
    
    indB = rayNumbers(indHor(1));
    indC = rayNumbers(indHor(2));
    
    
    A = vpVer(2);
    B = verGrid(indB);
    C = verGrid(indC);
    D = verGrid(indC+1:end);
    
    AC = abs(A-C);
    BC = abs(B-C);
    BD = abs(B-D);
    AD = abs(A-D);
    
    cr = (AC./BC)*(BD./AD);
    
    crTruth = abs(horY(indHor(1))-horY(17))/abs(horY(indHor(2))-horY(indHor(1)));
   
    temp = abs(crTruth - cr);
    [~, idx] = min(temp); %index of closest value
    
    y2 = indC + idx;
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Vertical Lines %%%%%%%%%%%%%%%%%%%%%%%%%


%% check whether y3 is annotated
if ~ismember(1, foundLines)
   
    % find which vertical lines have been found
    indVer = foundLines(foundLines <= 7);
    
    % Pick the two annotated lines with the largest norm
    xx = verLines(:, 4) - verLines(:, 5);
    yy = verLines(:, 6) - verLines(:, 7);
   
    lengths = sqrt(xx.^2+yy.^2);
    [~,ind] = sort(lengths, 'descend');
    
    indVer = indVer(sort(ind(1:2))); %indVer(1) is to the left of indVer(2);
    
    % now get the ray number of the two annotated lines with the largest
    % norms from left to right
    
    if vpHor(1) < 0 % the horizontal vp is to the left of the field. A = vpHor(1)
        indC = rayNumbers(indVer(1));
        indD = rayNumbers(indVer(2));
        
        A  = vpHor;
        B = horGrid(1:indC-1,:);
        C = horGrid(indC,:);
        D = horGrid(indD,:);
        
        
        nrowB = size(B, 1);
        
        AC = matRowNorm(A - C) ;
        BD = matRowNorm(B-repmat(D, nrowB,1));
        BC = matRowNorm(B-repmat(C, nrowB,1));
        AD = matRowNorm(A - D) ;
        
        cr = (AC./AD)*(BD./BC);
        
        crTruth = abs(verX(indVer(2))-verX(1))/abs(verX(indVer(1))-verX(1));
        
        temp = abs(crTruth - cr);
        [~, idx] = min(temp); %index of closest value
        
        y3 = idx;
    else % the horizontal vp is to the right of the field. D = vpHor(1)
        
        indB = rayNumbers(indVer(1)); 
        indC = rayNumbers(indVer(2)); 
        
        A  = horGrid(1:indB-1,:);
        B = horGrid(indB,:);
        C = horGrid(indC,:);
        D = vpHor;
        
        
        nrowA = size(A, 1);
        
        AC = matRowNorm(A - repmat(C, nrowA,1)) ;
        BD = matRowNorm(B-D);
        BC = matRowNorm(B-C);
        AD = matRowNorm(A - repmat(D, nrowA,1)) ;
        
        cr = (AC./AD)*(BD./BC);
        
        crTruth = abs(verX(indVer(2))-verX(1))/abs(verX(indVer(2))-verX(indVer(1)));
        
        temp = abs(crTruth - cr);
        [~, idx] = min(temp); %index of closest value
        
        y3 = idx;
        
    
    end
    
    
end


%% check whether y4 is annotated
if ~ismember(7, foundLines)
   
    % find which vertical lines have been found
    indVer = foundLines(foundLines <= 7);
    
    % Pick the two annotated lines with the largest norm
    xx = verLines(:, 4) - verLines(:, 5);
    yy = verLines(:, 6) - verLines(:, 7);
   
    lengths = sqrt(xx.^2+yy.^2);
    [~,ind] = sort(lengths, 'descend');
    
    indVer = indVer(sort(ind(1:2))); 
    
    % now get the ray number of the two annotated lines with the largest
    % norms from left to right
    
    if vpHor(1) < 0 % the horizontal vp is to the left of the field. A = vpHor(1)
        
        indB = rayNumbers(indVer(1));
        indC = rayNumbers(indVer(2));
        
        
        A = vpHor;
        B = horGrid(indB,:);
        C = horGrid(indC,:);
        D = horGrid(indC+1:end,:);

        nrowD = size(D, 1);
        
        AC = matRowNorm(A - C) ;
        BD = matRowNorm(repmat(B, nrowD,1) - D);
        BC = matRowNorm(B - C);
        AD = matRowNorm(repmat(A, nrowD,1) - D) ;
        
        %cr = (AC./AD)*(BD./BC);
        cr = (AC./BC)*(BD./AD);
        
        crTruth = abs(verX(indVer(1))-verX(7))/abs(verX(indVer(2))-verX(indVer(1)));
        
        temp = abs(crTruth - cr);
        [~, idx] = min(temp); %index of closest value
        
        y4 = indC + idx;
        
        
    else
        
        indA = rayNumbers(indVer(1));
        indB = rayNumbers(indVer(2));
        
        A = horGrid(indA,:);
        B = horGrid(indB,:);
        C = horGrid(indB+1:end,:);
        D = vpHor;
      
        nrowC = size(C, 1);
        
        AC = matRowNorm(repmat(A, nrowC,1) - C) ;
        BD = matRowNorm(B - D);
        BC = matRowNorm(repmat(B, nrowC,1) - C);
        AD = matRowNorm(A - D) ;
        
        %cr = (AC./AD)*(BD./BC);
        cr = (AC./BC)*(BD./AD);
        
        crTruth = abs(verX(7)-verX(indVer(1)))/abs(verX(7)-verX(indVer(2)));
        
        temp = abs(crTruth - cr);
        [~, idx] = min(temp); %index of closest value
        
        y4 = indB + idx;
        
        
        
    end
    
end




















