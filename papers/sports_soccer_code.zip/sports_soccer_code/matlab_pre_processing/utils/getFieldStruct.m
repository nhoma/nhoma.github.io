function s = getFieldStruct(marg, wid, h)
% this function return a model of a field July 24th notes

% output:
% P = a 17x4 matrix of the form [x1 x2 y1 y2] where (x1, y1) and (x2 y2)
% are the endpoints of each line segment. P(1:7, :) correspond to vertical
% lines from left to the right and P(8:17) correspond to horizontal
% lines from top to bottom first at left then at right such that P(33:34)
% correspond to the lower sideline

% L_vert = the ax+by+c = 0 equations of vertical lines from left to right
% L_hor = horizontal lines from top to bottom. Left to right. The bottom
% sideline comes the last

% linmem = a 17x1 vector such that linmem == 1 if the line is horizontal 
% and linmem == 2 if the line is vertical

% s = the above contained in a structure


%% DImensions are in Yards




%marg = 5; 
%wid = 114.83;
%h = 74.37;



%% Points. Refer to July 24 notes

P = zeros(34,2);

%% vertical Lines
% Left Goalline. l1

P(1,:) = [marg, marg];
P(2,:) = [marg, marg+h];

% l2

P(3,:) = [marg + 6, marg + (h-44)/2 + 12];
P(4,:) = [marg + 6, marg + (h-44)/2 + 32];

% l3

P(5,:) = [marg + 18, marg + h/2-22];
P(6,:) = [marg + 18, marg + h/2+22];

% l4 Midline

P(7,:) = [marg + wid/2, marg];
P(8,:) = [marg + wid/2, marg + h];


% l5

P(9,:) = [marg + wid - 18, marg + h/2-22];
P(10,:) = [marg + wid - 18, marg + h/2+22];

% l6

P(11,:) = [marg + wid - 6, marg + (h-44)/2 + 12];
P(12,:) = [marg + wid - 6, marg + (h-44)/2 + 32];

% l7, right goalline

P(13,:) = [marg + wid, marg];
P(14,:) = [marg + wid, marg+h];


%% horizontal lines

% m1, lower sideline

P(15,:) = [marg, marg];
P(16,:) = [marg + wid, marg];

% m2 
P(17,:) = [marg, marg + h/2 - 22];
P(18,:) = [marg + 18, marg + h/2 - 22];

% m3

P(19,:) = [marg, marg + h/2 - 10];
P(20,:) = [marg + 6, marg + h/2 - 10];

% m4 

P(21,:) = [marg, marg + h/2 + 10];
P(22,:) = [marg + 6, marg + h/2 + 10];

% m5
P(23,:) = [marg, marg + h/2 + 22];
P(24,:) = [marg + 18, marg + h/2 + 22];


% m6 

P(25,:) = [marg + wid, marg + h/2 - 22];
P(26,:) = [marg + wid - 18, marg + h/2 - 22];

% m7 

P(27,:) = [marg + wid, marg + h/2 - 10];
P(28,:) = [marg + wid - 6, marg + h/2 - 10];

% m8

P(29,:) = [marg + wid, marg + h/2 + 10];
P(30,:) = [marg + wid - 6, marg + h/2 + 10];

% m9

P(31,:) = [marg + wid, marg + h/2 + 22];
P(32,:) = [marg + wid - 18, marg + h/2 + 22];

% m10
P(33,:) = [marg + wid, marg + h];
P(34,:) = [marg , marg + h];


%% put the points in the format [x1 x2 y1 y2]

P = [P(1:2:33,1), P(2:2:34,1), P(1:2:33,2), P(2:2:34,2)];

% arrange so that the min comes before the max
P = [min(P(:,[1,2]), [], 2), max(P(:,[1,2]), [], 2), ...
    min(P(:,[3,4]), [], 2), max(P(:,[3,4]), [], 2)];


%% add the points to a structure
s.points = P;


%% plot the lines between the points

doPlotPoints = 0;

if doPlotPoints == 1
    figure;
    xlim([0, 150])
    ylim([0, 100])

    hold on;

    for ii =1:17

        plot([P(ii, 1), P(ii, 2)], [P(ii, 3), P(ii, 4)]);
        pause;
    end
end

%% create the linmem vector

linmem = ones(17, 1);
linmem(1:7, 1) = 2;

% add to the structure
s.linmem = linmem;

%% Lines. Separate the vertical and horizontal lines
% lines are of the form ax+by+c = 0

L_vert = zeros(7,3);
L_hor = zeros(6,3);

%% vertical lines form left to right. 7 of them

% l1 : left sideline
L_vert(1,:) = [1, 0, -marg];

% l2 
L_vert(2, :) = [1, 0, -( marg + 6 )];

% l3
L_vert(3, :) = [1, 0, - ( marg + 18 )];

% l4: midline

L_vert(4, :) = [1, 0, - ( marg + wid/2) ]; 

% l5

L_vert(5, :) = [1, 0, - ( marg + wid - 18) ]; 


% l6

L_vert(6, :) = [1, 0, - (marg + wid - 6)];

% l7

L_vert(7, :) = [1, 0, - (marg + wid )];


%% Horizontal lines. from below to top. 6 of them . some line correspond to 
% multiple line segments

L_hor(1,:) = [0, 1, - ( marg ) ];
L_hor(2,:) = [0, 1, - ( marg + h/2-22 ) ];
L_hor(3,:) = [0, 1, - ( marg + h/2-10 ) ];
L_hor(4,:) = [0, 1, - ( marg + h/2+10 ) ];
L_hor(5,:) = [0, 1, - ( marg + h/2+22 ) ];
L_hor(6,:) = [0, 1, - ( marg + h ) ];


%% plot the lines


%{
figure
xlim([ 0, 150 ])
ylim( [0, 100 ])
hold on;


for ii = 1:7
    plotABCLine(L_vert(ii,:), 150, 100)
    pause
end



for ii = 1:6
    plotABCLine(L_hor(ii,:), 150, 100)
    pause
end
%}





%% add it to a structure
s.vertical_lines = L_vert;
s.horizontal_lines = L_hor;
















end