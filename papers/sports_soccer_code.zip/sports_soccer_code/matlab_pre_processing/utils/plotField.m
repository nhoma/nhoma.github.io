function plotField(P, col, style, l_size)
% inpute: 
% P = an array of size 17*4
% array where each row specifies the [x1 x2 y1 y2] endpoints of the line
% segments in the field

hold on;

for ii =1:17
    
    plot([P(ii, 1), P(ii, 2)], [P(ii, 3), P(ii, 4)], ...
        col, 'LineWidth', l_size, 'LineStyle', style);
    %pause;
end

end