function plot_ellipse(params)

t = linspace(0,pi*2);
x = params(3) * cos(t);
y = params(4) * sin(t);
nx = x*cos(params(5))-y*sin(params(5)) + params(1);
ny = x*sin(params(5))+y*cos(params(5)) + params(2);
plot(nx,ny,'r-', 'LineWidth',3)

end