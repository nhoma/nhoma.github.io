function yGT = findGTRayNumbersOnEstimationGrid(annot, vpVer, vpHor, vpVerLines, vpHorLines, doPlot, im)
% This function computes the ray numbers associated to the true annotated
% lines on the grid constructed from the estimated vanishing points

%output: yGT = the ground truth labels. a 1*4 matrix

rayNumbers = zeros(17,1);
foundLines = annot.lines.foundLines;
verLines = annot.lines.img(foundLines(foundLines <= 7),:);
horLines = annot.lines.img(foundLines(foundLines > 7),:);

for ii=1:size(verLines, 1)
    minArea = Inf;
    L = verLines(ii, :); %[a,b,c,x1,x2,y1,y2]
    p1 = L([4,6]);
    p2 = L([5,7]);
    
    for jj = 1:size(vpVerLines, 1)
        
        L2 = vpVerLines(jj,:);
        d1 = dot([p1, 1], L2)/sqrt(sum(p1.^2)); % distance from endpoint of L to ray L2
        d2 = dot([p2, 1], L2)/sqrt(sum(p2.^2));
        
        if d1*d2 < 0 % the annoted line segment intersects the ray
            
            xpt = cross(L(1:3), L2);
            xpt = xpt(1:2)/xpt(3);
            
            % use pythagoreas
            base1 = sqrt(norm(p1-xpt)^2-d1^2);
            base2 = sqrt(norm(p2-xpt)^2-d2^2);
            
            totArea = abs(d1)*base1/2+abs(d2)*base2/2;
            
        else % have to find the area of a trapezoid
            
            h = norm(p1-p2);
            
            totArea = h*(abs(d1)+abs(d2))/2;
            
        end
        
        if totArea < minArea
            rayNumbers(foundLines(ii)) = jj;
            minArea = totArea;
        end
        
        
    end
    
    
end


for ii=1:size(horLines, 1)
    minArea = Inf;
    L = horLines(ii, :); %[a,b,c,x1,x2,y1,y2]
    p1 = L([4,6]);
    p2 = L([5,7]);
    
    for jj = 1:size(vpHorLines, 1)
        
        L2 = vpHorLines(jj,:);
        d1 = dot([p1, 1], L2)/sqrt(sum(p1.^2)); % distance from endpoint of L to ray L2
        d2 = dot([p2, 1], L2)/sqrt(sum(p2.^2));
        
        if d1*d2 < 0 % the annoted line segment intersects the ray
            
            xpt = cross(L(1:3), L2);
            xpt = xpt(1:2)/xpt(3);
            
            % use pythagoreas
            base1 = sqrt(norm(p1-xpt)^2-d1^2);
            base2 = sqrt(norm(p2-xpt)^2-d2^2);
            
            totArea = abs(d1)*base1/2+abs(d2)*base2/2;
            
        else % have to find the area of a trapezoid
            
            h = norm(p1-p2);
            
            totArea = h*(abs(d1)+abs(d2))/2;
            
        end
        
        if totArea < minArea
            rayNumbers(foundLines(size(verLines,1)+ii)) = jj;
            minArea = totArea;
        end
        
        
        
    end
    
    
end

col = 'r';
style = '--';
l_size = 1;


if doPlot == 1
    doPause = 0;
    indVer = rayNumbers( foundLines(foundLines <= 7));
    indHor = rayNumbers( foundLines(foundLines >7));
    plotVanishingGridAnnotatedData(vpHorLines(indHor,:), vpVerLines(indVer,:), ...
        doPause, im, col, style, l_size);
end




[y1, y2, y3, y4] = ...
    findTheMissingLabelsCREstGrid(annot, vpVer, vpHor,vpVerLines, vpHorLines, rayNumbers);



y1 = max(y1, rayNumbers(8));
y2 = max(y2, rayNumbers(17));
y3 = max(y3, rayNumbers(1));
y4 = max(y4, rayNumbers(7));

yGT = [y1, y2, y3, y4];



end