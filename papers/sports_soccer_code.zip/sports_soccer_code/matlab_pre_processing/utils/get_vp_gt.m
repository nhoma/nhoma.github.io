function [vp_hor, vp_ver] = get_vp_gt(H, field_w, field_h)

H_inv = inv(H);

s = getFieldStruct(0, field_w, field_h);

model_pts = [s.points(:,1),s.points(:,3),ones(17,1),s.points(:,2),s.points(:,4),ones(17,1)];
model_pts = model_pts([1,7,8,17],:);

img_pts = [model_pts(:, 1:3); model_pts(:, 4:6)]*H_inv';
img_pts = hnormalise(img_pts);
%img_pts = img_pts(:,1:2);

img_pts = [img_pts(1:4,:), img_pts(5:8,:)];

%% find the equation of the lines:
ver_lines = cross(img_pts(1:2,1:3), img_pts(1:2,4:6));
hor_lines = cross(img_pts(3:4,1:3), img_pts(3:4,4:6));

%% fing the vps

vp_ver = cross(ver_lines(1,:), ver_lines(2,:));
vp_ver = hnormalise(vp_ver);
vp_ver = vp_ver(1:2);

vp_hor = cross(hor_lines(1,:), hor_lines(2,:));
vp_hor = hnormalise(vp_hor);
vp_hor = vp_hor(1:2);

end