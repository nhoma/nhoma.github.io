function y_gt = find_y_gt(H, vpVerLines, vpHorLines, field_wid, field_h,im)
% this function finds ray numbers corresponding to the ground truth y
% the difference between this funciton and find_y_gt is that this function
% projects grid lines on to the image 
%output: yGT = the ground truth labels. a 1*4 matrix


%% find the projection of the sidelines from the model to the image
H_inv = inv(H);
s = getFieldStruct(0, field_wid, field_h);

model_pts = [s.points(:,1),s.points(:,3),ones(17,1),s.points(:,2),s.points(:,4),ones(17,1)];
model_pts = model_pts([1,7,8,17],:);

verLinesModel = vpVerLines*H_inv;
horLinesModel = vpHorLines*H_inv;



figure; hold on; 
%plotABCLine(verLinesModel(), field_wid+20, field_h+20, 'r')
plotABCLine(horLinesModel, field_wid+20, field_h+20, 'r')
xlim([-20,field_wid+20])
ylim([-20,field_h+20])

col = 'b';
style = ':';
l_size = 3;
plotField(s.points, col, style, l_size)


%{
figure
%imagesc(im); hold on; axis ij;
plot(model_pts(:,1),model_pts(:,2), 'r','LineWidth',1);
%}

%%
y_gt = zeros(1,4);


for ii=1:4
    minArea = Inf;
    L = img_pts(ii,:); %[x1, y1, x2, y2]
    p1 = L([1,2]);
    p2 = L([3,4]);
    
    [p1, p2] = restrict_line_to_image(p1, p2, 1280,720);
    
    if ii==1 || ii==2
        vpLines = vpHorLines;
    else
        vpLines = vpVerLines;
    end
    
    for jj = 1:size(vpLines, 1)
        
        L2 = vpLines(jj,:);
        d1 = dot([p1, 1], L2)/sqrt(sum(p1.^2)); % distance from endpoint of L to ray L2
        d2 = dot([p2, 1], L2)/sqrt(sum(p2.^2));
        
        if d1*d2 < 0 % the annoted line segment intersects the ray
            
            xpt = cross(L(1:3), L2);
            xpt = xpt(1:2)/xpt(3);
            
            % use pythagoreas
            base1 = sqrt(norm(p1-xpt)^2-d1^2);
            base2 = sqrt(norm(p2-xpt)^2-d2^2);
            
            totArea = abs(d1)*base1/2+abs(d2)*base2/2;
            
        else % have to find the area of a trapezoid
            
            h = norm(p1-p2);
            
            totArea = h*(abs(d1)+abs(d2))/2;
            
        end
        
        if totArea < minArea
            y_gt(ii) = jj;
            minArea = totArea;
        end
        
        
    end
    
    disp(['ii = ', num2str(ii), ', min = ', num2str(minArea)])

end


end
