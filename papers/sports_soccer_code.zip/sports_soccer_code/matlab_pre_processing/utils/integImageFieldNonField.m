function [fieldAccum, nonFieldAccum] = integImageFieldNonField(vp1_num, vp2_num, yGT)
% this function computes the accumulators corresponding to field and
% nonfield given the true labels
%input: yGT = the true labels


A = zeros(vp1_num, vp2_num); 

A(yGT(1):yGT(2), yGT(3):yGT(4)) = 1;

fieldAccum = cumsum(cumsum(A')');    

A = ~A;
nonFieldAccum = cumsum(cumsum(A')');

end