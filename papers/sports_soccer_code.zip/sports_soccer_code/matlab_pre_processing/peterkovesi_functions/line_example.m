im = imread('images/sample1.jpg');
load('images/sample1BB.mat')


edgeim = getEdgeBW(im,'log', BB);

figure(1), imshow(edgeim);

[edgelist, labelededgeim] = edgelink(edgeim, 10);
drawedgelist(edgelist, size(im), 1, 'rand', 2); axis off

tol = 2;
seglist = lineseg(edgelist, tol);

drawedgelist(seglist, size(im), 2, 'rand', 3); axis off