%% Clear and close


clear all;
close all;


%% directories

%data_dir = '/ais/gobi4/namdar/soccer/data/cvpr/';
data_dir = '/ais/gobi4/namdar/soccer/data/cvpr/matlab_format/';
split = {'train_val', 'test'};
%split = {'train_val_hdf5', 'test_hdf5'};
%split = {'temp'};

%% hyperparamters
%numVpVer = 2000; % for the grid
%numVpHor = 500; % for the grid
numVpVer = 600; % for the grid
numVpHor = 300; % for the grid

wid = 1280;
h = 720;

field_wid = 114.83; % in yards
field_h = 74.37;

%%
parpool(30)
%%
saveResults = 1;

%%
%ii=1
%jj=1

%%
for ii = 1:2
    %%
    img_names = dir([data_dir, split{ii}, '/*.jpg']);
    img_names = {img_names.name};
    failed = zeros(1, length(img_names));
    
    %%
    parfor jj = 1:length(img_names)
        %failed = []
        try
            
            %% load the image, segmentations and the homography
            
            %jj = 200
            im_name = img_names{jj};
            %im_name='35.jpg'
            im_name = im_name(1:end-4);
            
            %im_name = '199_rev'
            %im_name = '37'
            
            disp([split{ii},' ', num2str(jj), '/', num2str(length(img_names)),': ',im_name])
            
            im = imread([data_dir, split{ii},filesep,im_name, '.jpg']);
            preds = load([data_dir, split{ii},filesep, im_name, '_seg_pred']);
            preds = preds.preds;
            
            H = load([data_dir, split{ii},filesep, im_name,'.homographyMatrix']);
            
            %% get the vanishing points
            disp('Computing VPs!')
            do_plot = 0;
            [vpVer, vpHor, W_hor,W_ver, W_circ, W_ell, ellipse, grass, background] = ...
                get_vp(im, preds, 0, do_plot);
            %{
            figure;
                imagesc(preds)
            imagesc(background)
                imagesc(W_ver)
                imagesc(W_hor)
                imagesc(W_circ)
                imagesc(W_ell)
    
            %}
            
            %% construct a grid
            
            disp('Get Grid!')
            plotGrid = 0;
            [vpHorLines, vpVerLines] = integImageGrid(vpVer, vpHor, numVpVer, numVpHor, plotGrid, im);
            
            %% restrict grid
            
            Y = restrict_grid(vpHor, vpVer, vpHorLines, vpVerLines);
            
            %% Find the designation of each pixel in the image to the cells created by
            
            plotGrid = 0;
            
            [V1, V2] = findPixelCellCorrespondance(vpHorLines, vpVerLines, wid, h, plotGrid);
            
            
            
            %% Compute the integral image corresponding to grass pixels
            
            [A_grass, grass_cell_counts] = computeIntegImage(V1, V2, numVpHor, numVpVer, grass, wid, h);
            
            %% Compute the integral image corresponding to non-grass pixels
            
            [A_non_grass, A_non_grass_cell_counts] = computeIntegImage(V1, V2, numVpHor, numVpVer, background, wid, h);
            
            %% Create accumulators corresponding to W1 and W2. That is accumulators which
            % specify how many line pixels from each vp is present in the image.
            % A1_lines is an accumulator corresponding to vp1
            A_hor_lines = computeIntegImage(V1, V2, numVpHor, numVpVer, W_hor, wid, h);
            
            % A2_lines correspond to vanishing points from vp2
            A_ver_lines = computeIntegImage(V1, V2, numVpHor, numVpVer, W_ver, wid, h);
                        
            %% create accumulators for ellipse
            
            A_ellipse = computeIntegImage(V1, V2, numVpHor, numVpVer, W_ell, wid, h);
            
            %% create accumulators for circle
            A_circle = computeIntegImage(V1, V2, numVpHor, numVpVer, W_circ, wid, h);
            
            %% Given the grid, get the cross ratio of the lines present in the image
            
            disp('Computing the cross ratios')
            tic
            [T_hor, T_ver] = getLinesCrossRatios(vpVer, vpHor,...
                vpVerLines, vpHorLines, Y, field_wid, field_h);
            toc

           %%
                            
           if 1==0
               
               %%
               ind = [11,117,260,562]
               ind = [14,192,302,580]
               col = 'r';
               style = '--';
               l_size = 1;
               doPause = 0;
               figure;
               ind_hor = squeeze(T_hor(ind(1),ind(2),:));
               ind_ver = squeeze(T_ver(ind(3),ind(4),:));
               plotVanishingGridAnnotatedData(vpHorLines(ind_hor,:),...
                   vpVerLines(ind_ver, :),doPause,W_ver , ...
                   col, style, l_size);
           end
           
           
           %}
            
            %% Get Ellipse cross ratios
            disp('Computing the cross ratios for ellipses and circle:')
            
            tic
            [TE1, TE2] = getEllipseCrossRatios(vpVer, vpHor, ...
                vpVerLines, vpHorLines, Y, field_wid, field_h);
            toc
            
            %tempT2 = uint16(tempT2);
            %dlmwrite([im_name,'.','verEllipsisCR1'] , tempT2)

                %%
                            
                %{
                
                ind = [31,205,199,470]
                col = 'r';
                style = '--';
                l_size = 1;
                doPause = 0;
                figure;
                ind_hor = squeeze(TE1(ind(1),ind(2),:));
                ind_ver = squeeze(TE2(ind(3),ind(4),:));
                plotVanishingGridAnnotatedData(vpHorLines(ind_hor,:),...
                    vpVerLines(ind_ver, :),doPause,W_circ , ...
                    col, style, l_size);
                %}

            
            %% Get the ground truth rays corresponding to the sidelines
            
            y_gt = find_y_gt(H, vpVerLines, vpHorLines, field_wid, field_h);
            
            %plotFieldHomography(y_gt(1), y_gt(2), y_gt(3), y_gt(4), vpHorLines, vpVerLines, im)
            
            %%
                            
                %{
                temp = [y_gt(1), y_gt(2), y_gt(3), y_gt(4)]
                temp = [33, 195, 300, 359]
                col = 'r';
                style = '--';
                l_size = 1;
                doPause = 0;
                figure;
                plotVanishingGridAnnotatedData(vpHorLines(temp(1:2),:),...
                    vpVerLines(temp(3:4), :),doPause, im, ...
                    col, style, l_size);
                %}

            
            %%
            %sometimes the values of y_gt fall outside the bounds specified by Y. If
            %this is the case let's do a hacky fix.
            if y_gt(1) < Y.y1(1)
                warning('y_gt(1) out of bounds!')
                y_gt(1) = Y.y1(1);
            end
            if y_gt(1) > Y.y1(2)
                warning('y_gt(1) out of bounds!')
                y_gt(1) = Y.y1(2);
            end
            if y_gt(2) < Y.y2(1)
                warning('y_gt(2) out of bounds!')
                y_gt(2) = Y.y2(1);
            end
            if y_gt(2) > Y.y2(2)
                warning('y_gt(2) out of bounds!')
                y_gt(2) = Y.y2(2);
            end
            if y_gt(3) < Y.y3(1)
                warning('y_gt(3) out of bounds!')
                y_gt(3) = Y.y3(1);
            end
            if y_gt(3) > Y.y3(2)
                warning('y_gt(3) out of bounds!')
                y_gt(3) = Y.y3(2);
            end
            if y_gt(4) < Y.y4(1)
                warning('y_gt(4) out of bounds!')
                y_gt(4) = Y.y4(1);
            end
            if y_gt(4) > Y.y4(2)
                warning('y_gt(4) out of bounds!')
                y_gt(4) = Y.y4(2);
            end
            
            %% Get the field and non-filed accumulators
            
            [fieldAccum, nonFieldAccum] = integImageFieldNonField(numVpHor,numVpVer, y_gt);
            
            %%
            if saveResults == 1
                parfor_dlmwrite(data_dir, split{ii}, im_name,...
                    vpVer, vpHor, A_grass, A_non_grass, vpHorLines, vpVerLines, ...
                    A_hor_lines, A_ver_lines, Y, T_hor, T_ver, TE1, TE2, ...
                    A_ellipse, A_circle, y_gt, fieldAccum, nonFieldAccum, H)
            end
            disp('Saving done!')
            
        catch
            
            failed(jj) = 1;
            disp(['img failed: ', num2str(jj)])
            continue
        end

        
    end
    failed_imgs = img_names(failed>0);
    save([data_dir, split{ii},filesep, 'failed.mat'], 'failed_imgs');
 
end
%%
disp('DONE!')
