import numpy as np
#import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import collections
import glob
import scipy.io
import scipy.misc



def get_data(img_dir):
    # array containing all the images

    #img_dir='/ais/gobi4/namdar/soccer/data/cvpr/train_val/'

    img_paths = glob.glob(img_dir + '*.jpg')
    num_imgs = len(img_paths)

    # read a sample image to get the size of the images
    inp_img = mpimg.imread(img_paths[0])
    img_size = inp_img.shape

    # store the images in a numpy array
    imgs = np.empty([num_imgs, img_size[0], img_size[1], img_size[2]], dtype='uint8')

    # store the ground truth lables in a numpy array as well
    labels = np.empty([num_imgs, img_size[0], img_size[1]], dtype='uint8')

    img_names = np.empty([num_imgs], dtype=object)

    for ii, img in enumerate(img_paths):

        # open the image
        inp_img = mpimg.imread(img)
        # img = misc.imread(img_name).flatten()

        imgs[ii] = inp_img

        temp = scipy.io.loadmat(img[:-4]+'_seg.mat')
        labels[ii] = temp['gt_mask']

        img_names[ii] = img[:-4]

    #plt.imshow(imgs[8, :, :, :].squeeze())
    #plt.matshow(labels[8, :, :].squeeze())




    return imgs, labels, num_imgs, img_names


class DataSet(object):

    def __init__(self, raw_images,
                 raw_labels,
                 img_paths,
                 rescale_factor = 1,
                 img_size=None,
                 label_size=None):

        """Construct a DataSet.
        """

        _num_examples = raw_images.shape[0]


        # Resize the images and the lables
        if img_size is not None and label_size is not None:
            img_size = img_size
            label = label_size
        else:
            new_size = [int(raw_images.shape[1]*rescale_factor),
                                     int(raw_images.shape[2]* rescale_factor)]
            img_size = new_size
            label_size = new_size

        _images = np.empty([_num_examples, img_size[0], img_size[1], 3], dtype='uint8')
        _labels = np.empty([_num_examples, label_size[0], label_size[1]], dtype='uint8')

        for ii in range(0, _num_examples):
            _images[ii] = scipy.misc.imresize(raw_images[ii].squeeze(), img_size, interp='bicubic')
            _labels[ii] = scipy.misc.imresize(raw_labels[ii].squeeze(), label_size, interp='nearest')

        # plt.imshow(_images[0, :, :, :].squeeze())
        # plt.matshow(_labels[0, :, :].squeeze())



        # Convert from [0, 255] -> [0.0, 1.0].
        _images = _images.astype(np.float16)
        _images = np.multiply(_images, 1.0 / 255.0)

        # plt.imshow(_images[0, :, :, :].squeeze(), vmin=0, vmax=1)
        self._num_examples = _num_examples
        self._images = _images
        self._labels = _labels
        self._img_size = img_size
        self._label_size = label_size
        self._img_paths = img_paths

    @property
    def images(self):
        return self._images

    @property
    def labels(self):
        return self._labels


    @property
    def num_examples(self):
        return self._num_examples

    @property
    def img_size(self):
        return self._img_size


    @property
    def label_size(self):
        return self._label_size

    @property
    def img_paths(self):
        return self._img_paths


def read_data_sets(path_to_data = '/ais/gobi4/namdar/soccer/data/cvpr/',
                   rescale_factor=1.0/4,
                   seed= 1987,
                   val_size = 50,
                   img_size = None,
                   label_size = None,
                   read_test= True):
    print("Reading the data!")

    train_val_images, train_val_labels, train_val_num_imgs, train_val_img_paths = \
        get_data(path_to_data+'train_val/')

    if read_test == True:
        test_images, test_labels, _, test_img_paths = get_data(path_to_data + 'test/')


    print("DONE!")

    print("Createing the validation set of size " + str(val_size) +
          " with random seed " + str(seed))
    # split to train and validation sets
    np.random.seed(seed)
    perm = np.arange(train_val_num_imgs)
    np.random.shuffle(perm)

    train_val_images = train_val_images[perm]
    train_val_labels = train_val_labels[perm]
    train_val_img_paths =  train_val_img_paths[perm]

    val_images = train_val_images[0:val_size]
    val_labels = train_val_labels[0:val_size]
    val_img_paths = train_val_img_paths[0:val_size]

    train_images = train_val_images[val_size:]
    train_labels = train_val_labels[val_size:]
    train_img_paths = train_val_img_paths[val_size:]

    print("Resizing the images:")

    train = DataSet(train_images, train_labels, train_img_paths,
                    rescale_factor=rescale_factor,
                    img_size=img_size,
                    label_size=label_size)
    val = DataSet(val_images, val_labels, val_img_paths,
                  rescale_factor=rescale_factor,
                  img_size=img_size,
                  label_size=label_size)
    if read_test == True:
        test = DataSet(test_images, test_labels, test_img_paths,
                       rescale_factor=rescale_factor,
                       img_size=img_size,
                       label_size=label_size)
    else:
        test = None

    print("Resized the Images!")

    data_sets = collections.namedtuple('Datasets', ['train', 'val', 'test'])

    return data_sets(train=train, val=val, test=test)
