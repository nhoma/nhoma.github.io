#!/bin/bash
source activate tf0.10
python training_vgg16_dilation_hockey_upp_circle.py
#python training_vgg16_hockey_more_lines.py
