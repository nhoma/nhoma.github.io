import tflearn
#import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import numpy as np
import tensorflow as tf

# import the custom code
from read_data import read_data_sets
from model_vgg16_dilation_only_conv import vgg16_dilation, get_gt_one_hot_node
from iou_metric import iou_metric

#import IOUMetric

# set up some hyper parameters

num_classes = 6
num_epoch = 150
batch_size = 10
initital_learning_rate = 0.01
path_to_vgg = "/ais/gobi4/namdar/soccer/data/cvpr/trained_models/vgg16_weights.npz"
path_to_checkpoints = "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/model_weights/vgg16_dilation_penalty_4/checkpoint"
#path_to_checkpoints = "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/model_weights/vgg16_dilation_20_epoch/checkpoint"
path_to_best_checkpoint = "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/model_weights/vgg16_dilation_best/"
path_to_logs = "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/tf_logs/vgg16_dilation/"
#latest_checkpoint_num = "-3680"
#model_name = "vgg16_simple_20_epoch_"+latest_checkpoint_num
#train, val, _ = read_data_sets('/ais/gobi4/namdar/soccer/data/cvpr/playing_around/',
#                               rescale_factor=0.5, val_size=1)


train, val, _ = read_data_sets(rescale_factor=0.25)


# read the vgg weights



#tf.reset_default_graph()

# define placeholder for input and output
x_inp = tflearn.input_data(
    shape=[None, train.img_size[0], train.img_size[1], 3],
    name='input')

# placeholder for the groundtruth
y_true = tf.placeholder(tf.float32,
                        shape=(None, train.label_size[0], train.label_size[1]))

# get the forward pass of the model
x = vgg16_dilation(x_inp)

# weight the observations
#x = tf.mul(x, tf.constant([3,3,3,1,1,1], shape=(1,6),dtype=tf.float32))
x = tf.pow(x, tf.constant([4,4,4,1,1,1], shape=(1,6),dtype=tf.float32))

# reshape the
y_pred = tf.reshape(x, shape=(-1, num_classes))



# get a one-hot encoding for the ground truth images
y_true_hot = get_gt_one_hot_node(y_true)

# define the loss
loss = tflearn.softmax_categorical_crossentropy(y_pred, y_true_hot)

# define the optimizer
#optimizer_op = tf.train.RMSPropOptimizer(0.01)
optimizer_op = tf.train.RMSPropOptimizer(learning_rate=initital_learning_rate)



#IOU
IOU = iou_metric(y_pred, y_true_hot)

print("IOU Defined!")


train_op = tflearn.TrainOp(loss,
                           optimizer=optimizer_op,
                           metric= IOU,
                           batch_size=batch_size)
'''
trainer = tflearn.Trainer(train_ops=train_op,
                          tensorboard_dir='./test')
'''

trainer = tflearn.Trainer(train_ops=train_op,
                          checkpoint_path=path_to_checkpoints,
                          keep_checkpoint_every_n_hours=0.5,
                          tensorboard_dir=path_to_logs)

print("Trainer Initialized!")

#trainer.restore(path_to_checkpoints+latest_checkpoint_num)

trainer.fit(feed_dicts={x_inp: train.images, y_true: train.labels},
            val_feed_dicts={x_inp: val.images, y_true: val.labels},
            show_metric=True,
            n_epoch=num_epoch)


'''
##
tflearn.config.is_training(is_training=False, session=trainer.session)



print("Got the predictions:")
# The PDF document
pdf_pages = PdfPages(path_to_figures + model_name + "train_false.pdf")

for ii in range(10):

    fig = plt.figure(figsize=(8, 12))

    for jj in range(5):
        plt.subplot(5, 2, 2 * jj + 1)
        # plt.imshow(players.train.images[i,:,:,:].squeeze(), vmin=0, vmax=1)
        plt.imshow(val.images[ii * 5 + jj])
        cur_axes = plt.gca()
        cur_axes.axes.get_xaxis().set_visible(False)
        cur_axes.axes.get_yaxis().set_visible(False)

        preds = trainer.session.run(x, feed_dict={x_inp: val.images[[ii * 5 + jj]]})

        preds_max = np.argmax(preds, axis=3)

        plt.subplot(5, 2, 2 * jj + 2)
        plt.imshow(preds_max[0])
        cur_axes = plt.gca()
        cur_axes.axes.get_xaxis().set_visible(False)
        cur_axes.axes.get_yaxis().set_visible(False)

    pdf_pages.savefig(fig)

    plt.close(fig)

pdf_pages.close()

print("Plotted all the figures!")


trainer.save('./saved/epoch250')

ind = 10
ind = ind + 1
temp = trainer.session.run(x, feed_dict={x_inp: val.images[[ind]] })

temp_max = np.argmax(temp, axis=3)


plt.imshow(val.images[ind,:,:,:])
plt.figure()
#plt.imshow(temp[ind, :, :, chan])
plt.imshow(temp_max[0])
plt.colorbar()

print(temp.shape)



init = tf.initialize_all_variables()
#with tf.Session() as sess:
sess = tf.Session()
sess.run(init)

temp = sess.run(y_pred, feed_dict={x_inp: train.images[[0]] })
print(temp.shape)


temp1 = sess.run(y_true_reshaped, feed_dict={y_true: train.labels[[0]] })


temp2 = sess.run(y_true_hot, feed_dict={y_true: train.labels[[0]] })



init = tf.initialize_all_variables()
sess = tf.InteractiveSession()
sess.run(init)
temp = sess.run(x, feed_dict={x_inp: train.images[[0]]})


#plt.figure()
plt.imshow(train.images[0,:,:,:])
plt.imshow(train.labels[0,:,:])



plt.colorbar()


#return x

# define the loss function


# define the training
'''


