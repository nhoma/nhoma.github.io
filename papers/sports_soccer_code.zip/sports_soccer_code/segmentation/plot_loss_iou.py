import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from __future__ import division


path_to_data = "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/curves/vgg16_dilation/"


pdf_pages = PdfPages(path_to_data+"curves.pdf")

# loss
fig = plt.figure()
loss_train = pd.read_csv(path_to_data+'loss_train.csv', header=0)
loss_val = pd.read_csv(path_to_data+'loss_val.csv', header=0)

plt.plot(loss_train['Step'], loss_train['Value'], label='Train Loss')
loss_val_plt = plt.plot(loss_val['Step'], loss_val['Value'], label='Val Loss')
plt.ylim(0,0.5)
plt.legend()

pdf_pages.savefig(fig)
plt.close(fig)


# iou
fig = plt.figure()
iou_train = pd.read_csv(path_to_data+'iou_train.csv', header=0)
iou_val = pd.read_csv(path_to_data+'iou_val.csv', header=0)

plt.plot(iou_train['Step'], iou_train['Value'], label='Train IOU')
loss_val_plt = plt.plot(iou_val['Step'], iou_val['Value'], label='Val IOU')
plt.legend(loc=2)

pdf_pages.savefig(fig)
plt.close(fig)


pdf_pages.close()