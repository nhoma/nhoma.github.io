function [vpVer, vpHor, W_hor,W_ver, W_circ, W_ell, ellipse, grass, background] = ...
                get_vp(im, preds, do_plot_all, do_plot_vps)
%%
%{
clear all;
close all;
%}  
          
%%
ellipse = []; % [pLeft; pRight; pTop; pBot];
big_ellipse_found = 0;
thresh_circ = 0.6; % threshold for the boundary of the ellipse
thresh_grass = 0.5; % threshold for inside the ellipse
ver_lines_thresh = 150;
%ver_lines_thresh = 400;
field_wid = 114.83; % in yards
field_h = 74.37;
r = 10;




%%
%{
do_plot_all = 1;
data_dir = '/ais/gobi4/namdar/soccer/data/cvpr/';
im_num = '73';

im = imread([data_dir, 'train_val/',im_num, '.jpg']);
%im = imread([data_dir, 'test/',im_num, '.jpg']);
preds = load([data_dir, 'train_val/',im_num, '_seg_pred']);
%preds = load([data_dir, 'test/',im_num, '_seg_pred']);
preds = preds.preds;
%}

%%
[h, w, ~] = size(im);

%im = imresize(im, [h/4, w/4]);
%imagesc(im)

im_gray = rgb2gray(im);
im_edge_log = edge(im_gray, 'log');
im_edge_log_smaller_sigma = edge(im_gray, 'log', [], 1);
%figure;imagesc(im_edge_log)
im_edge_canny = edge(im_gray, 'canny', [], 0.1);
%figure;imagesc(im_edge_canny)

%im_edge = im_edge_log | im_edge_canny | im_edge_log_smaller_sigma;
im_edge_1 = im_edge_log | im_edge_canny;
im_edge_2 = im_edge_log_smaller_sigma | im_edge_canny;

%im_edge = imresize(im_edge, [h/4,w/4]);

%figure;imagesc(im_edge)

%%


%imagesc(preds)

preds_size = size(preds);

%% get horizontal lines
hor = zeros(preds_size);
hor(preds == 1) = 1;

hor = imresize(hor, [h,w]);
hor(hor>0) = 1;
hor(hor < 0 ) = 0;
%figure;imagesc(hor)
W_hor_1 = hor.* im_edge_1;
%do_plot_all = 1;
hor_lines_1 = get_lines(im_gray, W_hor_1, 20, do_plot_all);

W_hor_2 = hor.* im_edge_2;
%do_plot_all = 1;
hor_lines_2 = get_lines(im_gray, W_hor_2, 20, do_plot_all);

%W_hor = W_hor_1 | W_hor_2;
hor_lines = [hor_lines_1;hor_lines_2];
W_hor = zeros(h,w);
for ii=1:size(hor_lines,1)
    W_hor = drawLineInMatrix(W_hor, hor_lines(ii,[1,3]), hor_lines(ii,[2,4]));
end
%figure;imagesc(W_hor)

num_hor_lines = size(hor_lines, 1);
hor_lines_eq = cross([hor_lines(:,1), hor_lines(:,3), ones(num_hor_lines,1)], ...
    [hor_lines(:,2), hor_lines(:,4), ones(num_hor_lines,1)],2);




%% get vertical lines
ver = zeros(preds_size);
ver(preds == 0) = 1;
ver = imresize(ver, [h,w]);
ver(ver>0) = 1;
ver(ver < 0 ) = 0;
%figure;imagesc(ver)
W_ver_1 = ver.* im_edge_1;
%figure;imagesc(W_ver)
%figure;imagesc(ver)
%do_plot_all = 1        
ver_lines_1 = get_lines(im_gray, W_ver_1, 30, do_plot_all);

W_ver_2 = ver.* im_edge_2;
ver_lines_2 = get_lines(im_gray, W_ver_2, 30, do_plot_all);

%W_ver = W_ver_1 | W_ver_2;
W_ver = zeros(h,w);
ver_lines = [ver_lines_1;ver_lines_2];
for ii=1:size(ver_lines,1)
    W_ver = drawLineInMatrix(W_ver, ver_lines(ii,[1,3]), ver_lines(ii,[2,4]));
end
%figure;imagesc(W_ver)
num_ver_lines = size(ver_lines, 1);
ver_lines_eq = cross([ver_lines(:,1), ver_lines(:,3), ones(num_ver_lines,1)], ...
    [ver_lines(:,2), ver_lines(:,4), ones(num_ver_lines,1)],2);


%% get ellipses
ell = zeros(preds_size);
ell(preds == 2) = 1;
ell = imresize(ell, [h,w]);
ell(ell>0) = 1;
ell(ell < 0 ) = 0;
%figure;imagesc(ell)
W_ell = ell.* im_edge_2;
%figure;imagesc(W_ell)

%% get grass

grass = zeros(preds_size);
grass(preds == 4) = 1;
grass = imresize(grass, [h,w], 'nearest');
grass(grass>0) = 1;
grass(grass < 0 ) = 0;
%figure; imagesc(grass)


%% get grass

background = zeros(preds_size);
background(preds == 5) = 1;
background = imresize(background, [h,w], 'nearest');
background(background>0) = 1;
background(background < 0 ) = 0;
%figure; imagesc(background)



%% get circle
circ = zeros(preds_size);
circ(preds == 3) = 1;

circ = imresize(circ, [h,w]);

circ(circ>0) = 1;
circ(circ < 0 ) = 0;

%figure;imagesc(circ)


W_circ = circ.* im_edge_2;
%imagesc(W_circ)

%%

if max(max(W_circ)) > 0
    %
    %figure;imagesc(circ)
    
    [edgelist, ~, ~] = edgelink(W_circ, 20);
    
    %drawedgelist(edgelist, size(circ), 1, 'rand', 1);
    
    % remove the edges that are too small
    newEdgeList = cleanedgelist(edgelist, 100);
    
    if ~isempty(newEdgeList)
        
        if do_plot_all == 1
            imagesc(im);
            drawedgelist(newEdgeList, size(circ), 1, 'rand', 1);
        end
        
        % connect the edges
        edges = [];
        for jj = 1:length(newEdgeList)
            edges = [edges; newEdgeList{jj}];
        end
        
        % fit an ellipse through the edges
        params = fitellipse(edges(:,2), edges(:,1));
        
        
        % find the 4 defining points of the big ellipse
        Cx = params(1);
        Cy = params(2);
        Rx = abs(params(3));
        Ry = abs(params(4));
        theta = params(5);
        
        if do_plot_all == 1
            figure
            imagesc(im)
            hold on
            plot_ellipse(params)
        end
        
        if max(Rx, Ry) > 2000 || min(Rx,Ry) < 10
            disp('The detected ellipse has a very large axis! Not Right!')
            big_ellipse_found = 0;
        else
                  
            % draw the ellipse in a matrix
            [circ_mat, circ_inside] = draw_ellipse_in_matrix(params, size(circ), 500);
            %imagesc(circ_mat)
            
            % check whether the percentage of ellipse edges that are actually denoted
            % to be a middle circle are more than a threshold
            acc_circ = circ .* circ_mat;
            acc_circ = sum(acc_circ(:))/sum(circ_mat(:));
            
            acc_circ_inside = grass .* circ_inside;
            acc_circ_inside = sum(acc_circ_inside(:))/sum(circ_inside(:));
            
            if acc_circ > thresh_circ && acc_circ_inside > thresh_grass
                disp('Found a big ellipse!')
                big_ellipse_found = 1;
                
            else
                disp('No big ellipse!')
                big_ellipse_found = 0;
                
            end
            
        end
    end
end
    


%%



if big_ellipse_found == 1
    %%
    disp('Detected a big ellipse!')
    
    
    pLeft = [-Rx; 0];
    pRight = [Rx; 0];
    pBot = [0; -Ry];
    pTop = [0; Ry];
    
    rot = [cos(theta), -sin(theta); sin(theta), cos(theta)];
    
    % need some transformation
    pLeft = (rot*pLeft+[Cx;Cy])';
    pRight = (rot*pRight+[Cx;Cy])';
    pBot = (rot*pBot+[Cx;Cy])';
    pTop = (rot*pTop+[Cx;Cy])';
    
    
    %%
    % somwtimes the code for some reason replaces the position of pLeft/pRight
    % with pTop/pBottom. fix it with a hack
    
    
    movingPoints = [pLeft; pRight; pTop; pBot];
    
    [~, ind] = min(movingPoints(:,1));
    pLeft = movingPoints(ind,:);
    [~, ind] = max(movingPoints(:,1));
    pRight = movingPoints(ind,:);
    [~, ind] = min(movingPoints(:,2));
    pTop = movingPoints(ind,:);
    [~, ind] = max(movingPoints(:,2));
    pBot = movingPoints(ind,:);
    
    movingPoints = [pLeft; pRight; pTop; pBot];
    ellipse = movingPoints;
    
    
    %imagesc(im); hold on; axis ij;plot(p_top(1), p_top(2), 'r*')
    
    %%
    
    
    sumVerEdges = sum( sum( W_ver(:,1:max(round(pLeft(1)),0)) ) ) + ...
        sum( sum( W_ver(:,min(round(pRight(1)),1281):end) ) );
    
    %{
    if pLeft(1) > 0 && pRight(1) < w
        enoughVerLines = sumVerEdges > 2*ver_lines_thresh;
        
    else
        enoughVerLines = sumVerEdges > ver_lines_thresh;
        
    end
    %}
    
    enoughVerLines = sumVerEdges > ver_lines_thresh;
    
    if enoughVerLines == 1
        disp('Enough Vertical Lines!')
    else
        disp('Not Enough Vertical Lines! Have to use the Middle Circle')
    end
        
    %%
    if enoughVerLines == 1
        %% for vpVer
        %{
        minor_line = cross([pTop,1],[pBot,1]);
        
        % compute the intersection of the minor axis with the previously
        % found vertical lines
        Xpnts = cross(repmat(minor_line, num_ver_lines, 1), ver_lines_eq);
        Xpnts = Xpnts(:,1:2)./repmat(Xpnts(:,3), 1,2);
        
        % keep the vps that have y-coordinate larger than -1000 and less
        % than h/2
        keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,2) < -1000 | Xpnts(:,2) > h/2) );
        Xpnts=Xpnts(keepind,:);
        
        %{
        figure
        imagesc(im);hold on;
        plot(Xpnts(:,1),Xpnts(:,2), '*');
        xlim([-4000,4000]);ylim([-1000,2000])
        %}
        
        minor_line = [pTop(1), pBot(1) , pTop(2) , pBot(2) , 0, 0 , norm(pTop-pBot)];
        %}
        
        % if enough vertical lines, just add the minor axis as another line
        % alond the others
        minor_line = [pTop(1), pBot(1) , pTop(2) , pBot(2) , 0, 0 , norm(pTop-pBot)];
        
        Xpnts = ComputeIntersectionPoints([ver_lines; minor_line]);
        %Xpnts = ComputeIntersectionPoints(ver_lines);
        keepind = find(~isnan(Xpnts(:,1)) & ~isnan(Xpnts(:,2)) & ...
            ~isinf(Xpnts(:,1)) & ~isinf(Xpnts(:,2)));
        Xpnts = Xpnts(keepind,:);
        % consider only intersection points that are outside the field
        keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,1) < w & Xpnts(:,1) > 0 & Xpnts(:,2) < h & Xpnts(:,2) > h/2));
        Xpnts=Xpnts(keepind,:);
        
        % consider only the intersection points that are below h/2 of the image: namdar
        % added
        
        keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,2) > h/2) );
        Xpnts=Xpnts(keepind,:);
        
        
        % keep the vps that have y-coordinate larger than -1000
        keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,2) < -1000) );
        Xpnts=Xpnts(keepind,:);
        
        %VoteArr = ComputeLinePtVote(ver_lines,Xpnts);
        VoteArr = ComputeLinePtVote([ver_lines; minor_line],Xpnts);
        Vote=sum(VoteArr,1);
        
        %get the first point & remove the lines of this point
        [~, ind]=sort(Vote,'descend');
        vpVer=Xpnts(ind(1),1:2);
        
        
        
    else % not enough vertical lines
        %% find the intersection of the minor axis and the boundary between grass and outside
        
        minor_line = cross([pTop,1],[pBot,1]);
        
        % find the intersrction of the minor_line with horizontal lines
        p_top_field = cross(repmat(minor_line, num_hor_lines,1), hor_lines_eq);
        p_top_field = p_top_field(:,1:2)./repmat(p_top_field(:,3), 1,2);
        
        %% only keep the points that are above the ellipse
        p_top_field = p_top_field(find(p_top_field(:,2) < pTop(2)),:);
        p_top_field = p_top_field(find(p_top_field(:,2) > 0),:);
        
        [~, inds] = sort(p_top_field(:,2));
        p_top_field = round(p_top_field(inds, :));
        
        inds = ones(size(p_top_field,1),1);
        
        for ii=1:size(inds,1)
            
            if p_top_field(ii,1) > 0 && p_top_field(ii,1) < w && ...
                    p_top_field(ii,2) > 0 && p_top_field(ii,2) < h
                
                if background(p_top_field(ii,2),p_top_field(ii,1)) == 1
                    inds(ii,1) = 0;
                end
                
            end
            
        end
        
        p_top_field = p_top_field(inds>0,:);
        
        % as the top mose point, look at the mean of at most 5 top points
        for ii = 1:5
            if size(p_top_field, 1) >= (6-ii)
                p_top_field = median(p_top_field(1:(6-ii),:), 1);
                break;
            end
        end
        
        if do_plot_all == 1
            %imagesc(im); hold on; axis ij;plot(p_top_field(:,1), p_top_field(:,2), 'r*')
            imagesc(im); hold on; axis ij;plot(p_top_field(1), p_top_field(2), 'r*')
        end
        
        if isempty(p_top_field)
            warning('The intersection of the minor axis and the grass boundary is empty!')
            warning('Set vertical vp at infinity!')
            vpVer = [1000*minor_line(2)/minor_line(1)-minor_line(3)/minor_line(1),-1000];
        else
            
            movingPoints = [movingPoints; p_top_field(1,:)];
            
            %%
            
            
            pLeftModel = [field_wid/2-r, field_h/2];
            pRightModel = [field_wid/2+r, field_h/2];
            pBotModel = [field_wid/2, field_h/2+r];
            pTopModel = [field_wid/2, field_h/2-r];
            
            fixedPoints = [pLeftModel; pRightModel;  pTopModel; pBotModel; [field_wid/2,0]];
            
            
            %% we have [fixedPoint(1,:),1] = [movingPoints(1,:),1]*tform.T
            tform = fitgeotrans(movingPoints, fixedPoints, 'Projective');
            
            
            %% apply a homography to the two tangent lines to the middle circle in the model
            % and find the vertical vp as the intersection of these two projected lines
            
            L1 = [1, 0, -field_wid/2-r];
            L2 = [1, 0, -field_wid/2+r];
            
            verL1 = L1*tform.T';
            verL2 = L2*tform.T';
            
            vpVer = cross(verL1,verL2);
            vpVer = vpVer ./ vpVer(3);
            vpVer = vpVer(1:2);
        end
        
        
    end
    
    %% up until here we settled the vertical vp. Let's now deal with the
    % horizontal vp but with less fuss. The only thing we do extra for the
    % horizontal vp is the use it's major axis as an extra vertical line
    % for the voting procedure
    if enoughVerLines == 0
        % find the line corresponding to major axis
        majorLine = cross([pLeft,1],[pRight,1]);
        
        % compute the intersection of the major axis with the previously
        % found horizontal lines
        Xpnts = cross(repmat(majorLine,num_hor_lines,1), hor_lines_eq);
        Xpnts = Xpnts(:,1:2)./repmat(Xpnts(:,3), 1,2);
        
        % prune some intersections based on prior knowledge
        keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,1) < w & Xpnts(:,1) > 0 & Xpnts(:,2) < h & Xpnts(:,2) > h/2));
        Xpnts=Xpnts(keepind,:);
        
        
        thresh = 0.1; %for checking orthogonality using dot products. ~ 3 degrees
        orthochks = checkOrthogonalityNamdar(vpVer, Xpnts, thresh);
    
        Xpnts = Xpnts(orthochks,:);

                
        % add the major axis to the list of lines
        majorLine = [pLeft(1), pRight(1) , pLeft(2) , pRight(2) , 0, 0 , norm(pLeft-pRight)];
        
        VoteArr = ComputeLinePtVote([hor_lines;majorLine],Xpnts);
        Vote=sum(VoteArr,1);
        
        %get the first point & remove the lines of this point
        [~, ind]=sort(Vote,'descend');
        vpHor=Xpnts(ind(1),1:2);
    else
        
        %{
        figure
        imagesc(im);hold on;
        plot(Xpnts(:,1),Xpnts(:,2), '*');
        xlim([-4000,4000]);ylim([-1000,2000])
        %}

               
        % add the major axis to the list of lines
        majorLine = [pLeft(1), pRight(1) , pLeft(2) , pRight(2) , 0, 0 , norm(pLeft-pRight)];
        
        Xpnts = ComputeIntersectionPoints([hor_lines; majorLine]);
        %Xpnts = ComputeIntersectionPoints([hor_lines]);
        keepind = find(~isnan(Xpnts(:,1)) & ~isnan(Xpnts(:,2)) & ...
            ~isinf(Xpnts(:,1)) & ~isinf(Xpnts(:,2)));
        Xpnts = Xpnts(keepind,:);
        % consider only intersection points that are outside the field
        keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,1) < w & Xpnts(:,1) > 0 & Xpnts(:,2) < h & Xpnts(:,2) > 0));
        Xpnts=Xpnts(keepind,:);
        
        % consider only the intersection points that are below h/2 of the image: namdar
        % added
        keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,2) > h/2) );
        Xpnts=Xpnts(keepind,:);
        
        thresh = 0.1; %for checking orthogonality using dot products. ~ 3 degrees
        orthochks = checkOrthogonalityNamdar(vpVer, Xpnts, thresh);
    
        Xpnts = Xpnts(orthochks,:);
        
        VoteArr = ComputeLinePtVote([hor_lines; majorLine],Xpnts);
        %VoteArr = ComputeLinePtVote([hor_lines],Xpnts);
        Vote=sum(VoteArr,1);
        
        %get the first point & remove the lines of this point
        [~, ii]=sort(Vote,'descend');
        vpHor(1:2)=Xpnts(ii(1),1:2);
        
        
    end
    
else % no big ellipse found
    
    
    
    %% get vpVer
    
    Xpnts = ComputeIntersectionPoints(ver_lines);
    keepind = find(~isnan(Xpnts(:,1)) & ~isnan(Xpnts(:,2)) & ...
        ~isinf(Xpnts(:,1)) & ~isinf(Xpnts(:,2)));
    Xpnts = Xpnts(keepind,:);
    % consider only intersection points that are outside the field
    keepind = setdiff(1:size(Xpnts,1),...
        find(Xpnts(:,1) < w & Xpnts(:,1) > 0 & Xpnts(:,2) < h & Xpnts(:,2) > h/2));
    Xpnts=Xpnts(keepind,:);
    
    % consider only the intersection points that are below h/2 of the image: namdar
    % added
    
    keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,2) > h/2) );
    Xpnts=Xpnts(keepind,:);
    
    
    % keep the vps that have y-coordinate larger than -1000
    keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,2) < -1000) );
    Xpnts=Xpnts(keepind,:);
    
    %Computing votes for every point from all lines. Rows <-> lines, Cols <->
    %intersection point
    VoteArr = ComputeLinePtVote(ver_lines,Xpnts);
    Vote=sum(VoteArr,1);
    
    %get the first point & remove the lines of this point
    [~, ii]=sort(Vote,'descend');
    vpVer(1:2)=Xpnts(ii(1),1:2);

    
        %% get vpHor
    
    Xpnts = ComputeIntersectionPoints(hor_lines);
    keepind = find(~isnan(Xpnts(:,1)) & ~isnan(Xpnts(:,2)) & ...
        ~isinf(Xpnts(:,1)) & ~isinf(Xpnts(:,2)));
    Xpnts = Xpnts(keepind,:);
    % consider only intersection points that are outside the field
    keepind = setdiff(1:size(Xpnts,1), ...
        find(Xpnts(:,1) < w & Xpnts(:,1) > 0 & Xpnts(:,2) < h & Xpnts(:,2) > 0));
    Xpnts=Xpnts(keepind,:);
    
    keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,2) > h/2) );
    Xpnts=Xpnts(keepind,:);
    
    
    thresh = 0.1; %for checking orthogonality using dot products. ~ 3 degrees
    orthochks = checkOrthogonalityNamdar(vpVer, Xpnts, thresh);
    
    Xpnts = Xpnts(orthochks,:);
    
    
    %Computing votes for every point from all lines. Rows <-> lines, Cols <->
    %intersection point
    VoteArr = ComputeLinePtVote(hor_lines,Xpnts);
    Vote=sum(VoteArr,1);
    
    %get the first point & remove the lines of this point
    [~, ii]=sort(Vote,'descend');
    vpHor(1:2)=Xpnts(ii(1),1:2);

    
end


%{
figure
imagesc(im);hold on;
plot(Xpnts(:,1),Xpnts(:,2), '*');
xlim([-4000,4000]);ylim([-1000,2000])
%}


%% Output parameters
%{

%}

W_ver = ver;
W_hor = hor;


if big_ellipse_found == 1 || sum(sum(W_circ)) > 1000
    W_circ = W_circ; % put here just for clarity
else
    W_circ = zeros(h,w);
end

if sum(sum(W_ell)) > 1000
    W_ell = ell; % put here just for clarity
else
    W_ell = zeros(h,w);
end





%%

if do_plot_all == 1 || do_plot_vps == 1
    
    f = figure();
    set(f, 'Position', [200, 508, 1200, 500])
    subplot(1,3,1)
    hold on;
    axis ij;
    imagesc(im);
    
    plot(vpVer(1), vpVer(2), 'g*','MarkerSize',10)
    xlim([min(vpVer(1)-100, 0), max(vpVer(1)+100, w)]);
    
    if big_ellipse_found == 1
        plot_ellipse(params)
    end
    
    subplot(1,3,2)
    hold on;
    axis ij;
    imagesc(im);
    plot(vpHor(1), vpHor(2), 'r*','MarkerSize',10)
    xlim([min(vpHor(1)-100, 0), max(vpHor(1)+100, w)]);
    
    subplot(1,3,3)
    imagesc(im);
    hold on;
    [y,x] = find(W_hor);
    plot(x,y, 'r.','MarkerSize',1);
    %plot(x,y, 'm.','MarkerSize',1);
    [y,x] = find(W_ver);
    plot(x,y, 'g.','MarkerSize',1);
    [y,x] = find(W_circ);
    plot(x,y, 'y.','MarkerSize',1);
    [y,x] = find(W_ell);
    plot(x,y, 'b.','MarkerSize',1);

    
    
end




end

%{
figure
imagesc(im)
axis ij
xlim([0 1280])
ylim([0 720])
hold on
%All_lines = ver_lines;
All_lines = hor_lines;
for ii = 1:size(All_lines,1)
        plot(All_lines(ii, 1:2), All_lines(ii, 3:4), 'r', 'LineWidth',3)
end
%}

