function [Accum, A] = computeIntegImage(V1, V2, vp1_num, vp2_num, G, wid, h)
%This function finds the integral image of the grass content on the field
% refer to June 11th notes
% input:
% VP1 = the (i,j)-th entry of V1 is equal to k if the (i,j) th entry falls
% between lines L_{k-1} and L_k from vp1
% VP2 = similar
% vp1_num = Number of grid lines from vp1
% vp2_num = number of grid lines from vp2
% G = a 720*1280 binary matrix where the (i,j)-th entry is 1 if pixel (i,j)
% corresponds to some feature persent in the image and 0 otherwise
% wid,h = width and height of the image
% output:
% Accum: the integral image of G

% wid = 1280;
% h = 720;


% create an empty accumulator. For details refer to June 3rd and June 6th
% notes. A initially contains the number of grass pixels in each cell
A = zeros(vp1_num, vp2_num); 


for ii = 1:h
    
    for jj = 1:wid
        x_ind = V1(ii,jj);
        y_ind = V2(ii,jj);
        
        if x_ind ~= 0 && y_ind ~= 0
            A(x_ind, y_ind) = A(x_ind, y_ind) + G(ii,jj);
        end
        
    end
    
end
    
% This is the accumulator    
Accum = cumsum(cumsum(A')');    
 
   
end    




