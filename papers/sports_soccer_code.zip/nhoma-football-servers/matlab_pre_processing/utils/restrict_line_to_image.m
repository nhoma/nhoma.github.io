function [p1, p2] = restrict_line_to_image(p1, p2, w,h)
% restrict the line with endpoints p1 and p2 to an image of size h*w
% return the endpoints of this new line
% if the line is completely outside the field of view, then return p1 and
% p2 unchanged

% Get coordinates of points on the line
points = getRasterLineCoordinates(p1, p2);



x = points(:, 1);
y = points(:, 2);

keepind = setdiff(1:size(points,1), find(x > w | x < 0 | y < 0 | y > h) );

if length(keepind) > 20
    points = points(keepind,:);
    
    [~, inds] = sort(points(:,1));
    points = points(inds,:);
    
    p1 = points(1,:);
    p2 = points(end,:);
end



end