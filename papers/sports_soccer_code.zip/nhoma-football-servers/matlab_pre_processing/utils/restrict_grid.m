function Y = restrict_grid(vpHor, vpVer, vpHorLines, vpVerLines)
% this function restricts the rays on the grid
% output: 
% Y = a structure that would contain the limits of each ray

%%
w = 1280;
h = 720;

%%
numVpVer = size(vpVerLines,1);
numVpHor = size(vpHorLines,1);


%%
Y.y1 = [3, numVpHor];
Y.y2 = [1, numVpHor-3];
Y.y3 = [3, numVpVer];
Y.y4 = [1, numVpVer-3];


%% 
refPoint = [w/2, h*2/3, 1]';

temp = sign(vpVerLines*refPoint);
changePoint = find(temp(1:end-1,1)+temp(2:end,1) == 0);

Y.y3(2) = changePoint - 3;
Y.y4(1) = changePoint + 3;

temp = sign(vpHorLines*refPoint);
changePoint = find(temp(1:end-1,1)+temp(2:end,1) == 0);

Y.y1(2) = changePoint - 3;
Y.y2(1) = changePoint + 3;

%% make sure Y3-max and y4-min dont cross the vertical line through vp

refPoint = vpVer;
refPoint(2) = refPoint(2) + 20;
refPoint = [refPoint';1];

temp = sign(vpVerLines*refPoint);
changePoint = find(temp(1:end-1,1)+temp(2:end,1) == 0);

Y.y3(2) = min(Y.y3(2), changePoint-2);
Y.y4(1) = max(Y.y4(1), changePoint+2);



%% refine the bounds on y3 and y4 so that they don't fall on the wrong
% side of the horizontal vp


if vpHor(1) < 0
    
    
    refPoint = vpHor;
    refPoint(1) = refPoint(1) + 50;
    refPoint = [refPoint';1];
    
    temp = sign(vpVerLines*refPoint);
    changePoint = find(temp(1:end-1,1)+temp(2:end,1) == 0);
    
    if ~isempty(changePoint)
        Y.y3(1) = max(Y.y3(1), changePoint+2);
    end
    
else
    
    
    refPoint = vpHor;
    refPoint(1) = refPoint(1) - 20;
    refPoint = [refPoint';1];
    
    temp = sign(vpVerLines*refPoint);
    changePoint = find(temp(1:end-1,1)+temp(2:end,1) == 0);
    
    if ~isempty(changePoint)
        Y.y4(2) = min(Y.y4(2), changePoint-2);
    end
    
end



%% refine the bounds on y1 so that it doesn't fall above vpVer
% side of the horizontal vp

refPoint = vpVer;
refPoint(2) = refPoint(2) + 10;
refPoint = [refPoint';1];

temp = sign(vpHorLines*refPoint);
changePoint = find(temp(1:end-1,1)+temp(2:end,1) == 0);

if ~isempty(changePoint)
    Y.y1(1) = max(Y.y1(1), changePoint+2);
end
    










end