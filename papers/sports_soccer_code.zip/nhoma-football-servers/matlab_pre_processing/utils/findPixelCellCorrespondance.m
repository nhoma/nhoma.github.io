function [V1, V2] = findPixelCellCorrespondance(vpHorLines, vpVerLines, wid, h, plotGrid)
% Find the designation of each pixel in the image to the cells created by 
% lines from the vanishing points.

% input: 
% vp#_lines: the equations for the lines emenating from vp# which creates
% the grid
% wid = width of the field
% h = height of the field
% plotGrid: 1 to plot the grids

% Output:
% VP1 = the (i,j)-th entry of V1 is equal to k if the (i,j) th entry falls
% between lines L_{k-1} and L_k from vp1
% VP2 = similar

%wid = 1280;
%h = 720;

numVpHor = size(vpHorLines,1);
numVpVer = size(vpVerLines,1);

              
% the (i,j)-th entry of V1 is equal to k if the (i,j) th entry falls
% between lines L_{k-1} and L_k from vp1
V1 = zeros(h, wid);
row_ind = ones(1, wid);

for ii = 1:numVpHor
   
    L = vpHorLines(ii,1:3);
    
    for x = 1:wid
        
        y = round(-L(1)/L(2)*x-L(3)/L(2));
        
        if y > 0
            
            if row_ind(1,x) <= h
                ind = row_ind(1,x):min(y, h)  ; 
                V1(ind, x) = ii;
                row_ind(1,x) = y+1;
                
            end
            
        end
        
    end
end

if plotGrid == 1
    figure;
    imagesc(V1)
%imshow(mat2gray(A1))
end
    
% the (i,j)-th entry of V2 is equal to k if the (i,j) th entry falls
% between lines L_{k-1} and L_k from vp2
V2 = zeros(h, wid);
col_ind = ones(h,1);

for jj = 1:numVpVer
   
    L = vpVerLines(jj,1:3);
    
    for y = 1:h
        x = round(-L(2)/L(1)*y-L(3)/L(1));
        
        if x > 0 
            
            if col_ind(y,1) <= wid
                ind = col_ind(y,1):min(x, wid) ; 
                V2(y, ind) = jj;
                col_ind(y,1) = x+1;
                
            end
            
        end
        
    end
end

if plotGrid == 1
    figure;
    imagesc(V2)
end

end

