function lines = lsdWrapper(im, minLen, doPlot)
% This funciton creates a matlab wrapper over the C's lsd function for
% detecting line segments


imwrite(im, 'temp.pgm', 'PGM');

system('/Users/namdar/Projects/Football/Code/branchAndBound/lsd_1.6/lsd temp.pgm temp.lines.txt')

lines = readtable('temp.lines.txt', 'Delimiter', ' ');


lines = table2array(lines);

%A = [A(:,3), A(:,4), A(:,1), A(:,2)];
lines = [lines(:,1), lines(:,3), lines(:,2), lines(:,4)];



lines = [lines, zeros(size(lines, 1), 3)];

lines(:,7) = sqrt(((lines(:,1)-lines(:,2)).^2 + (lines(:,3)-lines(:,4)).^2));

ind = find(lines(:,7) > minLen);

lines = lines(ind,:);


if doPlot == 1
    figure
    axis ij
    xlim([0 1280])
    ylim([0 720])
    hold on
    
    for ii = 1:size(lines,1)
        
        plot(lines(ii, 1:2), lines(ii, 3:4))
        
    end
    

end

% remove the temporary created files
delete('temp.pgm', 'temp.lines.txt');



end