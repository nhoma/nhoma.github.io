function [T1, T2, CR1, CR2] = getEllipseCrossRatiosHockey(vpVer, vpHor, ...
                                vpVerLines, vpHorLines, Y, wid, h)

%%
N = size(vpHorLines, 1); % number of lines from vpHor

M = size(vpVerLines, 1); % number of lines from vpVer



%%
p = vpVer + [0, 50];

L = cross([vpHor,1], [p,1]);

horGrid = cross(vpVerLines,repmat(L, size(vpVerLines,1), 1));
horGrid = horGrid(:, 1:2)./repmat(horGrid(:,3), 1,2);
% col 1 corresponds to x values and col 2 to y values of the grid
% have to tdo this since the y coordinate of the vpHor could be higher than
% the y-coordiante of the vpVer and just drawing a horGridontal line to
% create a grid would cause trouble


% similarly for vpVer
xstar = vpVer(1);
verGrid = -xstar*vpHorLines(:,1)./vpHorLines(:,2)-vpHorLines(:,3)./vpHorLines(:,2);

%% 

% radius of the circles in yards
r = 10; 

% offset from the center of the circles to the sides of the inside squares
q = r*sqrt(2)/2;
    
%%

CR_vertical = zeros(1,8);

CR_vertical(1) = wid/(12+q); 
CR_vertical(2) = wid/(12+r);
CR_vertical(3) = wid/(wid/2-r);
CR_vertical(4) = wid/(wid/2-q);
CR_vertical(5) = wid/(wid/2+q);
CR_vertical(6) = wid/(wid/2+r);
CR_vertical(7) = wid/(wid-12-r);
CR_vertical(8) = wid/(wid-12-q);

if vpHor(1) > 0
    
    % the horizontal vp is to the right of the field. D = vpHor
    % The actual cross ratios are actually reversed too. So lets
    % flip the actual cross ratios too
    CR_vertical = fliplr(CR_vertical);
    
end



%disp(CR_vertical)

% Cross ratios for the horizontal lines. There are 8 of them but I'll take
% the ones that are concurrent as one. There are 4 of them this way.
% Enumerate them from top to bottom
CR_horiz = zeros(1,4);

CR_horiz(1) = h/(h/2-r);
CR_horiz(2) = h/(h/2-q);
CR_horiz(3) = h/(h/2+q);
CR_horiz(4) = h/(h/2+r);

%disp(CR_horiz)

%% Given lines from vp2 (Vertical), find the ray numbers for vertical lines
% in the image


T2 = zeros(Y.y3(2), M, 8);
CR2 = zeros(Y.y3(2), M, 8);




for ii = Y.y3(1):Y.y3(2) % ii coresponds to y3
    
    
    
    % jj corresponds to y4. They have to be 5 apart to allow all the
    % vertical lines to be present on the grid
    %for jj = ii+6:M
    for jj = Y.y4(1):Y.y4(2)    
    
        %disp(['ii = ', num2str(ii), ', jj = ', num2str(jj)])
        
        ind = ii+1:jj-1;
        
        if vpHor(1) < 0 % the horizontal vp is to the left of the field. A = vpHor(1)
            
            A  = vpHor;
            B = horGrid(ii,:);
            C = horGrid(ind,:);
            D = horGrid(jj,:);
            
            nrowC = size(C, 1);
            
            AC = matRowNorm(repmat(A, nrowC,1) - C) ;
            BD = matRowNorm(B-D);
            BC = matRowNorm(repmat(B, nrowC,1)-C);
            AD = matRowNorm(A - D) ;
            
            CR = (AC./BC)*(BD./AD);
            
           
        else % the horizontal vp is to the right of the field. D = vpHor
            
            A  = horGrid(ii,:);
            B = horGrid(ind,:);
            C = horGrid(jj,:);
            D = vpHor;
            
            nrowB = size(B, 1);
            
            AC = matRowNorm(A-C) ;
            BD = matRowNorm(B-repmat(D, nrowB,1));
            BC = matRowNorm(B-repmat(C, nrowB,1));
            AD = matRowNorm(A - D) ;
            
            CR = (AC./AD)*(BD./BC);

        end 
         
        % perhaps before the if statement I can find the min/max CR and if
        % permissible, compute the rest. This optimizes the BB a bit.
        
        %if max(CR) >= CR_vertical(1) - 1 && min(CR) <= CR_vertical(end) + 1
            
            
            
             % TODO: add the ii and jj to the permited list of y3/y4
             
             % find the ray for the line  1
             temp = abs(CR - CR_vertical(1));
             [~, idx] = min(temp); %index of closest value
             T2(ii, jj, 1) = idx;   
             
             % find the ray for the line 2 
             temp = abs(CR - CR_vertical(2));
             [~, idx] = min(temp); %index of closest value
             T2(ii, jj, 2) = idx;   
            
             % find the ray for the midline 
             temp = abs(CR - CR_vertical(3));
             [~, idx] = min(temp); %index of closest value
             T2(ii, jj , 3) = idx;
            
             % find the ray for the line  4
             temp = abs(CR - CR_vertical(4));
             [~, idx] = min(temp); %index of closest value
             T2(ii, jj, 4) = idx;   
            
             % find the ray for the line  5
             temp = abs(CR - CR_vertical(5));
             [~, idx] = min(temp); %index of closest value
             T2(ii, jj, 5) = idx;   
             
             % find the ray for the line  6
             temp = abs(CR - CR_vertical(6));
             [~, idx] = min(temp); %index of closest value
             T2(ii, jj, 6) = idx;   
             
             % find the ray for the line  7
             temp = abs(CR - CR_vertical(7));
             [~, idx] = min(temp); %index of closest value
             T2(ii, jj, 7) = idx;
             
             % find the ray for the line  8
             temp = abs(CR - CR_vertical(8));
             [~, idx] = min(temp); %index of closest value
             T2(ii, jj, 8) = idx;   
             
             CR2(ii,jj,:) = CR(T2(ii, jj, :));
             T2(ii, jj, :) = T2(ii, jj, :) + ii;
             
            
           
        %end
         
        
         
    end
    
end





%% Given lines from vp1 (Horizontal), find the ray numbers for Horizontal lines
% in the image

% indexing has an issue, temp fix
%T1 = zeros(Y.y1(2)-Y.y1(1)+1, N, 4);
%CR1 = zeros(Y.y1(2)-Y.y1(1)+1, N, 4);

T1 = zeros(Y.y1(2), N, 4);
CR1 = zeros(Y.y1(2), N, 4);



for ii = Y.y1(1):Y.y1(2) % ii coresponds to y1    
    
    
    % jj corresponds to y2. They have to be 4 apart to allow all the
    % vertical lines to be present on the grid
    %for jj = ii+5:N
    for jj = Y.y2(1):Y.y2(2)
    
        ind = ii+1:jj-1;
        
        % the cross ratios: AC.BD/(BC.AD). I'll arrange them in increasing
        % order
        %CR = (abs(vp2(2)-ver(ind)) * abs(ver(ii)-ver(jj)))...
        %     ./ (abs(ver(ii)-ver(ind)) * abs(vp2(2)-ver(jj)));
        
        A = vpVer(2);
        B = verGrid(ii);
        C = verGrid(ind);
        D = verGrid(jj);
        
        AC = abs(A-C);
        BC = abs(B-C);
        BD = abs(B-D);
        AD = abs(A-D);
        
        CR = (AC./BC)*(BD./AD);
         
         
        % perhaps before the if statement I can find the min/max CR and if
        % permissible, compute the rest. This optimizes the BB a bit.
        
        %if CR(1) >= CR_horiz(1)-1 && CR(end) <= CR_horiz(end)+1
            
            
            
            % find the ray for the line 1
             temp = abs(CR-CR_horiz(1));
             [~, idx] = min(temp); %index of closest value
             T1(ii, jj , 1) = idx;
            
             % find the ray for the line 2
             temp = abs(CR-CR_horiz(2));
             [~, idx] = min(temp); %index of closest value
             T1(ii, jj , 2) = idx;
             
             
             
             
             % find the ray for the line 3
             temp = abs( CR - CR_horiz(3) );
             [~, idx] = min(temp); %index of closest value
             T1(ii, jj , 3) = idx;
             
             % find the ray for the line 4
             temp = abs( CR - CR_horiz(4) );
             [~, idx] = min(temp); %index of closest value
             T1(ii, jj , 4) = idx;
             
             CR1(ii,jj,:) = CR(T1(ii, jj, :));
             T1(ii, jj, :) = T1(ii, jj, :) + ii;
            
           
        %end
         
        
         
    end
    
end





end

