function [ell, ell_inside] = draw_ellipse_in_matrix(params, mat_size, spacing)
% this function takes the parameters of an ellipse and draw an ellipse in
% the matrix of size mat_size

t = linspace(0,pi*2, spacing);
x = params(3) * cos(t);
y = params(4) * sin(t);
nx = x*cos(params(5))-y*sin(params(5)) + params(1);
ny = x*sin(params(5))+y*cos(params(5)) + params(2);

img_pts = [nx', ny'];

ell = zeros(mat_size(1:2));

for jj = 1:spacing-1
    ell = drawLineInMatrix(ell, img_pts(jj,:), img_pts(jj+1,:));
end


ell_inside = poly2mask(round(nx), round(ny), mat_size(1), mat_size(2));


end