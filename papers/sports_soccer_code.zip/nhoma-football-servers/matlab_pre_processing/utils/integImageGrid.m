 function [vpHorLines, vpVerLines] = integImageGrid(vpVer, vpHor, numVpVertical, numVpHorizontal, doPlot, im)
% Create a mesh from the two orthogonal vanishing points that can be used
% to compute the integral images (look at june 5th notes)

% Input:
% vp = vanishing points
% num_vp1_bottom = 5; % number of lines from vp1 that passes through the bottom
% side of the ractangle (does not consider the line1min and max)
% num_vp1_right = 10; % number of lines from vp1 that passes through the right
% side of the ractangle
% num_vp2_bottom = 5;
% num_vp2_left = 10;
% wid = width of the grid
% h = height of the grid
% grass_bound = if we have an image of size 720x1280, the boundary is a 1*1280 vector that
% separated the field and the crowd. So each element specifies the row
% number of the boundary between the field and outside.

% doPlot = 1; %plot the mesh

% Output:
% vp1_lines = lines ax+by+c = 0 from the first vanishing point (corresponding to the sidelines)
%             returns [a, b, c] 
% vp2_lines = lines from the first vanishing point (corresponding to the goallines)


%%
% limits = [y1_min ,y2_max, y3_min, y4_max] % the limits for the grid when
% it is unbounded. Results obtained from get_grid_stats_from_gt.m

limits = [-20, 2000, -10000, 10000];
%limits = [-150, 2000, -11500, 13000];



%% 
%numVpVertical = 10;
%numVpHorizontal = 10;

verGrid = []; %used for horizonral vanishing point
horGrid = []; %used for vertical vanishing point


fieldWid = 1280;
fieldHeight = 720;

%% 

vpVer = [vpVer, 1];
vpHor = [vpHor, 1];



%% Now create two different horizontal grids based on where we're looking at


if vpHor(1) < 0
    %horGridLowerLim = max(limits(3),vpHor(1)+100);
    horGridLowerLim = limits(3); %y3_min
    horGridUpperLim = limits(4); %y4_max
else
    horGridLowerLim = limits(3);
    %horGridUpperLim = min(limits(4),vpHor(1)-100);
    horGridUpperLim = limits(4);
end
    
horGrid = [linspace(horGridLowerLim, horGridUpperLim,...
    numVpVertical)];
horGrid = sort(horGrid);
N = length(horGrid);
horGrid = [horGrid', fieldHeight/3*2*ones(N,1),ones(N,1)];

%% Create the vertical grid

%verGridLowerLim = vpVer(2)+100;
%verGridUpperLim = 2000;

verGridLowerLim = limits(1) ;
verGridUpperLim = limits(2); %y2_max


verGrid = [linspace(verGridLowerLim, verGridUpperLim, numVpHorizontal)];
verGrid = sort(verGrid);
N = length(verGrid);
verGrid = [fieldWid/2*ones(N,1), verGrid',ones(N,1)];


%%

vpVerLines = zeros(numVpVertical, 3);
vpHorLines = zeros(numVpHorizontal, 3);


%% Find the grid lines

for ii=1:numVpVertical
    vpVerLines(ii,1:3) = cross(vpVer, horGrid(ii,:));
end


for ii=1:numVpHorizontal
        vpHorLines(ii,1:3) = cross(vpHor, verGrid(ii,:));
end



%%
%{
figure;
imagesc(im)
hold on
plot(horGrid, fieldHeight/2, 'r*');
plot(fieldWid/2, horGrid, 'b*');

xlim([min(horGrid)-100, max(horGrid)+100])
ylim([min(verGrid)-100, max(verGrid)+100])
%}

col = 'r';
style = '--';
l_size = 1;


if doPlot == 1
    doPause = 0;
    figure;
    plotVanishingGridAnnotatedData(vpHorLines, vpVerLines,doPause, im, ...
        col, style, l_size);
    %plotVanishingGrid(vp, vp1_lines, [],wid,h, doPause, im, ...
    %    col, style, l_size);
end




 end





