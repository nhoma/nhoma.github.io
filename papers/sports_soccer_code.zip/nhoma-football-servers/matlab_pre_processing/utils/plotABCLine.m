function plotABCLine(L, wid, h, col)
% plot the line ax+by+c = 0 where L = [a b c]


n = size(L, 1);

for i = 1:n
    
    if L(i,2) ~= 0
        x=  linspace(1,wid,100);
        y = -L(i,1)/L(i,2)*x - L(i,3)/L(i,2);
        plot(x,y, col, 'LineWidth', 1);
    else
        y=  linspace(1,h,100);
        x = -L(i,2)/L(i,1)*y - L(i,3)/L(i,1);
        plot(x,y, col, 'LineWidth', 1);
    end

end


end