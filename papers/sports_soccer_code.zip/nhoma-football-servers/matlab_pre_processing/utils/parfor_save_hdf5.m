function parfor_save(data_dir, split, im_name,...
            vpVer, vpHor, A_grass, A_non_grass, vpHorLines, vpVerLines, ...
            A_hor_lines, A_ver_lines, Y, T_hor, T_ver, TE1, TE2, ...
            A_ellipse, A_circle, y_gt, fieldAccum, nonFieldAccum, H)

disp('Saving')
vpVer = vpVer';
vpHor = vpHor';
%save([data_dir, split,filesep, im_name,'.','vpVer'] , 'vpVer', '-ascii')
h5create([data_dir, split,filesep, im_name,'.','vpver'],'/vpVer',size(vpVer));
h5write([data_dir, split,filesep, im_name,'.','vpver'],'/vpVer',vpVer);
%save([data_dir, split,filesep, im_name,'.','vpHor'] , 'vpHor', '-ascii')
h5create([data_dir, split,filesep, im_name,'.','vphor'],'/vpHor',size(vpHor));
h5write([data_dir, split,filesep, im_name,'.','vphor'],'/vpHor',vpHor);


% grass and non-grass accumulators
%save([data_dir, split,filesep, im_name,'.','grassAccum'] , 'A_grass', '-ascii')
h5create([data_dir, split,filesep, im_name,'.','grassaccum'],'/grassAccum',size(A_grass));
h5write([data_dir, split,filesep, im_name,'.','grassaccum'],'/grassAccum' ,A_grass);
%save([data_dir, split,filesep, im_name,'.','nonGrassAccum'] , 'A_non_grass', '-ascii')
h5create([data_dir, split,filesep, im_name,'.','nongrassaccum'],'/nonGrassAccum',size(A_non_grass));
h5write([data_dir, split,filesep, im_name,'.','nongrassaccum'],'/nonGrassAccum' ,A_non_grass);


% save the equations of the lines from the vanishing points
%save([data_dir, split,filesep, im_name,'.','vpHorLines'] , 'vpHorLines', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'vphorlines'], '/vpHorLines', size(vpHorLines));
h5write([data_dir, split,filesep, im_name,'.', 'vphorlines'], '/vpHorLines', vpHorLines);
%save([data_dir, split,filesep, im_name,'.','vpVerLines'] , 'vpVerLines', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'vpverlines'], '/vpVerLines', size(vpVerLines));
h5write([data_dir, split,filesep, im_name,'.', 'vpverlines'], '/vpVerLines', vpVerLines);


% accumulators for line accumulators
%save([data_dir, split,filesep, im_name,'.','vpHorLinesAccum'] , 'A_hor_lines', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'vphorlinesaccum'], '/vpHorLinesAccum', size(A_hor_lines));
h5write([data_dir, split,filesep, im_name,'.', 'vphorlinesaccum'], '/vpHorLinesAccum', A_hor_lines);

%save([data_dir, split,filesep, im_name,'.','vpVerLinesAccum'] , 'A_ver_lines', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'vpverlinesaccum'], '/vpVerLinesAccum', size(A_ver_lines));
h5write([data_dir, split,filesep, im_name,'.', 'vpverlinesaccum'], '/vpVerLinesAccum', A_ver_lines);

%
temp = [Y.y1, Y.y2, Y.y3, Y.y4]; % corresponds to T B L R
%save([data_dir, split,filesep, im_name,'.','initialTblr'] , 'temp', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'initialtblr'], '/initialTblr', size(temp));
h5write([data_dir, split,filesep, im_name,'.', 'initialtblr'], '/initialTblr', temp);


% cross ratio tensors for lines
tempT1 =  T_hor(Y.y1(1):Y.y1(2), Y.y2(1):Y.y2(2),:);
%tempT1 = reshape(tempT1, [Y.y1(2)-Y.y1(1)+1, (Y.y2(2)-Y.y2(1)+1)*4]);
%save([data_dir, split,filesep, im_name,'.','horLinesCR'] , 'tempT1', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'horlinescr'], '/horLinesCR', size(tempT1));
h5write([data_dir, split,filesep, im_name,'.', 'horlinescr'], '/horLinesCR', tempT1);

tempT2 =  T_ver(Y.y3(1):Y.y3(2), Y.y4(1):Y.y4(2),:);
%tempT2 = reshape(tempT2, [Y.y3(2)-Y.y3(1)+1, (Y.y4(2)-Y.y4(1)+1)*5]);
%save([data_dir, split,filesep, im_name,'.','verLinesCR'] , 'tempT2', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'verlinescr'], '/verLinesCR', size(tempT2));
h5write([data_dir, split,filesep, im_name,'.', 'verlinescr'], '/verLinesCR', tempT2);

% cross ratio tensors for ellipse
tempT1 =  TE1(Y.y1(1):Y.y1(2), Y.y2(1):Y.y2(2),:);
%tempT1 = reshape(tempT1, [Y.y1(2)-Y.y1(1)+1, (Y.y2(2)-Y.y2(1)+1)*4]);
%save([data_dir, split,filesep, im_name,'.','horEllipsisCR'] , 'tempT1', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'horellipsiscr'], '/horEllipsisCR', size(tempT1));
h5write([data_dir, split,filesep, im_name,'.', 'horellipsiscr'], '/horEllipsisCR', tempT1);


tempT2 =  TE2(Y.y3(1):Y.y3(2), Y.y4(1):Y.y4(2),:);
%tempT2 = reshape(tempT2, [Y.y3(2)-Y.y3(1)+1, (Y.y4(2)-Y.y4(1)+1)*8]);
%save([data_dir, split,filesep, im_name,'.','verEllipsisCR'] , 'tempT2', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'verellipsiscr'], '/verEllipsisCR', size(tempT2));
h5write([data_dir, split,filesep, im_name,'.', 'verellipsiscr'], '/verEllipsisCR', tempT2);


% ellipse accumulator
%save([data_dir, split,filesep, im_name,'.','ellipsisAccum'] , 'A_ellipse', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'ellipsisaccum'], '/ellipsisAccum', size(A_ellipse));
h5write([data_dir, split,filesep, im_name,'.', 'ellipsisaccum'], '/ellipsisAccum', A_ellipse);

% ellipse accumulator
%save([data_dir, split,filesep, im_name,'.','circleAccum'] , 'A_circle', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'circleaccum'], '/circleAccum', size(A_circle));
h5write([data_dir, split,filesep, im_name,'.', 'circleaccum'], '/circleAccum', A_circle);

% save the ground truth labels
%save([data_dir, split,filesep, im_name,'.','labelsGT'] , 'y_gt', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'labelsgt'], '/labelsGT', size(y_gt));
h5write([data_dir, split,filesep, im_name,'.', 'labelsgt'], '/labelsGT', y_gt);

% save field and non-field accumulators
%save([data_dir, split,filesep, im_name,'.','fieldAccum'] , 'fieldAccum', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'fieldaccum'], '/fieldAccum', size(fieldAccum));
h5write([data_dir, split,filesep, im_name,'.', 'fieldaccum'], '/fieldAccum', fieldAccum);

%save([data_dir, split,filesep, im_name,'.','nonFieldAccum'] , 'nonFieldAccum', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'nonfieldaccum'], '/nonFieldAccum', size(nonFieldAccum));
h5write([data_dir, split,filesep, im_name,'.', 'nonfieldaccum'], '/nonFieldAccum', nonFieldAccum);


% save the true homography
%save([data_dir, split,filesep, im_name,'.','homographyMatrix'] , 'H', '-ascii')
h5create([data_dir, split,filesep, im_name,'.', 'homographymatrix'], '/homographyMatrix', size(H));
h5write([data_dir, split,filesep, im_name,'.', 'homographymatrix'], '/homographyMatrix', H);


end