function nrm= matRowNorm(A)
    nrm = sqrt(sum(A.^2,2));
end

