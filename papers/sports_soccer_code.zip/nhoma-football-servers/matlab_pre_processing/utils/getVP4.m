%Copyright (c) October,15 2008 by Varsha Hedau, UIUC.  All rights reserved.
function [vpVer, vpHor, W1,W2,W3, ellipse, zoomedIn]=getVP4(img, imgname, grass,doPlot, saveIm)
%function [vp, votes, p, All_lines, linemem]=getVP(imdir,imagename,DO_DISPLAY,savedir)
% getVP Get a triplet of orthogonal vanishing points for an image.
%For details see [1] Varsha Hedau, Derek Hoiem, David Forsyth, Recovering the Spatial
%     Layout of Cluttered Rooms, in the Twelfth IEEE International Conference
%     on Computer Vision, 2009.

% INPUT:
%    image -imagename and image directory
%    grass = the array of grass pixels

%OUTPUT:
% vpVer, vpHor - vertical and horizontal vanishing points
% W1,W2,W3 =  Create three array such that their entries specify whther there is a pixel
%  corresponding to lines from each vanishing points or ellipses
% ellipse = [pLeft; pRight; pTop; pBot]; coordinates of an ellipse if there
%           is one, empty otherwise



vp1=[];p=[];lines=[];
[h, w, ~]=size(img);



%get all the small lines in the field
All_lines = lsdWrapper(img, 20, 0);
% keep all the lines on the Grass
keepLines = keepFieldLines(All_lines, grass,0.5);
All_lines = All_lines(keepLines ==1, :);


% get very long lines of size 200
All_lines_long = lsdWrapper(img, 150, 0);
%keepLines = keepFieldLines(All_lines_long, ~grass,0.5);
%All_lines_long = All_lines_long(keepLines ==1, :);

All_lines = [All_lines; All_lines_long];


% get very long lines of size 200
All_lines_long = lsdWrapper(img, 200, 0);
%keepLines = keepFieldLines(All_lines_long, ~grass,0.5);
%All_lines_long = All_lines_long(keepLines ==1, :);

All_lines = [All_lines; All_lines_long];

% get very long lines of size 250
All_lines_long = lsdWrapper(img, 250, 0);
%keepLines = keepFieldLines(All_lines_long, ~grass,0.5);
%All_lines_long = All_lines_long(keepLines ==1, :);

All_lines = [All_lines; All_lines_long];

% get very long lines of size 300
All_lines_long = lsdWrapper(img, 300, 0);
%keepLines = keepFieldLines(All_lines_long, ~grass,0.5);
%All_lines_long = All_lines_long(keepLines ==1, :);

All_lines = [All_lines; All_lines_long];

% get very long lines of size 400
All_lines_long = lsdWrapper(img, 400, 0);
%keepLines = keepFieldLines(All_lines_long, ~grass,0.5);
%All_lines_long = All_lines_long(keepLines ==1, :);

All_lines = [All_lines; All_lines_long];
% get very long lines of size 400
All_lines_long = lsdWrapper(img, 500, 0);
%keepLines = keepFieldLines(All_lines_long, ~grass,0.5);
%All_lines_long = All_lines_long(keepLines ==1, :);

All_lines = [All_lines; All_lines_long];



%{

figure
imagesc(img)
axis ij
xlim([0 1280])
ylim([0 720])
hold on
    
for ii = 1:size(All_lines,1)
        plot(All_lines(ii, 1:2), All_lines(ii, 3:4))
%        plot(lines(ii, 1:2), lines(ii, 3:4), 'b')
end

%}

% chucking out the lines near image boundaries imaging artifacts
offset = 10;
inds = find(sum(double(All_lines(:,1:2)>offset),2) & ...
    sum(double(All_lines(:,1:2)<w-offset),2) & ...
    sum(double(All_lines(:,3:4)>offset),2) & ...
    sum(double(All_lines(:,3:4)<h-offset),2));
All_lines = All_lines(inds,:);

% namdar added, chuck out the lines corresponding to the clock, if one end
% point there, take out the line
inds = setdiff( ...
    1:size(All_lines,1), ...
    find( min(All_lines(:,1),All_lines(:,2)) > 90 & ...
    max(All_lines(:,1),All_lines(:,2)) < 360 & ...
    min(All_lines(:,3),All_lines(:,4)) > 45 & ...
    max(All_lines(:,3),All_lines(:,4)) < 110 ));

All_lines = All_lines(inds,:);


maxl=max(All_lines(:,7));



%Computing intersections of all the lines
lines = All_lines;
Xpnts = ComputeIntersectionPoints(lines);
keepind = find(~isnan(Xpnts(:,1)) & ~isnan(Xpnts(:,2)) & ...
    ~isinf(Xpnts(:,1)) & ~isinf(Xpnts(:,2)));
Xpnts = Xpnts(keepind,:);
% consider only intersection points that are outside the field
keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,1) < w & Xpnts(:,1) > 0 & Xpnts(:,2) < h & Xpnts(:,2) > 0));
Xpnts=Xpnts(keepind,:);

% consider only the intersection points that are below h/2 of the image: namdar
% added
%keepind = setdiff(1:size(Xpnts,1), ...
%    find(Xpnts(:,2) > 0 | Xpnts(:,2) < -600 | Xpnts(:,1) < -2000 | Xpnts(:,1) > 4000));
keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,2) > h/2) );
Xpnts=Xpnts(keepind,:);

% lets first find the horizontal vp, so use prior knowledge where it could
% be
keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,1) < w+1500 & Xpnts(:,1) > -1500) );
Xpnts=Xpnts(keepind,:);

% keep the vps that have y-coordinate larger than -1000
keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,2) < -1000) );
Xpnts=Xpnts(keepind,:);


%{
figure
imagesc(img);hold on;
plot(Xpnts(:,1),Xpnts(:,2), '*');
xlim([-1000,4000]);ylim([-1000,2000])
plot(vp2(:,1),vp2(:,2), 'r*','MarkerSize',10)
%}

%Computing votes for every point from all lines. Rows <-> lines, Cols <->
%intersection point
VoteArr = ComputeLinePtVote(lines,Xpnts);
Vote=sum(VoteArr,1);

%get the first point & remove the lines of this point
[~, ii]=sort(Vote,'descend');
vp1(1:2)=Xpnts(ii(1),1:2);
Vote1 = VoteArr(:,ii(1));
active_lines = find((Vote1*maxl./All_lines(:,7))<0.7);
inactive_lines = find((Vote1*maxl./All_lines(:,7))>=0.7);
lines = All_lines(active_lines,:);

%work with the remaining lines
Xpnts = ComputeIntersectionPoints(lines);
keepind = find(~isnan(Xpnts(:,1)) & ~isnan(Xpnts(:,2)) & ...
    ~isinf(Xpnts(:,1)) & ~isinf(Xpnts(:,2)));
Xpnts = Xpnts(keepind,:);


% consider only intersection points that are outside the field
keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,1) < w & Xpnts(:,1) > 0 & Xpnts(:,2) < h & Xpnts(:,2) > 0));
%keepind = find(Xpnts(:,1) > imsize(2) | Xpnts(:,1) < 0 | Xpnts(:,2) > imsize(1) < Xpnts(:,2) > 0);
Xpnts=Xpnts(keepind,:);
%VoteArr = ComputeLinePtVote([lines;All_lines(inactive_lines,:)],Xpnts);

keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,2) > h/2) );
Xpnts=Xpnts(keepind,:);

% keep the vps that have y-coordinate larger than -1000
keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,2) < -1000) );
Xpnts=Xpnts(keepind,:);



VoteArr = ComputeLinePtVote([lines],Xpnts);
Vote=sum(VoteArr(1:size(lines,1),:),1);
[vv, ii]=sort(Vote,'descend');
Vote = vv(:);
Xpnts=Xpnts(ii,:);
VoteArr = VoteArr(:,ii);
%Remove some of the points
[Xpnts,~,~] = RemoveRedundantPoints2(Xpnts,Vote,VoteArr,w,h);


thresh = 0.1; %for checking orthogonality using dot products. ~ 3 degrees
orthochks = checkOrthogonalityNamdar(vp1, Xpnts, thresh);

Xpnts = Xpnts(orthochks,:);


VoteArr = ComputeLinePtVote([lines],Xpnts);
Vote=sum(VoteArr(1:size(lines,1),:),1);

[~, ii]=sort(Vote,'descend');
vp2 = Xpnts(ii(1),1:2);

Vote2 = Vote(1,ii(1));

active_lines = find((Vote2*maxl./All_lines(:,7))<0.7);
inactive_lines = find((Vote2*maxl./All_lines(:,7))>=0.7);

% figure out which vp is vertical and which one is horizontal based on the
% following heuristic:
dist1 = abs(vp1(1) - 1280/2);
dist2 = abs(vp2(1) - 1280/2);

if dist1 > dist2
    vpHor = vp1;
    vpVer = vp2;
else
    vpHor = vp2;
    vpVer = vp1;
end


% find the line memberships
VoteArrTemp = ComputeLinePtVote(All_lines,[vpHor(1) vpHor(2);vpVer(1) vpVer(2)]);
p=[VoteArrTemp.*maxl./repmat(All_lines(:,7),[1 2]) zeros(size(All_lines,1),1)];
ind=find(max(p(:,1:2),[],2)< 0.5);
p(ind,3)=1;
p=p./repmat(sum(p,2),[1 3]);
%     [vv linemem] = max(VoteArrTemp,[],2);
[~, linemem] = max(p,[],2);



%% remove non-vp lines that are two small
thresh = 30;
keepLines = find(All_lines(:,7) > thresh & linemem == 3);
All_lines = All_lines([keepLines; find(linemem ~= 3)], :);
linemem = linemem([keepLines; find(linemem ~= 3)], :);



%% Let's guess if we have zoomed in or not on a side of the field.
% If we have zoomed in, then most likely the vertical vp will occupy a
% certain side of the space, our prior. In this scenario, we might find a
% big ellipse on the side which is not a good estimate of the conic in that
% side. So let's guess if we have zoomed in or not and if we haven't, let's
% fit an ellipse

if (vpVer(1) > w+800 & vpVer(2) < -200) 
    zoomedIn = 1; % looking at the left
elseif (vpVer(1) < 0-800 & vpVer(2) < -200)
    zoomedIn = 2; % looking at the right
else
    zoomedIn = 0;
end


%%
if zoomedIn > 0
    
    foundBigEll = 0;
    
else
    %%%%%%%%%%%%%%%%%%%%%%%% Let's play with ellipses
    %% Create three array such that their entries specify whther there is a pixel
    %  corresponding to lines from each vanishing points or ellipses
    
    doPlotW = 0;
    [W1, W2] = linesPixels(All_lines(find(linemem == 1 | linemem == 2),:), ...
        linemem(find(linemem == 1 | linemem == 2)),1280, 720, doPlotW);
    
    W3 = ellipsePixels(All_lines, linemem, 1280,720, doPlotW);
    
    %% Get the edge map of the image
  %  sigma = 1; %original 1.5
    
    grayIm = rgb2gray(img);
    
   % g=fspecial('gaussian', [7,7],sigma);
   % grayIm=filter2(g,grayIm);
    
    %im_canny = edge(grayIm, 'canny');
    im_edge = edge(grayIm , 'log');
    %imagesc(im_edge)
    
    %% Get the non-vp edges in edge map from non-vp lines
    W4 = zeros(720, 1280);
    
    
    offset = 5;
    
    [r,c] = find(W3);
    
    for jj=1:length(r)
        
        rInd = max(r(jj)-offset,1):min(r(jj)+offset,720);
        cInd = max(c(jj)-offset,1):min(c(jj)+offset,1280);
        W4(rInd, cInd) = im_edge(rInd, cInd);
    end
    %imagesc(W4)
    
    %% Connect the ellipse edges
    [edgelist, ~] = edgelink(W4, 20);
    %drawedgelist(edgelist, size(img), 1, 'rand', 1); axis off
    
    %% remove the edges that are too small
    
    newEdgeList = cleanedgelist(edgelist, 100);
    %drawedgelist(newEdgeList, size(img), 2, 'rand', 1); axis off
    
    %%
    if isempty(newEdgeList)
        
        foundBigEll = 0;
        
    else
        %% concatenate all the edges
        
        edges = [];
        for jj = 1:length(newEdgeList)
            edges = [edges; newEdgeList{jj}];
        end
        
        %% do k-means on the circular edges with 2 clusters. K means can be made faster
        % by sampling points from each edge segment rahter than clustering all the
        % edges together
        
        % initial centers = edges with the most left/right x's
        [~,indMin] = min(edges(:,2));
        [~,indMax] = max(edges(:,2));
        initCenter = [edges(indMin, :);edges(indMax, :)];
        
        [idx, C] = kmeans(edges, 2,'Start',initCenter);
        
        %% draw the line between the two centers in the ellipse edge image and
        % see whether it crosses any edge pixles. I'm seeing if the coordinates of
        % the line between the two centers contains non-vp edges or not. If yes,
        % then we might have two ellipses
        coords = getRasterLineCoordinates(C(1,:),C(2,:));
        
        W5 = edgelist2image(newEdgeList,[720,1280]);
        
        twoCircles = max(max((W5(coords(:,1), coords(:,2)))));
        
        if twoCircles == 1 % found two different ellipses, keep only the large one
            if sum(idx == 1) > sum(idx == 2)
                edges = edges(idx==1,:);
            else
                edges = edges(idx==2,:);
            end
        end
        
        
        %% fit the big ellipse
        
        params = fitellipse(edges(:,2), edges(:,1));
        
        
        %% find the 4 defining points of the big ellipse
        Cx = params(1);
        Cy = params(2);
        Rx = abs(params(3));
        Ry = abs(params(4));
        theta = params(5);
        
        %% See if the ellipse we fitted is actually the one that it's in the middle
        foundBigEll = 0; % a boolean to indicate whether we found big circle
        thresh = 150; % the minimum length of either axis
        
        if max(Rx,Ry) < thresh
            foundBigEll = 0;
        else
            foundBigEll = 1;
        end
        
        
        %% somwtimes, ellipse edges get assigned to horizontal vp, try to fix this
        % by refiting the big ellipse
        
        if foundBigEll == 1
            %%
            t = linspace(0,pi*2,1000);
            x = params(3) * cos(t);
            y = params(4) * sin(t);
            nx = round(x*cos(params(5))-y*sin(params(5)) + params(1));
            ny = round(x*sin(params(5))+y*cos(params(5)) + params(2));
            
            [~,ind] = find(nx > 0 & nx < 1280);
            nx = nx(ind);
            ny = ny(ind);
            
            [~,ind] = find(ny > 0 & ny < 720);
            nx = nx(ind);
            ny = ny(ind);
            %%
            W4 =  zeros(720, 1280);
            
            W4(sub2ind(size(W4),ny,nx)) = 1;
            
            [r,c] = find(W4);
            % take vpHor lines close to already fitted ellipse
            for jj=1:length(r)
                
                rInd = max(r(jj)-30,1):min(r(jj)+30,720);
                cInd = max(c(jj)-300,1):min(c(jj)+300,1280);
                W4(rInd, cInd) = W4(rInd, cInd) | W1(rInd, cInd);
                
            end
            
            % take nonvp lines
            for jj=1:length(r)
                
                rInd = max(r(jj)-10,1):min(r(jj)+10,720);
                cInd = max(c(jj)-300,1):min(c(jj)+300,1280);
                W4(rInd, cInd) = W4(rInd, cInd) | W3(rInd, cInd);
                
            end
            
            W4(sub2ind(size(W4),ny,nx)) = 0;
            
            [r,c] = find(W4);
            offset = 5;
            for jj=1:length(r)
                
                rInd = max(r(jj)-offset,1):min(r(jj)+offset,720);
                cInd = max(c(jj)-offset,1):min(c(jj)+offset,1280);
                W4(rInd, cInd) = im_edge(rInd, cInd);
                
            end
            
            %imagesc(W4)
            
            
            %% Connect the ellipse edges
            [edgelist, ~] = edgelink(W4, 20);
            %drawedgelist(edgelist, size(img), 1, 'rand', 1); axis off
            
            %% remove the edges that are too small
            newEdgeList = cleanedgelist(edgelist, 30);
            % drawedgelist(newEdgeList, size(img), 2, 'rand', 1); axis off
            
            
            %%
            edges = [];
            for jj = 1:length(newEdgeList)
                edges = [edges; newEdgeList{jj}];
            end
            
            
            %% fit the big ellipse
            
            params = fitellipse(edges(:,2), edges(:,1));
            
            %% find the 4 defining points of the big ellipse
            Cx = params(1);
            Cy = params(2);
            Rx = abs(params(3));
            Ry = abs(params(4));
            theta = params(5);
            
            
            
            %% Now depending on whether we have found a big circle, we should adjust the
            % vps. If we don't see a big circle, most likely we are looking at one of
            % the sides of the field and we have enough clues to find the vps. If we
            % see one, we either won't need it if there are clues for the vps, or we
            % might actually need it. Last case happend when we are looking at a narrow
            % region in the middle of the field.
            % We have to disinguish if we are looking exactly at the middle of the
            % field or not. If yes, then find the vps by actually finding an
            % approximate homography. If no, that is there are other lines, we can just
            % use the minor and major axis of the ellipse as extra lines for the
            % original procedure of vp estimation
            
            
            %%
            pLeft = [-Rx; 0];
            pRight = [Rx; 0];
            pBot = [0; -Ry];
            pTop = [0; Ry];
            
            rot = [cos(theta), -sin(theta); sin(theta), cos(theta)];
            
            % need some transformation
            pLeft = (rot*pLeft+[Cx;Cy])';
            pRight = (rot*pRight+[Cx;Cy])';
            pBot = (rot*pBot+[Cx;Cy])';
            pTop = (rot*pTop+[Cx;Cy])';
            
            
            %%
            % somwtimes the code for some reason replaces the position of pLeft/pRight
            % with pTop/pBottom. fix it with a hack
            
            
            movingPoints = [pLeft; pRight; pTop; pBot];
            
            [~, ind] = min(movingPoints(:,1));
            pLeft = movingPoints(ind,:);
            [~, ind] = max(movingPoints(:,1));
            pRight = movingPoints(ind,:);
            [~, ind] = min(movingPoints(:,2));
            pTop = movingPoints(ind,:);
            [~, ind] = max(movingPoints(:,2));
            pBot = movingPoints(ind,:);
            
            movingPoints = [pLeft; pRight; pTop; pBot];
            
            %% now depending if we have other lines to find the vps or not, consider
            % two different cases
            
            % here figure out if there are enough vertical lines
            % there are three scenarios:
            %   1) left and right of big ellipse in image
            %   2) left of big ellipse in image
            %   3) right of big ellipse in image
            
            % specify a threshold of vertical edges to be in the image
            thresh = 150;
            
            sumVerEdges = sum( sum( W2(:,1:max(round(pLeft(1)),0)) ) ) + ...
                sum( sum( W2(:,min(round(pRight(1)),1281):end) ) );
            
            if pLeft(1) > 0 && pRight(1) < 1280
                enoughVerLines = sumVerEdges > 2*thresh;
            else
                enoughVerLines = sumVerEdges > thresh;
            end
            
            
            
            %%
            if enoughVerLines == 1
                
                %% use the minor axis of the big ellipse as an extra vertical line segment
                % and only consider the intersection of other vertical lines and
                % the minor axis
                
                % find the line corresponding to minor axis
                minorLine = cross([pTop,1],[pBot,1]);
                
                verLines = All_lines(linemem == 2,1:4);
                verLines = cross([verLines(:,1), verLines(:,3), ones(sum(linemem==2),1)], ...
                    [verLines(:,2), verLines(:,4), ones(sum(linemem==2),1)]);
                
                % compute the intersection of the minor axis with the previously
                % found vertical lines
                Xpnts = cross(repmat(minorLine,sum(linemem==2),1), verLines);
                Xpnts = Xpnts(:,1:2)./repmat(Xpnts(:,3), 1,2);
                
                % keep the vps that have y-coordinate larger than -1000 and less
                % than h/2
                keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,2) < -1000 | Xpnts(:,2) > h/2) );
                Xpnts=Xpnts(keepind,:);
                
                
                % add the minor axis to the list of lines
                verLines = All_lines(linemem == 2,:);
                minorLine = [pTop(1), pBot(1) , pTop(2) , pBot(2) , 0, 0 , norm(pTop-pBot)];
                
                VoteArr = ComputeLinePtVote([verLines;minorLine],Xpnts);
                Vote=sum(VoteArr,1);
                
                %get the first point & remove the lines of this point
                [~, ind]=sort(Vote,'descend');
                vpVer=Xpnts(ind(1),1:2);
                
                
                
            else % not enough vertical lines
                %% find the intersection of the minor axis and the boundary between grass and outside
                
                % bound specified the top boundary between grass and outside
                bound = zeros(size(grass,2),1);
                
                for jj = 1:size(grass,2)
                    
                    for kk = 1:size(grass,1)
                        if grass(kk,jj) == 1
                            ind = kk;
                            break;
                        end
                    end
                    
                    bound(jj,1) = ind;
                end
                
                bound = [(1:1280)',bound];
                
                
                % find the line corresponding to minor axis
                minorLine = cross([pTop,1],[pBot,1]);
                
                
                pTemp = [-minorLine(3)/minorLine(1),1];
                coords = getRasterLineCoordinates(pTop, pTemp);
                
                pTemp = intersect(coords, bound, 'rows');
                
                if isempty(pTemp)
                    warning('The intersection of the minor axis and the grass boundary is empty!')
                    warning('Set vertical vp at infinity!')
                    vpVer = [1000*minorLine(2)/minorLine(1)-minorLine(3)/minorLine(1),-1000];
                elseif pTemp(1,2) == 1 % the boundary is outside the image, we have zoomed in
                    warning('The intersection of the minor axis and the grass boundary is outside the image!')
                    warning('Set vertical vp at infinity!')
                    vpVer = [1000*minorLine(2)/minorLine(1)-minorLine(3)/minorLine(1),-1000];
                else
                    movingPoints = [movingPoints; pTemp(1,:)];
                    
                    
                    %%
                    field_wid = 114.83; % in yards
                    field_h = 74.37;
                    r = 10;
                    
                    
                    pLeftModel = [field_wid/2-r, field_h/2];
                    pRightModel = [field_wid/2+r, field_h/2];
                    pBotModel = [field_wid/2, field_h/2+r];
                    pTopModel = [field_wid/2, field_h/2-r];
                    
                    fixedPoints = [pLeftModel; pRightModel;  pTopModel; pBotModel; [field_wid/2,0]];
                    
                    
                    %% we have [fixedPoint(1,:),1] = [movingPoints(1,:),1]*tform.T
                    tform = fitgeotrans(movingPoints, fixedPoints, 'Projective');
                    
                    
                    
                    %% apply a homography to the two tangent lines to the middle circle in the model
                    % and find the vertical vp as the intersection of these two projected lines
                    
                    L1 = [1, 0, -field_wid/2-r];
                    L2 = [1, 0, -field_wid/2+r];
                    
                    verL1 = L1*tform.T';
                    verL2 = L2*tform.T';
                    
                    vpVer = cross(verL1,verL2);
                    vpVer = vpVer ./ vpVer(3);
                    vpVer = vpVer(1:2);
                end
                
                
            end
            
            %% up until here we settled the vertical vp. Let's now deal with the
            % horizontal vp but with less fuss. The only thing we do extra for the
            % horizontal vp is the use it's major axis as an extra vertical line
            % for the voting procedure
            
            % find the line corresponding to major axis
            majorLine = cross([pLeft,1],[pRight,1]);
            
            horLines = All_lines(linemem == 1,1:4);
            horLines = cross([horLines(:,1), horLines(:,3), ones(sum(linemem==1),1)], ...
                [horLines(:,2), horLines(:,4), ones(sum(linemem==1),1)]);
            
            % compute the intersection of the major axis with the previously
            % found horizontal lines
            Xpnts = cross(repmat(majorLine,sum(linemem==1),1), horLines);
            Xpnts = Xpnts(:,1:2)./repmat(Xpnts(:,3), 1,2);
            
            keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,1) < w & Xpnts(:,1) > 0 & Xpnts(:,2) < h & Xpnts(:,2) > 0));
            Xpnts=Xpnts(keepind,:);
            keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,2) > h/2) );
            Xpnts=Xpnts(keepind,:);
            keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,1) < w+1500 & Xpnts(:,1) > -1500) );
            Xpnts=Xpnts(keepind,:);
            keepind = setdiff(1:size(Xpnts,1), find(Xpnts(:,2) < -1000) );
            Xpnts=Xpnts(keepind,:);
            
            
            % add the minor axis to the list of lines
            horLines = All_lines(linemem == 1,:);
            majorLine = [pLeft(1), pRight(1) , pLeft(2) , pRight(2) , 0, 0 , norm(pLeft-pRight)];
            
            VoteArr = ComputeLinePtVote([horLines;majorLine],Xpnts);
            Vote=sum(VoteArr,1);
            
            %get the first point & remove the lines of this point
            [~, ind]=sort(Vote,'descend');
            vpHor=Xpnts(ind(1),1:2);
            
            
        end
        
        
    end
    
end

%% only keep lines that are on the grass and have length more than some
% threshold. The threshold is to avoid having lines belonging to the
% players or to the net
%All_lines = lines;
%linemem = temp;
keepLines = keepFieldLines(All_lines, grass,0.5);
All_lines = All_lines(keepLines ==1, :);
linemem = linemem(keepLines ==1, :);

% for vertical and horizontal lines
if foundBigEll == 1
    thresh = 50;
else
    thresh = 100; % when no big ellipse found, we are most probably looking
    % at goal posts and want to eliminate net lines
end

keepLines = find(All_lines(:,7) > thresh & linemem ~= 3);
All_lines = All_lines([keepLines; find(linemem == 3)], :);
linemem = linemem([keepLines; find(linemem == 3)], :);

% for other/elliptical lines
thresh = 30;
keepLines = find(All_lines(:,7) > thresh & linemem == 3);
All_lines = All_lines([keepLines; find(linemem ~= 3)], :);
linemem = linemem([keepLines; find(linemem ~= 3)], :);


%% now convert the lines to matrix
doPlotW = 0;
[W1, W2] = linesPixels(All_lines(find(linemem == 1 | linemem == 2),:), ...
    linemem(find(linemem == 1 | linemem == 2)),1280, 720, doPlotW);

W3 = ellipsePixels(All_lines, linemem, 1280, 720, doPlotW);


%% refine W3 and W1 a bit

if foundBigEll == 1
    
    t = linspace(0,pi*2,10000);
    x = params(3) * cos(t);
    y = params(4) * sin(t);
    nx = round(x*cos(params(5))-y*sin(params(5)) + params(1));
    ny = round(x*sin(params(5))+y*cos(params(5)) + params(2));
    
    [~,ind] = find(nx > 0 & nx < 1280);
    nx = nx(ind);
    ny = ny(ind);
    
    [~,ind] = find(ny > 0 & ny < 720);
    nx = nx(ind);
    ny = ny(ind);
    
    offset = 5;
    for jj = 1:length(nx)
        
        W3(ny(jj), nx(jj)) = 1;
        
        rInd = max(ny(jj)-offset,1):min(ny(jj)+offset,720);
        cInd = max(nx(jj)-offset,1):min(nx(jj)+offset,1280);
        W1(rInd, cInd) = 0;
        
    end
    
end




%%
if foundBigEll == 1
    ellipse = movingPoints(1:4,:);
else
    ellipse = [];
end


%%
grp1=find(linemem==1);

grp2=find(linemem==2);

grp3=find(linemem==3);

%%
plotVis = 1;
if doPlot == 1
    
    f2 = figure;
    title(num2str(imgname))
    hold on;
    axis ij;
    if plotVis == 0
        set(f2, 'visible', 'off');
    end
    if 1 == 0
        plot(vpHor(1), vpHor(2), 'r*','MarkerSize',10)
        plot(vpVer(1), vpVer(2), 'g*','MarkerSize',10)
    end
    imagesc(img);
    [y,x] = find(W1);
    plot(x,y, 'r.','MarkerSize',1);
    %plot(x,y, 'm.','MarkerSize',1);
    [y,x] = find(W2);
    plot(x,y, 'g.','MarkerSize',1);
    [y,x] = find(W3);
    plot(x,y, 'b.','MarkerSize',1);
    %plot(All_lines(grp1, [1 2])', All_lines(grp1, [3 4])','r');
    %plot(All_lines(grp2, [1 2])', All_lines(grp2, [3 4])','g');
    %plot(All_lines(grp3, [1 2])', All_lines(grp3, [3 4])','b');
    %plot(All_lines(grp1, [1 2])', All_lines(grp1, [3 4])','b','LineWidth',2);
    %plot(All_lines(grp2, [1 2])', All_lines(grp2, [3 4])','b','LineWidth',2);
    %plot(All_lines(grp3, [1 2])', All_lines(grp3, [3 4])','b','LineWidth',2);
    if saveIm == 1
        print(['/Users/namdar/Desktop/vp_VP4/', imgname],'-dpng','-r200')
    end
   
     f1 = figure;
    title(num2str(imgname))
    hold on;
    axis ij;
    if plotVis == 0
        set(f1, 'visible', 'off');
    end
    plot(vpHor(1), vpHor(2), 'r*','MarkerSize',10)
    plot(vpVer(1), vpVer(2), 'g*','MarkerSize',10)
    imagesc(img);
    [y,x] = find(W1);
    plot(x,y, 'm.','MarkerSize',1);
    [y,x] = find(W2);
    plot(x,y, 'g.','MarkerSize',1);
    [y,x] = find(W3);
    plot(x,y, 'b.','MarkerSize',1);
    %plot(All_lines(grp1, [1 2])', All_lines(grp1, [3 4])','r');
    %plot(All_lines(grp2, [1 2])', All_lines(grp2, [3 4])','g');
    %plot(All_lines(grp3, [1 2])', All_lines(grp3, [3 4])','b');
    xlim([min(vpVer(1)-100, 0), max(vpVer(1)+100, 1280)]);
    %plot(All_lines(grp1, [1 2])', All_lines(grp1, [3 4])','b','LineWidth',2);
    %plot(All_lines(grp2, [1 2])', All_lines(grp2, [3 4])','b','LineWidth',2);
    %plot(All_lines(grp3, [1 2])', All_lines(grp3, [3 4])','b','LineWidth',2);
    if saveIm == 1
        print(['/Users/namdar/Desktop/vpShown_VP4/', imgname],'-dpng','-r200')
    end
   
    
end


disp(['Zoomed In = ', num2str(zoomedIn)])


return


%{
        figure
    imagesc(img);hold on;
plot(Xpnts(:,1),Xpnts(:,2), '*');
xlim([-4000,4000]);ylim([-1000,2000])
plot(vpVer(:,1),vpVer(:,2), 'k*','MarkerSize',10)
plot(vpHor(:,1),vpHor(:,2), 'k*','MarkerSize',10)
%}

%{
        figure
        imagesc(img)
axis ij
xlim([0 1280])
ylim([0 720])
hold on
    
for ii = 5:5
        plot(All_lines(ii, 1:2), All_lines(ii, 3:4))
        %plot(lines(ii, 1:2), lines(ii, 3:4))
        plot(verLines(ii, 1:2), All_lines(ii, 3:4),'LineWidth', 10)
end

%}

%{
figure
imagesc(img)
hold on
t = linspace(0,pi*2);
x = params(3) * cos(t);
y = params(4) * sin(t);
nx = x*cos(params(5))-y*sin(params(5)) + params(1);
ny = x*sin(params(5))+y*cos(params(5)) + params(2);

plot(nx,ny,'r-', 'LineWidth',3)


%}


%{


figure
drawedgelist(newEdgeList, size(img), 1, 'rand', 3); axis off
hold on;
plot(edges(idx==1,2),edges(idx==1,1), 'r*')

plot(edges(idx==2,2),edges(idx==2,1), 'g*')

plot(C(:,2),C(:,1), 'r+')






%}

