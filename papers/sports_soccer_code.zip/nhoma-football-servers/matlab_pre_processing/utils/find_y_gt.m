function y_gt = find_y_gt(H, vpVerLines, vpHorLines, field_wid, field_h,im)
% this function finds ray numbers corresponding to the ground truth y
%output: yGT = the ground truth labels. a 1*4 matrix


%% find the projection of the sidelines from the model to the image
H_inv = inv(H);
s = getFieldStruct(0, field_wid, field_h);

model_pts = [s.points(:,1),s.points(:,3),ones(17,1),s.points(:,2),s.points(:,4),ones(17,1)];
model_pts = model_pts([1,7,8,17],:);

img_pts = [model_pts(:, 1:3); model_pts(:, 4:6)]*H_inv';
img_pts = hnormalise(img_pts);
img_pts = img_pts(:,1:2);

% rows 1,2,3,4 correspond to y3, y4, y1, y2 respectively
% and each row is of the format [x1, y1, x2, y2]
img_pts = [img_pts(1:4,:), img_pts(5:8,:)];
% rearrange so that we have y1,y2,y3,y4
img_pts = img_pts([3,4,1,2],:);

%{
figure
imagesc(im); hold on; axis ij;
ind = 2
plot(img_pts(ind,[1,3]),img_pts(ind,[2,4]), 'r','LineWidth',1);

%}

%%
y_gt = zeros(1,4);


for ii=1:4
    minArea = Inf;
    L = img_pts(ii,:); %[x1, y1, x2, y2]
    p1 = L([1,2]);
    p2 = L([3,4]);
    
    [p1, p2] = restrict_line_to_image(p1, p2, 1280,720);
    
    if ii==1 || ii==2
        vpLines = vpHorLines;
    else
        vpLines = vpVerLines;
    end
    
    for jj = 1:size(vpLines, 1)
        
        L2 = vpLines(jj,:);
        d1 = dot([p1, 1], L2)/sqrt(sum(p1.^2)); % distance from endpoint of L to ray L2
        d2 = dot([p2, 1], L2)/sqrt(sum(p2.^2));
        
        if d1*d2 < 0 % the annoted line segment intersects the ray
            
            xpt = cross(L(1:3), L2);
            xpt = xpt(1:2)/xpt(3);
            
            % use pythagoreas
            base1 = sqrt(norm(p1-xpt)^2-d1^2);
            base2 = sqrt(norm(p2-xpt)^2-d2^2);
            
            totArea = abs(d1)*base1/2+abs(d2)*base2/2;
            
        else % have to find the area of a trapezoid
            
            h = norm(p1-p2);
            
            totArea = h*(abs(d1)+abs(d2))/2;
            
        end
        
        if totArea < minArea
            y_gt(ii) = jj;
            minArea = totArea;
        end
        
        
    end
    
    disp(['min = ', num2str(minArea), ', y_gt(ii)= ', num2str(y_gt(ii))])

end


end


%{
col = 'r';
style = '--';
l_size = 1;
doPause = 0;
%figure;
plotVanishingGridAnnotatedData(vpHorLines([200],:),...
    vpVerLines([],:),doPause, im, ...
    col, style, l_size);
%}
