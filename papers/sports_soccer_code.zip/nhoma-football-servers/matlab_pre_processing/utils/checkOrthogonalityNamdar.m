function [orthoCheck] =  checkOrthogonalityNamdar(vp1, vp2s, thresh)




vpUp = [0,1];

% the vector passing through vp1 and vp2s
vpLine = repmat(vp1, size(vp2s,1),1) - vp2s;
vpLine = vpLine./repmat(sqrt(sum(vpLine.^2,2)),1,2);


orthoScore = abs(dot(repmat(vpUp, size(vpLine, 1),1), vpLine,2));

orthoCheck = find(orthoScore < thresh);









end

