function plot_lines_on_im(im, lines)


figure
imagesc(im)
axis ij
xlim([0 size(im,2)])
ylim([0 size(im,1)])
hold on


for ii = 1:size(lines,1)
    
    plot(lines(ii, 1:2), lines(ii, 3:4), 'r','LineWidth',3)
    
end



end