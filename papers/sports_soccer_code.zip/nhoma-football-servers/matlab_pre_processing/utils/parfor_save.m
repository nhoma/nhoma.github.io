function parfor_save(data_dir, split, im_name,...
            vpVer, vpHor, A_grass, A_non_grass, vpHorLines, vpVerLines, ...
            A_hor_lines, A_ver_lines, Y, T_hor, T_ver, TE1, TE2, ...
            A_ellipse, A_circle, y_gt, fieldAccum, nonFieldAccum, H)

disp('Saving')
vpVer = vpVer';
vpHor = vpHor';
save([data_dir, split,filesep, im_name,'.','vpVer'] , 'vpVer', '-ascii')
save([data_dir, split,filesep, im_name,'.','vpHor'] , 'vpHor', '-ascii')


% grass and non-grass accumulators
save([data_dir, split,filesep, im_name,'.','grassAccum'] , 'A_grass', '-ascii')
save([data_dir, split,filesep, im_name,'.','nonGrassAccum'] , 'A_non_grass', '-ascii')


% save the equations of the lines from the vanishing points
save([data_dir, split,filesep, im_name,'.','vpHorLines'] , 'vpHorLines', '-ascii')
save([data_dir, split,filesep, im_name,'.','vpVerLines'] , 'vpVerLines', '-ascii')

% accumulators for line accumulators
save([data_dir, split,filesep, im_name,'.','vpHorLinesAccum'] , 'A_hor_lines', '-ascii')
save([data_dir, split,filesep, im_name,'.','vpVerLinesAccum'] , 'A_ver_lines', '-ascii')

%
temp = [Y.y1, Y.y2, Y.y3, Y.y4]; % corresponds to T B L R
save([data_dir, split,filesep, im_name,'.','initialTblr'] , 'temp', '-ascii')


% cross ratio tensors for lines
tempT1 =  T_hor(Y.y1(1):Y.y1(2), Y.y2(1):Y.y2(2),:);
tempT1 = reshape(tempT1, [Y.y1(2)-Y.y1(1)+1, (Y.y2(2)-Y.y2(1)+1)*4]);

tempT2 =  T_ver(Y.y3(1):Y.y3(2), Y.y4(1):Y.y4(2),:);
tempT2 = reshape(tempT2, [Y.y3(2)-Y.y3(1)+1, (Y.y4(2)-Y.y4(1)+1)*5]);

save([data_dir, split,filesep, im_name,'.','horLinesCR'] , 'tempT1', '-ascii')
save([data_dir, split,filesep, im_name,'.','verLinesCR'] , 'tempT2', '-ascii')

% cross ratio tensors for ellipse
tempT1 =  TE1(Y.y1(1):Y.y1(2), Y.y2(1):Y.y2(2),:);
tempT1 = reshape(tempT1, [Y.y1(2)-Y.y1(1)+1, (Y.y2(2)-Y.y2(1)+1)*4]);

tempT2 =  TE2(Y.y3(1):Y.y3(2), Y.y4(1):Y.y4(2),:);
tempT2 = reshape(tempT2, [Y.y3(2)-Y.y3(1)+1, (Y.y4(2)-Y.y4(1)+1)*8]);

save([data_dir, split,filesep, im_name,'.','horEllipsisCR'] , 'tempT1', '-ascii')
save([data_dir, split,filesep, im_name,'.','verEllipsisCR'] , 'tempT2', '-ascii')

% ellipse accumulator
save([data_dir, split,filesep, im_name,'.','ellipsisAccum'] , 'A_ellipse', '-ascii')

% ellipse accumulator
save([data_dir, split,filesep, im_name,'.','circleAccum'] , 'A_circle', '-ascii')

% save the ground truth labels
save([data_dir, split,filesep, im_name,'.','labelsGT'] , 'y_gt', '-ascii')

% save field and non-field accumulators
save([data_dir, split,filesep, im_name,'.','fieldAccum'] , 'fieldAccum', '-ascii')
save([data_dir, split,filesep, im_name,'.','nonFieldAccum'] , 'nonFieldAccum', '-ascii')

% save the true homography
save([data_dir, split,filesep, im_name,'.','homographyMatrix'] , 'H', '-ascii')


end