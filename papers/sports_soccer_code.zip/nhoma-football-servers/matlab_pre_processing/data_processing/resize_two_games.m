%% This script resized the images for two games from 712*1280 to 720*1280

data_folder = '/Users/namdar/Projects/Football/Data/';
all_imgs_path = [data_folder, 'SelectedFrames/'];
games = {'germany_ghana', 'germany_portugal'};



%%
for ii = 1:2
    
    img_folder = [all_imgs_path, games{ii}];
    
   % remove .DS_store from input folder
    system(['rm ', img_folder,'/.DS_Store']);
    
    all_files = dir( img_folder );
    all_files = { all_files(~[all_files.isdir]).name };
    
    for jj = 1:length(all_files)

        img = imread([img_folder, filesep,all_files{jj}]);
        img = imresize(img, [720,1280]);
        imwrite(img,[img_folder, filesep,all_files{jj}]);
    end

    
end