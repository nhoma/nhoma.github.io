% This script splits the annotated images into train/val and test and
% copies them into the data folder.
% the train and validation images are randomly reshuffled as well
% Moreover, we rename the images to start from 1 to num_images in each set.
% the homography matrix from the image to the model will be saved as
% #.homographyMatrix

%% Paths
data_folder = '/Users/namdar/Projects/Football/Data/';
all_imgs_path = [data_folder, 'SelectedFrames/'];
all_annots_path = [data_folder, 'annotations/'];
all_grass_path = [data_folder, 'annotations_grass/'];

%% The split should have an equal number of games with shadows
games = {'brazil_croatia',...
    'brazil_germany', ...
    'brazil_holland', ...
    'brazil_mexico', ...
    'england_italy', ...
    'england_uruguay', ...
    'germany_argentina', ...
    'germany_usa', ...
    'holland_argentina', ...
    'spain_chilli', ...
    'spain_holland', ...
    'swiss_france', ...
    'cro_mex', ...
    'germany_ghana'};

% games with shadows
games_shadow ={ 'argentina_belgium',...
    'germany_portugal',...
    'argentina_iran',...
    'argentina_swiss',...
    'columbia_ivory',...
    'france_germany'};

%%
% randomly split the games into two groups of train/val and test

%% set seed
rng(1366);

%% Randomly split the games into train/val and test
games_inds = 1:length(games);
games_sh_inds = 1:length(games_shadow);

train_val_inds = datasample(games_inds, length(games_inds)/2,'Replace', false);
train_val_games = games(train_val_inds);
test_games = games(setdiff(games_inds, train_val_inds));


train_val_sh_inds = datasample(games_sh_inds, length(games_sh_inds)/2,'Replace', false);
train_val_sh_games = games_shadow(train_val_sh_inds);
test_sh_games = games_shadow(setdiff(games_sh_inds, train_val_sh_inds));



%% Now merge the two togehter

train_val_games = [train_val_games, train_val_sh_games];
test_games = [test_games, test_sh_games];


%% get the number of images in each set of games
train_val_img_paths = {};
train_val_annot_paths = {};
train_val_grass_paths = {};

for ii = 1:length(train_val_games)
    game_name = train_val_games{ii};
    
    img_folder = [all_imgs_path, game_name];
    annot_folder = [all_annots_path, game_name];
    annot_grass_folder = [all_grass_path, game_name];
    
    % remove .DS_store from input folder
    system(['rm ', img_folder,'/.DS_Store']);
    
    all_files = dir( img_folder );
    all_files = { all_files(~[all_files.isdir]).name };
    
    
    for jj = 1:length(all_files)
        [~,img_name] = fileparts(all_files{jj});
        train_val_img_paths{end+1} = [img_folder, filesep,all_files{jj}];
        train_val_annot_paths{end+1} = [annot_folder, filesep,img_name, '.mat'];
        train_val_grass_paths{end+1} = [annot_grass_folder, filesep,img_name, '.mat'];
    end
    
    %system(['rm ', annotPNGFolderName,'/.DS_Store']);
end


disp(['Number of train/val images: ', num2str(length(unique(train_val_img_paths)))])
disp('Train/val games: ');
disp(train_val_games');


%{ 
DO NOT SPLIT HERE
% shuffle the train/val paths for randomness

inds = datasample(1:length(train_val_img_paths),length(train_val_img_paths),...
    'Replace', false);

% split the train and validation sets

num_val = floor(length(inds)/5);

val_img_paths = train_val_img_paths(1:num_val);
val_annot_paths = train_val_annot_paths(1:num_val);
val_grass_paths = train_val_grass_paths(1:num_val);

train_img_paths = train_val_img_paths(num_val+1:end);
train_annot_paths = train_val_annot_paths(num_val+1:end);
train_grass_paths = train_val_grass_paths(num_val+1:end);
%}


%% get the number of images in each set of games
test_img_paths = {};
test_annot_paths = {};
test_grass_paths = {};

for ii = 1:length(test_games)
    game_name = test_games{ii};
    
    img_folder = [all_imgs_path, game_name];
    annot_folder = [all_annots_path, game_name];
    annot_grass_folder = [all_grass_path, game_name];
    
    % remove .DS_store from input folder
    system(['rm ', img_folder,'/.DS_Store']);
    
    all_files = dir( img_folder );
    all_files = { all_files(~[all_files.isdir]).name };
    
    
    for jj = 1:length(all_files)
        
        [~,img_name] = fileparts(all_files{jj});
        test_img_paths{end+1} = [img_folder, filesep,all_files{jj}];
        test_annot_paths{end+1} = [annot_folder, filesep, img_name, '.mat'];
        test_grass_paths{end+1} = [annot_grass_folder, filesep, img_name, '.mat'];
    end
    
    %system(['rm ', annotPNGFolderName,'/.DS_Store']);
end


disp(['Number of test images: ', num2str(length(unique(test_img_paths)))])
disp('Test games: ');
disp(test_games');


%% Now rename and move the files

%% write the annotated training images



disp('Beginning to copy: ...')


for ii=1:2
    
    %%
    if ii == 1
        img_paths = train_val_img_paths;
        annot_paths = train_val_annot_paths;
        grass_paths = train_val_grass_paths;
        output_folder = [data_folder, 'train_val/'];
        mkdir(output_folder)
    elseif ii == 2
        img_paths = test_img_paths;
        annot_paths = test_annot_paths;
        grass_paths = test_grass_paths;
        output_folder = [data_folder, 'test/'];
        mkdir(output_folder)
    end
    
    %%    
    for jj = 1:length(img_paths)
        
        
        %copy the images
        comm = ['cp ', img_paths{jj}, ' ', output_folder, num2str(jj), '.jpg'];
        system(comm);
        
        % copy the homography annotations
        
        load(annot_paths{jj});
        H = annot.hom;
        
        save([output_folder,num2str(jj),'.','homographyMatrix'] , 'H', '-ascii')
        
        % copy the grass annotations
        
        load(grass_paths{jj});
        grass = annot.grass;
        
        save([output_folder,num2str(jj),'_grass_gt.mat'], 'grass' )
        
        
    end
    
end

disp('Done copying.')




