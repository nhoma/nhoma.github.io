% This script finds the homography for images reversed along the line
% x = 1280/2
%%
clear all;
close all;


%%
field_wid = 114.83;
field_h = 74.37;
field_r = 10;

w = 1280;
h = 720;
data_dir = '/ais/gobi4/namdar/soccer/data/cvpr/raw/train_val/';
data_out_dir = '/ais/gobi4/namdar/soccer/data/cvpr/train_val/';

%%
% H_rev takes the image to its reversed along x = w/2
H_rev = [-1, 0, w; 0, 1, 0; 0,0,1];
H_rev_inv = H_rev; % it would be the same as H_rev
% our new H would be H_orig*H_rev^{-1}
H_rev_model = [-1, 0, field_wid; 0, 1, 0; 0,0,1];



%%
img_names = dir([data_dir, '/*.jpg']);
img_names = {img_names.name};

%%
for ii = 1:length(img_names)
    
    %% 
    im_name = img_names{ii};
    im_name = im_name(1:end-4);
    disp([num2str(ii), '/', num2str(length(img_names)),': ',im_name])
    
    im_rev_name = [im_name, '_rev'];
    
    H_orig = load([data_dir, im_name,'.homographyMatrix']);
    
    H = H_orig*H_rev_inv; 
    H = H_rev_model*H;
    % have to save H
    save([data_out_dir, im_rev_name,'.homographyMatrix'] , 'H', '-ascii')
    
    %%
    
    
    %% For debugging
    if 1 ==0
        %%
        H_inv = inv(H);
        im = imread([data_out_dir, im_rev_name, '.jpg']);
        imagesc(im)
        
        s = getFieldStruct(0, field_wid, field_h);
        
        model_pts = [s.points(:,1),s.points(:,3),ones(17,1),s.points(:,2),s.points(:,4),ones(17,1)];
        inds = 4:7;
        model_pts = model_pts(inds,:);
        
        plot_lines = 1;
        if plot_lines == 1
            imagesc(im);
            hold on;
        end    
        for jj = 1:length(inds)

            img_pts = [model_pts(jj, 1:3); model_pts(jj, 4:6)]*H_inv';
            img_pts = hnormalise(img_pts);
            img_pts = img_pts(:,1:2); 
            if plot_lines == 1
                plot(img_pts(:,1),img_pts(:,2), 'r', 'LineWidth',2);
            end
        end
        
        
        s = getFieldStruct(0, field_wid, field_h);
        
        model_pts = [s.points(:,1),s.points(:,3),ones(17,1),s.points(:,2),s.points(:,4),ones(17,1)];
        inds = 8:10;
        model_pts = model_pts(inds,:);
        
        
        for jj = 1:length(inds)
            
            img_pts = [model_pts(jj, 1:3); model_pts(jj, 4:6)]*H_inv';
            img_pts = hnormalise(img_pts);
            img_pts = img_pts(:,1:2);
            

            if plot_lines == 1
                plot(img_pts(:,1),img_pts(:,2), 'r','LineWidth',1);
            end
        end

        
        
    end
    

end



