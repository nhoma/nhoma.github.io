% This script creates a tensor of size [w, h] for each image where the
% entry [ii, jj] is the semantic label kk of the the (ii,jj) pixel and
% which is a number in {0..6,7..16,17..19,20,21,22}
% where the indices 0 to 6 correspond to the vertical lines, the indices 
% 7 to 17 correspond to the horizontal lines,
% indices 17, 18 and 19 to the ellipses from left to right
% indice 20 to the corners
% indice 21 to the grass
% indice 22 to non-grass
 
%%
clear all;


%% Model dimenstins

field_wid = 114.83;
field_h = 74.37;
field_r = 10;

%% paths
data_folder = '/Users/namdar/Projects/Football/Data/';

% output folder for the segmentations
seg_out_folder = '/Users/namdar/Projects/Football/Data/segmentation_all_lines/';

 

%% some hyperparamters 

% dilation threshold for the lines in the image
dilation_thresh = 7;

%% read the images and the homographies

for split = {'train_val', 'test'}
    
    %split = {'train_val'};
    
    %%
    all_files = dir( [data_folder, split{1}, filesep, '*.jpg'] );
    all_files = {all_files.name};
    
    output_folder = [seg_out_folder, split{1}, filesep];
    mkdir([seg_out_folder, split{1}])
    
    %% for displaying purposes
    iter = 0;
    
    %%
    for im_name = all_files
        
        %%
        iter = iter+1;
        %im_name = all_files(1)
        
        %%
        [~, im_num] = fileparts(im_name{1});
        disp(['split = ', split{1}, ', image =' , num2str(iter), '/' num2str(length(all_files)) ])
        
        im = imread([data_folder, split{1}, filesep, im_num,'.jpg']);
        H = load([data_folder, split{1}, filesep, im_num,'.homographyMatrix']);
        H_inv = inv(H);
        
        grass = load([data_folder, split{1}, filesep, im_num,'_grass_gt.mat']);
        grass = grass.grass;
        
        
        
        %%
        
        im_size = size(im);
        
        %labels = uint8(zeros([im_size(1:2),5]));
        
        % map the homography from the model to the image
        
        % create a matrix where each entry is a number between 1 to 4
        % 1 = vertical lines, 2 = horizontal lines, 3 = ellipses, 4 = corners, 5 = grass, 6 = background
        
        
        s = getFieldStruct(0, field_wid, field_h);
        
        model_pts = [s.points(:,1),s.points(:,3),ones(17,1),s.points(:,2),s.points(:,4),ones(17,1)];
        
        %% define a tensor of size heightxwidthx22
        labels = uint8(zeros([im_size(1:2),22]));
        %% map the vertical lines
        
        
        
        plot_lines = 0;
        if plot_lines == 1
            imagesc(im);
            hold on;
        end
        
        %%
        ver = zeros(im_size(1:2));
        for ii = 1:7
            
            img_pts = [model_pts(ii, 1:3); model_pts(ii, 4:6)]*H_inv';
            img_pts = hnormalise(img_pts);
            img_pts = img_pts(:,1:2);
            
            labels(:,:,ii) = drawLineInMatrix(labels(:,:,ii), img_pts(1,:), img_pts(2,:));
            ver = drawLineInMatrix(ver, img_pts(1,:), img_pts(2,:));
            if plot_lines == 1
                plot(img_pts(:,1),img_pts(:,2), 'LineWidth',1);
            end
        end
        
        
        % map the horizontal lines
        
        
        hor = zeros(im_size(1:2));
        for ii = 8:17
            
            img_pts = [model_pts(ii, 1:3); model_pts(ii, 4:6)]*H_inv';
            img_pts = hnormalise(img_pts);
            img_pts = img_pts(:,1:2);
            
            labels(:,:,ii) = drawLineInMatrix(labels(:,:,ii), img_pts(1,:), img_pts(2,:));
            hor = drawLineInMatrix(hor, img_pts(1,:), img_pts(2,:));
            if plot_lines == 1
                plot(img_pts(:,1),img_pts(:,2), 'LineWidth',1);
            end
        end
        
        
        
        %% draw the ellipses
        
        ell = zeros(im_size(1:2));
        
        for ii = 1:3
            
            if ii == 1
                ell_spacing = 200;
                alpha = acos(6/field_r);
                % left circle
                t = linspace(-alpha, alpha, ell_spacing);
                xt = 12+ field_r*cos(t);
                yt = field_h/2 + field_r*sin(t);
            elseif ii == 2
                ell_spacing = 1000;
                t = linspace(0, 2*pi, ell_spacing);
                xt = field_wid/2+field_r*cos(t);
                yt = field_h/2+field_r*sin(t);                
            elseif ii == 3
                ell_spacing = 200;
                alpha = acos(6/field_r);
                t = linspace(pi-alpha, pi+alpha, ell_spacing);
                xt = field_wid - 12 + field_r*cos(t);
                yt = field_h/2 + field_r*sin(t);
            end
            
            img_pts = [xt',yt', ones(length(xt),1)];
            img_pts = img_pts*H_inv';
            img_pts = hnormalise(img_pts);
            
            for jj = 1:ell_spacing-1
                
                labels(:,:, ii+17) = drawLineInMatrix(labels(:,:,ii+17), img_pts(jj,:), img_pts(jj+1,:));
                ell = drawLineInMatrix(ell, img_pts(jj,:), img_pts(jj+1,:));
                if plot_lines == 1
                    plot(img_pts(:,1),img_pts(:,2), 'LineWidth',1);
                end
            end
            
            
        end
        
        
        %% now dilate the line maps and place them in the labels tensor
        % ver lines
        ver = imdilate(ver, strel('disk',dilation_thresh));
        
        
        % hor lines
        hor = imdilate(hor, strel('disk',dilation_thresh));
        
        
        % ellipse lines
        ell = imdilate(ell, strel('disk',dilation_thresh));
        
        
        
        for ii=1:20
           labels(:,:,ii) = imdilate(labels(:,:,ii), strel('disk',dilation_thresh));
        end
        
        %%
%{
        figure; imagesc(im);
        hold on;
        for ii=1:20
           imagesc(labels(:,:,ii));
           pause
        end
%}
        
        

        
        
        %% Assign the intersection of the lines as a new channel
        corners = zeros(im_size(1:2));
        corners(ver+hor > 1) = 1;
        corners(ell+ver > 1) = 1;
        

        %% Now save the labels as a matrix of size width*height where each entry
        % coressponds to the class of the object
        
        gt_mask = uint8(zeros(im_size(1:2)));
        
        %% First place the grass
        gt_mask(logical(grass) > 0) = 22;
        
        %% place non-grass now

        gt_mask(logical(grass) == 0) = 23;
        
        %% now place the lines and ellipses
        for ii=1:20
            gt_mask(logical(labels(:,:,ii)) > 0) = ii;
        end
        
        %% now overlay the corners
        
        gt_mask(logical(corners)> 0) = 21;
        
        %%
        % subtract 1 from each label so that the indices start from 0
        gt_mask = gt_mask - 1;
        %figure;imagesc(gt_mask)
        
        %%
        imwrite(im ,[output_folder, im_num, '.jpg'], 'Quality', 100)
        save([output_folder, im_num, '_seg.mat'], 'gt_mask');
        
        
        %% Now reverse each image and its segmentatiom mask and save them
        
        im_rev = fliplr(im);
        %imagesc(im_rev)
        gt_mask = fliplr(gt_mask);
        %imagesc(gt_mask_rev)
        
        % save
        imwrite(im_rev ,[output_folder, im_num, '_rev.jpg'], 'Quality', 100)
        save([output_folder, im_num, '_rev_seg.mat'], 'gt_mask');

        
    end
    
end


%% Now that we have all the images and the masks 















%imagesc(gt_mask)

%%
%{
figure; imagesc(im);
hold on;
imagesc(background, 'AlphaData',0.3)
%}

%%
%{
imagesc(ver)
imagesc(hor)
imagesc(ell)
imagesc(corners)
imagesc(grass)
imagesc(background)

temp = ver | hor | ell | corners;
figure; imagesc(im);
hold on;
imagesc(temp, 'AlphaData',0.3)
%}
%%
%{
dilation_thresh = 7;
temp2 = imdilate(temp, strel('disk',dilation_thresh));

figure; imagesc(im);
hold on;
imagesc(temp2, 'AlphaData',0.3)
%}

%%

