% This script find the midpoints of the sidelins and saves them in the
% order of L,T,R,B


%% Clear and close


clear all;
close all;


%% directories


data_dir = '/ais/gobi4/namdar/soccer/data/cvpr/';


train_dir = [data_dir, 'train_val/'];
test_dir = [data_dir, 'test/'];

%%
train_names = dir([train_dir, '/*.jpg']);
train_names = {train_names.name};

test_names = dir([test_dir, '/*.jpg']);
test_names = {test_names.name};





%%
% get the structure of the model field

% corners from the model. Rows 8 and 17 correspond to the upper and lower
% sidelines
field_wid = 114.83;
field_h = 74.37;

% get the structure of the model field
s = getFieldStruct(0, field_wid, field_h);

%%
% corners from the model. Rows 8 and 17 correspond to the upper and lower
% sidelines
points_model = [(s.points(8,1)+s.points(8,2))/2,s.points(8,3);...
    s.points(8,2),(s.points(8,3)+s.points(17,4))/2;...
    (s.points(8,1)+s.points(8,2))/2,s.points(17,3);...
    s.points(8,1),(s.points(8,3)+s.points(17,4))/2];

points_model = [points_model, ones(4,1)];
%plot(points_model(:,1),points_model(:,2), 'r*')


%%

%parpool(30)

%%
%save_figures = 1;
%set_invisible = 1;
%%
save_results = 0;

%%
for ii=1



for exper = exps
    
    %%
    try
        %%
        results_path = [exp_dir, exper{1}, filesep split{1}];
        feat_path = [data_dir, feat_split{1}, filesep];
        out_folder = [exp_dir, exper{1}, filesep split{1},'_plots/'];
        mkdir(out_folder);
        
        
        %% get the order of the predictions
        fid = fopen([results_path, '_fileNames.txt']);
        fileNames = textscan(fid,'%s');
        fclose(fid);
        
        fileNames = fileNames{1};
        
        %%
        % read the predictions
        
        preds = load([results_path, '_preds.dat']);
        
        % arrange the files in descending order based on theor IOU
        IOU = load([results_path, '_iou.dat']);
        energy = load([results_path, '_energy.dat']);
        iterations = load([results_path, '_iterations.dat']);
        [~, indIOU] = sort(IOU, 'descend');
        
        fileNames = fileNames(indIOU);
        preds = preds(indIOU,:);
        IOU = IOU(indIOU);
        energy = energy(indIOU);
        iterations = iterations(indIOU);
        
        %%
        numImg = length(fileNames);
        
        %% get modelo information
        field_wid = 200;
        field_h = 85;
        scale = 1;
        corner = 28;
        
        % get the structure of the model field
        P = get_hockey_field(scale,0);

        
        % corners from the model. Rows 8 and 17 correspond to the upper and lower
        % sidelines
        points_model = [P(8,1)-corner,P(8,2);...
            P(8,3)+corner,P(8,4);...
            P(9,3)+corner,P(9,4);...
            P(9,1)-corner,P(9,2)];
        
        
        
        %% transform P for homography transformation
        
        modelPoints = [P(:,1),P(:,2),ones(9,1),P(:,3),P(:,4),ones(9,1)];
        modelPoints = [modelPoints(1:9,1:3);modelPoints(1:9,4:6)];
        
        
        imgPoints = [];
        
        %%
        
        parfor ii = 1:numImg
            %%
            %ii=1
            %ii = 407
            disp([exper{1}, ' ,Image ', num2str(ii), ' out of ', num2str(numImg)])
            
            [~,imgName,~] = fileparts(fileNames{ii});
            disp(fileNames{ii})
            
            %imgName = 'period1_40733'
            
            im = imread([feat_path, imgName, '.jpg']);
            
            %imagesc(im)
            
            vpHorLines = load([feat_path, imgName, '.vpHorLines']);
            vpVerLines = load([feat_path, imgName, '.vpVerLines']);
            
            % open the true homography matrix
            H = load([feat_path, imgName, '.homographyMatrix']);
            
            %%
            predY = preds(ii,:);
            

            L_top = vpHorLines(predY(1),:);
            L_bottom = vpHorLines(predY(2),:);
            L_left = vpVerLines(predY(3),:);
            L_right = vpVerLines(predY(4),:);
            
            %{
            plotABCLine(L_top,1280, 720, 'r' )
            plotABCLine(L_bottom,1280, 720, 'r' )
            plotABCLine(L_left,1280, 720, 'r' )
            plotABCLine(L_right,1280, 720, 'r' )
            xlim([-3000,3000])
            ylim([-1000,1000])
            %}
            % corners have the format top-left, top-right, bottom-right, bottom-left
            corners_field = cross([L_top; L_top; L_bottom; L_bottom], [L_left; L_right;...
                L_right; L_left]);
            corners_field = hnormalise(corners_field);
            corners_field = corners_field(:,1:2);

            % create a transformation matrix
            tform = fitgeotrans(corners_field, points_model, 'Projective');
                        
            points_image = [corners_field, ones(size(corners_field,1),1)];
            
            
            %%% apply a homography to the image points
            
            points_transformed = tform.T'* points_image';
            points_transformed = hnormalise(points_transformed');
            
            % convert the transformed points into a plottable format
            points_transformed = changePointsFormat(points_transformed);
            
            %%%
            xWorldLimits = [-field_wid/2,field_wid/2];
            yWorldLimits = [-field_h/2, field_h/2];
            
            
            R = imref2d([720, 1280], xWorldLimits, yWorldLimits);
            
            [B, BI] = imwarp(im, tform, 'cubic','OutputView',R, 'FillValues', 255);
            
            %% get the transformation of model points to image
            imgPoints = modelPoints*inv(tform.T);          
            imgPoints = imgPoints(:,1:2)./repmat(imgPoints(:,3),1,2);            
            imgPoints = [imgPoints(1:9,:),imgPoints(10:18,:)];
            imgPoints = [imgPoints(:,1),imgPoints(:,3),imgPoints(:,2),imgPoints(:,4)];
            
            
            %% Plotting
            
            
            
            
            f1 = figure;
            %subplot(1,2,1)
            if set_invisible == 1
                set(f1, 'visible', 'off');
            end
            imshow(B,BI);
            

            col = 'm';
            style = '-';
            l_size = 3;
            

            hold on;
            
            for jj =1:9
                plot([P(jj, 1), P(jj, 3)], [P(jj, 2), P(jj, 4)], ...
                    col, 'LineWidth', l_size, 'LineStyle', style);
            end
            
            
            xlim([-field_wid/2, field_wid/2]);
            ylim([-field_h/2, field_h/2]);
            %set(gca, 'XAxisLocation', 'top')
            %set(gca, 'TickDir', 'out')
            
            %axis off
            
            title([imgName, ' ,IOU= '  num2str(IOU(ii)), ' ,energy= '  num2str(energy(ii)),...
                ' ,iter= '  num2str(iterations(ii))])
            
            % for saving the file in original dimensions
            %set(f1,'InvertHardcopy','on');
            %set(f1,'PaperUnits', 'inches');
            
            %set(f1, 'Position',[440, 378, 560, 420])
            %pbaspect([1280/720,1,1])
            %%
            if save_figures == 1
                %print([out_folder, num2str(ii),'_Model'],'-dpng', '-r200')
                print([out_folder, num2str(ii),'_Model'],'-dpng', '-r0')
            end

            
            %% using the estiamted homography, we project the model lines on 
            % the image. Then we reproject these lines back on the model
            % using the true homography

            f4 = figure; hold on
            %subplot(1,2,1)
            if set_invisible == 1
                set(f4, 'visible', 'off');
            end

            axis ij;
            
            back_points = modelPoints*inv(tform.T)*H;          
            back_points = back_points(:,1:2)./repmat(back_points(:,3),1,2);            
            back_points = [back_points(1:9,:),back_points(10:18,:)];
            back_points = [back_points(:,1),back_points(:,3),back_points(:,2),back_points(:,4)];
            
            col = 'b';
            %col = 'k';
            style = '-';
            l_size = 3;
            
            hold on;
            
            for jj =1:9
                plot([back_points(jj, 1), back_points(jj, 2)], [back_points(jj, 3), back_points(jj, 4)], ...
                    col, 'LineWidth', l_size, 'LineStyle', style);
                %disp(jj)
                %pause
            end
            
            min_x = min([back_points(:,1);back_points(:,2)]);
            max_x = max([back_points(:,1);back_points(:,2)]);
            min_y = min([back_points(:,3);back_points(:,4)]);
            max_y = min([back_points(:,3);back_points(:,4)]);
            
            % plot the model
            col = 'm';
            style = '-';
            l_size = 3;
            
            hold on;
            
            for jj =1:9
                plot([P(jj, 1), P(jj, 3)], [P(jj, 2), P(jj, 4)], ...
                    col, 'LineWidth', l_size, 'LineStyle', style);
            end

            
            title([imgName, ' ,IOU= '  num2str(IOU(ii)), ' ,energy= '  num2str(energy(ii)),...
                ' ,iter= '  num2str(iterations(ii))])

            
            %%
            if save_figures == 1
                %print([out_folder, num2str(ii),'_Model_2'],'-dpng', '-r200')
                print([out_folder, num2str(ii),'_Model_2'],'-dpng', '-r0')
            end
            %% Plot the image
            
            f2 = figure;
            %set(f2, 'Position',[440, 378, 560, 420])
            % Do not display the output image
            if set_invisible == 1
                set(f2, 'visible', 'off');
            end
            
            %h1 =subplot(1,2,1);
            %imshow(im, 'Xdata',[0, field_wid],'Ydata', [0, field_h]);
            %subplot(1,2,2)
            
            imagesc(im)
            pbaspect([1280/720,1,1])
            
            
            col = 'y';
            %col = 'k';
            style = '-';
            l_size = 3;
            
            hold on;
            
            for jj =1:9
                plot([imgPoints(jj, 1), imgPoints(jj, 2)], [imgPoints(jj, 3), imgPoints(jj, 4)], ...
                    col, 'LineWidth', l_size, 'LineStyle', style);
                %disp(jj)
                %pause
            end
            
            
            axis off
            
            % for saving the file in original dimensions
            %set(f2,'InvertHardcopy','on');
            %set(f2,'PaperUnits', 'inches');
            
            %savefigure([dataDir, 'videoFrames/', imgName])
            title([imgName, ' ,IOU= '  num2str(IOU(ii)), ' ,energy= '  num2str(energy(ii)),...
                ' ,iter= '  num2str(iterations(ii))])
            
            if save_figures == 1
                print([out_folder, num2str(ii),'_img'],'-dpng', '-r200')
            end
            %% close all the figures
            
            close all;
            
            
        end
        
        %% plot histograms
        f = figure('units','pixels','Position',[0 0 1200 700]);
        if set_invisible == 1
            set(f, 'visible', 'off');
        end
        subplot(1,3,1)
        hist(IOU)
        title([split{1}, ' IOU'])
        
        
        
        subplot(1,3,2)
        hist(iterations)
        title([split{1}, ' Iterations'])
        
        subplot(1,3,3)
        hist(energy)
        title([split{1} ' energy'])
        
        if save_figures == 1
            %print([out_folder, 'histogram'],'-dpng', '-r200')
            print([out_folder, 'histogram'],'-dpng', '-r0')
        end
        
        close
        
    catch
        warning('Something went wrong!')
    end
    
end



disp('DONE!')






















