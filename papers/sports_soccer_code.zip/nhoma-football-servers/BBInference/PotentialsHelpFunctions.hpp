//
//  PotentialsHelpFunctions.hpp
//  BranchAndBoundCpp
//
//  Created by Namdar  on 2015-10-20.
//  Copyright © 2015 Namdar . All rights reserved.
//

#ifndef PotentialsHelpFunctions_hpp
#define PotentialsHelpFunctions_hpp

#include <stdio.h>

#include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"


int accumLookUp(const arma::imat &accum, int top, int bottom, int left, int right);

arma::vec accumLookUpLines(const arma::imat &accum, arma::uvec &T, arma::uvec &B,
                           arma::uvec &L, arma::uvec &R);

int getRayPosFromCR(const arma::icube &rayPos, int rowNum, int colNum,
                    const arma::ivec &initialTblr, int lineNum);

int getRayPosFromCrEllipsis(const arma::icube &rayPos, int xx, int yy,
                            const arma::ivec &initialTblr, int lineNum);

#endif /* PotentialsHelpFunctions_hpp */
