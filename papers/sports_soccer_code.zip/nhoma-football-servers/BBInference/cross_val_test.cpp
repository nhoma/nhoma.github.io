#include <iostream>
// #include <armadillo>

// g++ test.cpp -o test -std=c++11 -Wall -I /u/namdar/soccer/Code/External/armadillo-6.200.3/include/ -lblas -llapack -fopenmp
#include <stdio.h>
#include<fstream>
#include<string.h>
#include <vector>
#include <math.h>



int main( int argc, const char** argv )
{
     

     
     int num_imgs = 17;
     int num_folds = 2;
     
     
     int val_size = round(num_imgs/double(num_folds));
     std::cout << "val size: " << val_size << std::endl;

     
     
     for (int kk=0; kk < num_folds; ++kk){
        
        std::cout << "fold " << kk+1 << std::endl;
        
        for(int ii=0; ii < val_size*kk; ++ii){
            std::cout << "train " << ii << std::endl;
        }

        for(int ii= val_size*kk; ii < val_size*(kk+1); ++ii){
            std::cout << "val " << ii << std::endl;
        }
        
        for(int ii= val_size*(kk + 1); ii < num_imgs; ++ii){
            
            if(kk == num_folds-1){
                std::cout << "val " << ii << std::endl; 
            }else{
                std::cout << "train " << ii << std::endl; 
            }

            
            
        }
        
        std::cout << " "  <<  std::endl;
     
     }
     
     
     
     
     /*
     std::ofstream fs;
     fs.open("123.txt");     
     fs.close();
     */
    
    
        
     
     return 0;
}