./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/G -e G &
./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GL -e GL &
./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/LE -e LE &

./CrossValidateC -r /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GLE -e GLE &

wait
echo "All jobs complete!"
