#ifndef Evaluate_hpp
#define Evaluate_hpp

#include <iostream>
#include <stdio.h>
#include "ImageFeat.hpp"
#include "BranchAndBoundInference.hpp"
#include <string>
#include <algorithm>
#include <dirent.h>
#include <fnmatch.h>
#include <vector>
#include <fstream>
#include "ReadDirectory.hpp"

#include "/ais/gobi4/namdar/soccer/Code/External/clipper/cpp/clipper.hpp" // http://www.angusj.com/delphi/clipper.php
#include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"

struct EvalOutput {
        double mean_energy;
        double med_energy;
        arma::vec energy;
        
        int mean_iter;
        int med_iter;
        arma::ivec iterations;
        
        double mean_time;
        double med_time;
        arma::vec time;
        
        double mean_iou;
        double med_iou;
        arma::vec iou;
        
        //double mean_iou_visible;
        //double med_iou_visible;
        //arma::vec iou_visible;

                
        arma::imat preds;
        std::vector<std::string> filenames;
                
};



EvalOutput evaluate(std::string data_dir, arma::vec w,
                std::string features, std::string pattern,  int gtAvailable);
double unionIntersectionMetric(arma::vec TL, arma::vec TR, arma::vec BR, arma::vec BL, arma::mat H);
double IOUVisibleImage(arma::vec TL, arma::vec TR, arma::vec BR, arma::vec BL, arma::mat H_inv);


#endif /* Evaluate_hpp */