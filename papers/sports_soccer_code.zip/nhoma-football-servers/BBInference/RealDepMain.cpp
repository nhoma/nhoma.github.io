#include "RealDepDemo.hpp"


int main(int argc, char** argv) {

//-r : where the required info are and results will be stored
//-i : where te images and features are
    
    
if(argc < 5){
    std::cout << "ERROR!! EXITING!! Have to pass some arguments. "
                << "Look at the code " << std::endl;
    exit(1);        
}



std::string baseDir("/u/namdar/soccer/Code/experiments3/");
std::string resultsDir(""); // e.g. exp2
std::string imgDir(""); // where the image features are stored. train/test/val

// parse the input arguments
for(int k=1;k<argc;++k) {
    if(::strcmp(argv[k], "-r")==0 && k+1!=argc) { // results folder
        resultsDir = argv[++k];
    }
    else if(::strcmp(argv[k], "-i")==0 && k+1!=argc) { // img folder, e.g. /u/namdar/soccer/Data/ValSet
        imgDir = argv[++k];
    }
    else{
        std::cout << "ERROR!! EXITING!! Wrong arguments " << std::endl;
    exit(1);        
    }
}
    
RealDepDemo(resultsDir, imgDir);

return 0;

}