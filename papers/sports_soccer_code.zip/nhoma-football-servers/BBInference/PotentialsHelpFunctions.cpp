//
//  PotentialsHelpFunctions.cpp
//  BranchAndBoundCpp
//
//  Created by Namdar  on 2015-10-20.
//  Copyright © 2015 Namdar . All rights reserved.
//

#include "PotentialsHelpFunctions.hpp"


int accumLookUp(const arma::imat &accum, int top, int bottom, int left, int right){
    
    int count;
    
    if( top >= bottom || left >=  right )
    {
        count = 0;
    }
    else
    {
        count = accum(bottom-1, right-1)+accum(top-1, left-1) -
        accum(bottom-1, left-1) - accum(top-1, right-1);
    }
    
    return count;
    
}



arma::vec accumLookUpLines(const arma::imat &accum, arma::uvec &T, arma::uvec &B,
                           arma::uvec &L, arma::uvec &R){
    
    arma::imat countsMat;
    
    countsMat = accum.submat(T-1, L-1) + accum.submat(B-1, R-1)
    - accum.submat(T-1, R-1) - accum.submat(B-1, L-1);
    
    arma::vec counts = arma::conv_to<arma::vec>::from(countsMat);
    
    return counts;
    
}





int getRayPosFromCR(const arma::icube &rayPos, int xx, int yy,
                    const arma::ivec &initialTblr, int lineNum){
    // get the ray number corresponding to a field line specified by lineNum
    // given that y1/y3 = xx and y2/y4 = yy.
    
    if(rayPos.n_slices == 4){ // vp1 Horizontal
        return rayPos(xx-initialTblr(0), yy-initialTblr(2), lineNum - 1);
    }
    else if (rayPos.n_slices == 5){ // vp2 Vertical
        return rayPos(xx-initialTblr(4), yy-initialTblr(6), lineNum - 1);
    }
    else{
        std::cout << "ERROR: the vpnum shoud be 1 or 2" << std::endl;
        return 1;
    }
    
    
}



int getRayPosFromCrEllipsis(const arma::icube &rayPos, int xx, int yy,
                            const arma::ivec &initialTblr, int lineNum){
    // get the ray number corresponding to a field line specified by lineNum
    // given that y1/y3 = xx and y2/y4 = yy.
    
    if(rayPos.n_slices == 4){ // vp1
        return rayPos(xx-initialTblr(0), yy-initialTblr(2), lineNum - 1);
    }
    else if (rayPos.n_slices == 8){ // vp2
        return rayPos(xx-initialTblr(4), yy-initialTblr(6), lineNum - 1);
    }
    else{
        std::cout << "ERROR: the vpnum shoud be 1 or 2" << std::endl;
        return 1;
    }
    
    
}
