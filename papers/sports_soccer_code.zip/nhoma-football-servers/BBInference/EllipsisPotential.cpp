//
//  EllipsisPotential.cpp
//  BranchAndBoundCpp
//
//  Created by Namdar  on 2015-10-26.
//  Copyright © 2015 Namdar . All rights reserved.
//

#include <stdio.h>
#include "Potentials.hpp"


void Potentials::SetEllipsis(ImageFeat &img, arma::ivec &tblr, arma::vec &ellipSign){
    
    const arma::imat &ellipsisAccum = img.GetEllipsisAccum();
    const arma::imat &circleAccum = img.GetCircleAccum();
    
    const arma::icube &horRayPosEllipsis = img.GetHorRayPosEllipsis();
    const arma::icube &verRayPosEllipsis = img.GetVerRayPosEllipsis();
    
    //
    const arma::icube &verRayPos = img.GetVerRayPos();
    
    
    //
    int nRow = ellipsisAccum.n_rows;
    int nCol = ellipsisAccum.n_cols;

    
    
    //
    int y1Min = tblr(0);
    int y1Max = tblr(1);
    
    int y2Min = tblr(2);
    int y2Max = tblr(3);
    
    int y3Min = tblr(4);
    int y3Max = tblr(5);
    
    int y4Min = tblr(6);
    int y4Max = tblr(7);
    
    
    //
    
    const arma::ivec &initialTblr = img.GetInitialTblr();

    // initialize the ellipsis
    
    m_ellipsis.zeros(3);
    
    int TMin, TMax, BMin, BMax, LMin, LMax, RMin, RMax;
    
    ///////////////// left circle
    if( ellipSign(0) > 0 ){ // positive weight
    
        // Circle on the left of the field
        TMin = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Min, y2Min, initialTblr, 1);
        TMax = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Max, y2Max, initialTblr, 2);
        if(TMin > TMax){ //correction: want to make the hypothesis as big as possible
            TMin = TMax;
        }
                
        BMin = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Min, y2Min, initialTblr, 3);
        BMax = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Max, y2Max, initialTblr, 4);
        if(BMin > BMax){ //correction: want to make the hypothesis as big as possible
            BMax = BMin;
        }
        
        LMin = getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 2);
        LMax = getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 2);
        if(LMin > LMax){ //correction: want to make the hypothesis as big as possible
            LMin = LMax;
        }
        
        RMin = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Min, y4Min, initialTblr, 1);
        RMax = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Max, y4Max, initialTblr, 2);
        if(RMin > RMax){ //correction: want to make the hypothesis as big as possible
            RMax = RMin;
        }
    
        
        m_ellipsis(0) = accumLookUp(ellipsisAccum, TMin, BMax, LMin, RMax) -
                            accumLookUp(ellipsisAccum, TMax, BMin, LMax, RMin);
        
    }
    else{
    
    // Circle on the left of the field
        TMin = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Max, y2Max, initialTblr, 1);
        TMax = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Min, y2Min, initialTblr, 2);
        if(TMin > TMax){ //correction: want to make the hypothesis as small as possible
            TMax = TMin;
        }

        BMin = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Max, y2Max, initialTblr, 3);
        BMax = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Min, y2Min, initialTblr, 4);
        if(BMin > BMax){ //correction: want to make the hypothesis as small as possible
            BMin = BMax;
        }
               
        LMin = getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 2);
        LMax = getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 2);
       if(LMin > LMax){ //correction: want to make the hypothesis as small as possible
            LMax = LMin;
        }
     
        RMin = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Max, y4Max, initialTblr, 1);
        RMax = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Min, y4Min, initialTblr, 2);
        if(RMin > RMax){ //correction: want to make the hypothesis as small as possible
            RMin = RMax;
        }
        
        m_ellipsis(0) = accumLookUp(ellipsisAccum, TMin, BMax, LMin, RMax) -
                            accumLookUp(ellipsisAccum, TMax, BMin, LMax, RMin);
      
    }
    
    if( ellipsisAccum(nRow-1, nCol-1) > 0){
        //m_ellipsis(0) = double(m_ellipsis(0))/(ellipsisAccum(nRow-1, nCol-1)+circleAccum(nRow-1, nCol-1));
        m_ellipsis(0) = double(m_ellipsis(0))/ellipsisAccum(nRow-1, nCol-1);
    }
    else{
        m_ellipsis(0) = 0;
    }

    
    
    ////////////////// MIDDLE CIRCLE    
    if( ellipSign(1) > 0 ){ // positive weight
        
        // Circle in the middle of the field
        
        TMin = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Min, y2Min, initialTblr, 1);
        TMax = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Max, y2Max, initialTblr, 2);
        if(TMin > TMax){ //correction: want to make the hypothesis as big as possible
            TMin = TMax;
        }

        BMin = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Min, y2Min, initialTblr, 3);
        BMax = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Max, y2Max, initialTblr, 4);
        if(BMin > BMax){ //correction: want to make the hypothesis as big as possible
            BMax = BMin;
        }
               
        LMin = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Min, y4Min, initialTblr, 3);
        LMax = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Max, y4Max, initialTblr, 4);
        if(LMin > LMax){ //correction: want to make the hypothesis as big as possible
            LMin = LMax;
        }
        
                
        RMin = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Min, y4Min, initialTblr, 5);
        RMax = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Max, y4Max, initialTblr, 6);
        if(RMin > RMax){ //correction: want to make the hypothesis as big as possible
            RMax = RMin;
        }
                        
        m_ellipsis(1) = accumLookUp(circleAccum, TMin, BMax, LMin, RMax) -
                accumLookUp(circleAccum, TMax, BMin, LMax, RMin);
        
    }
    else{
     
     // Circle in the middle of the field
        
        TMin = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Max, y2Max, initialTblr, 1);
        TMax = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Min, y2Min, initialTblr, 2);
        if(TMin > TMax){ //correction: want to make the hypothesis as small as possible
            TMax = TMin;
        }
        
        BMin = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Max, y2Max, initialTblr, 3);
        BMax = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Min, y2Min, initialTblr, 4);
        if(BMin > BMax){ //correction: want to make the hypothesis as small as possible
            BMin = BMax;
        }
                
        LMin = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Max, y4Max, initialTblr, 3);
        LMax = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Min, y4Min, initialTblr, 4);
        if(LMin > LMax){ //correction: want to make the hypothesis as small as possible
            LMax = LMin;
        }
                
        RMin = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Max, y4Max, initialTblr, 5);
        RMax = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Min, y4Min, initialTblr, 6);
        if(RMin > RMax){ //correction: want to make the hypothesis as small as possible
            RMin = RMax;
        }
                
        m_ellipsis(1) = accumLookUp(circleAccum, TMin, BMax, LMin, RMax) -
                accumLookUp(circleAccum, TMax, BMin, LMax, RMin);
       
    }
    if( circleAccum(nRow-1, nCol-1) > 0){
        //m_ellipsis(1) = double(m_ellipsis(1))/(ellipsisAccum(nRow-1, nCol-1)+circleAccum(nRow-1, nCol-1));
        m_ellipsis(1) = double(m_ellipsis(1))/circleAccum(nRow-1, nCol-1);
    }
    else{
        m_ellipsis(1) = 0;
    }

    
    
    ///////// Right Circle         
    if( ellipSign(2) > 0 ){ // positive weight
        // Circle in the right of the field
    
        
        TMin = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Min, y2Min, initialTblr, 1);
        TMax = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Max, y2Max, initialTblr, 2);
        if(TMin > TMax){ //correction: want to make the hypothesis as big as possible
            TMin = TMax;
        }

           
        BMin = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Min, y2Min, initialTblr, 3);
        BMax = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Max, y2Max, initialTblr, 4);
        if(BMin > BMax){ //correction: want to make the hypothesis as big as possible
            BMax = BMin;
        }
                
        LMin = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Min, y4Min, initialTblr, 7);
        LMax = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Max, y4Max, initialTblr, 8);
        if(LMin > LMax){ //correction: want to make the hypothesis as big as possible
            LMin = LMax;
        }
        
        RMin = getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 4);
        RMax = getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 4);
        if(RMin > RMax){ //correction: want to make the hypothesis as big as possible
            RMax = RMin;
        }
    
        m_ellipsis(2) = accumLookUp(ellipsisAccum, TMin, BMax, LMin, RMax) -
            accumLookUp(ellipsisAccum, TMax, BMin, LMax, RMin);
    }
    else{ // negative weights
        
        
        // Circle in the right of the field
    
        
        TMin = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Max, y2Max, initialTblr, 1);
        TMax = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Min, y2Min, initialTblr, 2);
        if(TMin > TMax){ //correction: want to make the hypothesis as small as possible
            TMax = TMin;
        }
        
        BMin = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Max, y2Max, initialTblr, 3);
        BMax = getRayPosFromCrEllipsis(horRayPosEllipsis, y1Min, y2Min, initialTblr, 4);
        if(BMin > BMax){ //correction: want to make the hypothesis as small as possible
            BMin = BMax;
        }
                
        LMin = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Max, y4Max, initialTblr, 7);
        LMax = getRayPosFromCrEllipsis(verRayPosEllipsis, y3Min, y4Min, initialTblr, 8);
        if(LMin > LMax){ //correction: want to make the hypothesis as small as possible
            LMax = LMin;
        }
        
        RMin = getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 4);
        RMax = getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 4);
        if(RMin > RMax){ //correction: want to make the hypothesis as small as possible
            RMin = RMax;
        }
            
        m_ellipsis(2) = accumLookUp(ellipsisAccum, TMin, BMax, LMin, RMax) -
            accumLookUp(ellipsisAccum, TMax, BMin, LMax, RMin);    
    }
    if( ellipsisAccum(nRow-1, nCol-1) > 0){
        //m_ellipsis(2) = double(m_ellipsis(2))/(ellipsisAccum(nRow-1, nCol-1)+circleAccum(nRow-1, nCol-1));
        m_ellipsis(2) = double(m_ellipsis(2))/ellipsisAccum(nRow-1, nCol-1);
    }
    else{
        m_ellipsis(2) = 0;
    }
    
    
    //std::cout<< "m_ellipsis: " << std::endl;
    //std::cout<< m_ellipsis << std::endl;
    
    //std::cout<< "total: " << std::endl;
    //std::cout<< circleAccum(nRow-1, nCol-1) << std::endl;
    
}





