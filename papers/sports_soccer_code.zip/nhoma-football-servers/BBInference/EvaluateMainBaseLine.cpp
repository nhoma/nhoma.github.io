#include "EvaluateBaseLine.hpp"


int main(int argc, char** argv) {

//-r : where the required info are and results will be stored
//-i : where te images and features are
    
    
std::string data_dir("/u/namdar/soccer/data/cvpr/test");
std::string resultsDir("/u/namdar/soccer/data/cvpr/soccer_results/final/baseline");
EvalOutput eval_out;


        
eval_out = evaluate(data_dir, "cornersField",  1);

std::ofstream fid;
fid.open (resultsDir + "/" + "field_results.txt");
fid << "mean_iou, " << eval_out.mean_iou << std::endl;
fid << "med_iou, " << eval_out.med_iou;
fid.close();



eval_out = evaluate(data_dir, "cornersBw",  1);
std::ofstream fid2;
fid2.open (resultsDir + "/" + "bw_results.txt");
fid2 << "mean_iou, " << eval_out.mean_iou << std::endl;
fid2 << "med_iou, " << eval_out.med_iou;
fid2.close();

return 0;

}