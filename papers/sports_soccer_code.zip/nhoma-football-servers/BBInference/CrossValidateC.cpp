#include "CrossValidateC.hpp"


// g++ CrossValidateC.cpp -o CrossValidateC -std=c++11 -Wall 


int main(int argc, char** argv)
{
// -e : specifies the features ,e.g. GLE
// -r : specifies the results directory, e.g. /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GLE
// -c: particular value of C
// -s: save results

/*
if(argc < 5){
    std::cout << "ERROR!! EXITING!! Have to pass some arguments. "
                << "Look at the code " << std::endl;
    exit(1);        
}
*/


std::string features("");
std::string resultsDir("");
arma::vec C;
int CProvided = 0;
int performTest = 1; // do inference on test set
bool save_results = 1;

// parse the input arguments
for(int k=1;k<argc;++k) {
    if(::strcmp(argv[k], "-r")==0 && k+1!=argc) { // 
        resultsDir = argv[++k];
    } else if(::strcmp(argv[k], "-e")==0 && k+1!=argc) {
        features = argv[++k];
    }
    else if(::strcmp(argv[k], "-c")==0 && k+1!=argc) {
        C = {std::atof(argv[++k])};
        CProvided = 1;
    }
    else if(::strcmp(argv[k], "-t")==0 && k+1!=argc) {
        performTest = std::atoi(argv[++k]);        
    }
    else if(::strcmp(argv[k], "-s")==0 && k+1!=argc) {
        save_results = std::atoi(argv[++k]);        
    }

    else{
        std::cout << "ERROR!! EXITING!! Wrong arguments " << std::endl;
    exit(1);        
    }
}

// make the directory corresponding to the resultsDir
std::string comm("");
comm = comm + "mkdir " + resultsDir;
std::system(comm.c_str());



int numFeatures;
// get the number of features
if( features.compare("G") == 0){
    //numFeatures = 2;
    numFeatures = 4;
}
else if( features.compare("GL") == 0 ){
    numFeatures = 5;
}//
else if( features.compare("GLE") == 0 ){
    numFeatures = 6;
}
else if( features.compare("GVerLHorL") == 0 ){
    numFeatures = 6;
}
else if( features.compare("GVerLHorLE") == 0 ){
    numFeatures = 7;
}
else if( features.compare("GVerLVerMVerRHorLE") == 0 ){
    numFeatures = 7;
}
else if( features.compare("GVerLHorLE1E2E3") == 0 ){
    
    numFeatures = 9;
}
else if( features.compare("LE") == 0 ){
    numFeatures = 2;
}
else if( features.compare("GVerLVerMVerRHorLE1E2E3") == 0 ){
    numFeatures = 11;
}
else if( features.compare("GVerAllHorLE1E2E3") == 0 ){
    numFeatures = 13;
}
else if( features.compare("GVerSymHorLESym") == 0 ){
    numFeatures = 9;
}
else if( features.compare("GVerSymHorSymESym") == 0 ){
    numFeatures = 14;
}
else if( features.compare("GVerAllHorAllEAll") == 0 ){
    numFeatures = 22;
}
else if( features.compare("GVerLHorLEInteraction") == 0 ){
    numFeatures = 8;
}
else{
    std::cout << "ERROR!! EXITING. THE -e argument NOT SPECIFIED PROPERLY"<< std::endl;
    exit(1);
}



// hyper parematers
int num_folds = 6; // numeber of cross validation folds
std::string train_str("");
//train_str = train_str+features;
std::string val_str("");
//val_str = val_str+features;


// data directory
std::string data_dir("/u/namdar/soccer/data/cvpr/train_val");
//std::string data_dir("/u/namdar/soccer/data/cvpr/playing");

// read all the image files in the img directory. save their paths
std::string pattern = "*.jpg";
std::vector<std::string> fileNames;
TraverseDirectory(data_dir, pattern, fileNames,1);
int num_imgs = fileNames.size();

// shuffle the filenames and set a seed
std::mt19937 randEng;
randEng.seed(15112016);
std::shuffle(fileNames.begin(), fileNames.end(), randEng);


// remove the jpg from the end of fileNames
for(int ii=0; ii< num_imgs; ++ii){
    fileNames[ii] = fileNames[ii].substr(0,fileNames[ii].find_last_of("."));
    //std::cout << fileNames[ii] << std::endl;
}



int val_size = floor(num_imgs/double(num_folds));
std::cout << "validation size: " << val_size << std::endl;



// set up the arguments to pass to learnSSVM
InputData inp; 
inp.dir = "";
inp.OutputModel = "/u/namdar/soccer/Code/results/results"; // -o
inp.InputModel = NULL; // -m
inp.DataFile = NULL; // -f
inp.ItCounter = 0; // -n
inp.time = -1; // -t
inp.message = NULL; // -M
// stuff I change most of the time
inp.resultsDir = resultsDir; // -r e.g. /ais/gobi4/namdar/soccer/data/cvpr/soccer_results/exp1/GLE
inp.feat = features; // -e      e.g. GLE  
//inp.MaxIterations = 10; // -i        
inp.MaxIterations = 10; // -i   more iterations for GVerLVerMVerRHorLE1E2E3     
inp.pattern = "*." + train_str;     // pattern that is used to retrieve the training examples
inp.data_dir = data_dir;
//inp.num_threads = 12;
inp.num_threads = 12;



if(CProvided == 0){
    //C = {0.0625,0.1250, 0.2500,0.5000, 1.0, 2.0, 4.0, 8.0};
    //C = {0.0625,0.1250, 0.2500,0.5000, 1.0, 2.0, 4.0};
    //C = {0.2500,0.5000, 1.0, 2.0, 4.0, 8.0};
    C = {0.2500,0.5000, 1.0, 2.0, 4.0};
    //C = {1,2};
}

arma::mat fold_iou(num_folds, C.n_elem); // values of the iou obtained in cross validation
arma::rowvec fold_mean_iou(C.n_elem);
arma::rowvec fold_sd_iou(C.n_elem);
double best_C;

//int temp2;
arma::vec w;

EvalOutput eval_out;


MPI::Init(); // needed for Strutsvm

if( CProvided == 0){
    for(int ii=0; ii < C.n_elem; ++ii){
        
            
            // with argc and argv like main(int argc, char** argv). Here argv has 9 words. 
            
            // change the C value and run the 
            inp.C = C(ii);
    
    
    
            for (int kk=0; kk < num_folds; ++kk){
            //for (int kk=0; kk < 2; ++kk){
                
                inp.fold = kk+1;
                
                std::cout << "C = " << C(ii) << std::endl;
                std::cout << features << std::endl;   
                std::cout << "fold " << kk+1 << std::endl;
                
                // remove the previously create extensions
                
                comm = "rm -f " + data_dir + "/*." + train_str;
                std::system(comm.c_str());
                comm = "rm -f " + data_dir + "/*." + val_str;
                std::system(comm.c_str());
                
                train_str = "train_" + features+"_"+std::to_string(ii)+"_"+std::to_string(kk);
                std::cout << train_str << std::endl;
                val_str = "val_" + features +"_" +std::to_string(ii)+"_"+std::to_string(kk);
                std::cout << val_str << std::endl;
                
                inp.pattern = "*."+ train_str;                                

                
                
                
                ////////////////////////
                // create filenames with .trainX and .valX (X for features) for 
                // create train strings
                for(int ii=0; ii < val_size*kk; ++ii){
                    //std::cout << "train " << ii << std::endl;
                     std::ofstream fs;
                     fs.open(fileNames[ii] + "." + train_str);     
                     fs.close();
                }
                
                // create val strings
                for(int ii= val_size*kk; ii < val_size*(kk+1); ++ii){
                    //std::cout << "val " << ii << std::endl;
                     std::ofstream fs;         
                     fs.open(fileNames[ii]+ "." + val_str);     
                     fs.close();        
                }
                
                // create val or train strings
                for(int ii= val_size*(kk + 1); ii < num_imgs; ++ii){        
                    if(kk == num_folds-1){
                         //std::cout << "val " << ii << std::endl;
                         std::ofstream fs;
                         fs.open(fileNames[ii] + "." + val_str);     
                         fs.close();
                    }else{
                         //std::cout << "train " << ii << std::endl;
                         std::ofstream fs;
                         fs.open(fileNames[ii] + "." + train_str);     
                         fs.close();
                    }    
                }
                ///////////////////////
                
                // do learning
                w = learnSSVM(inp); 
                
                
                // get the meanIOU for validation set
                eval_out = evaluate(data_dir, w, features, "*."+val_str,  1);
    
            
                // save the result of the IOU        
                fold_iou(kk,ii) = eval_out.mean_iou;
                
            }
    }
    
    
    
    // choose the best C from cross validation and retrain the model on all of train and val
    fold_mean_iou = arma::mean(fold_iou, 0);
    fold_sd_iou = arma::stddev(fold_iou, 0);
    best_C = C(arma::index_max(fold_mean_iou));
    
    if( save_results == 1){
        // save the iou of cross validations
        fold_iou.save(resultsDir + "/" + "cv_iou.dat", arma::raw_ascii);
        fold_mean_iou.save(resultsDir + "/" + "cv_mean_iou.dat", arma::raw_ascii);
        fold_sd_iou.save(resultsDir + "/" + "cv_sd_iou.dat", arma::raw_ascii);
    }
}

// using the best value of C, retrain on whole train and validation set
if( CProvided == 0){
    inp.C = best_C;
}
else{
    inp.C = C(0);
}

inp.pattern = "*.jpg";
std::cout << "Training on the whole trainig and validation set:" << std::endl;
std::cout << "Best value of C: " << inp.C << std::endl;
w = learnSSVM(inp); 

// reevaluate the whole training set
eval_out = evaluate(data_dir, w, features, "*.jpg",  1);
//save the ious and the results

if( save_results == 1){
    eval_out.energy.save(resultsDir + "/" + "train_energy.dat", arma::raw_ascii);
    eval_out.iterations.save(resultsDir + "/" + "train_iterations.dat", arma::raw_ascii);
    eval_out.time.save(resultsDir + "/" + "train_time.dat", arma::raw_ascii);
    eval_out.iou.save(resultsDir + "/" + "train_iou.dat", arma::raw_ascii);
    //eval_out.iou_visible.save(resultsDir + "/" + "train_iou_visible.dat", arma::raw_ascii);
    eval_out.preds.save(resultsDir + "/" + "train_preds.dat", arma::raw_ascii);
    
    // save the img names in the order they appear

    std::ofstream fid2;
    fid2.open(resultsDir + "/" + "train_fileNames.txt");
    for(int ii=0; ii<eval_out.filenames.size(); ii++){
            fid2 << eval_out.filenames[ii] << std::endl;
    }
    fid2.close();

    // save the experiment name in the exp directory
    std::ofstream fid4;
    fid4.open (resultsDir + "/" + "train_results.txt");
    fid4 << "best_C, " << best_C << std::endl;
    fid4 << "mean_energy, " << eval_out.mean_energy << std::endl;
    fid4 << "med_energy, " << eval_out.med_energy << std::endl;
    fid4 << "mean_iter, " << eval_out.mean_iter << std::endl;
    fid4 << "med_iter, " << eval_out.med_iter << std::endl;
    fid4 << "mean_time, " << eval_out.mean_time << std::endl;
    fid4 << "med_time, " << eval_out.med_time << std::endl;
    fid4 << "mean_iou, " << eval_out.mean_iou << std::endl;
    fid4 << "med_iou, " << eval_out.med_iou;
    //fid4 << "mean_iou_visible, " << eval_out.mean_iou_visible << std::endl;
    //fid4 << "med_iou_visible, " << eval_out.med_iou_visible;

    fid4.close();
}




/////////////////////////////////////// test set
// apply the results to the test set
//data_dir have to change to test set
data_dir = "/u/namdar/soccer/data/cvpr/test";
eval_out = evaluate(data_dir, w, features, "*.jpg",  1);

//////////// save the results of test set


// save the experiment name in the exp directory
if( save_results == 1){
    std::ofstream fid;
    fid.open (resultsDir + "/" + "features.txt");
    fid << features;
    fid.close();
    
    fid.open (resultsDir + "/" + "test_results.txt");
    fid << "best_C, " << best_C << std::endl;
    fid << "mean_energy, " << eval_out.mean_energy << std::endl;
    fid << "med_energy, " << eval_out.med_energy << std::endl;
    fid << "mean_iter, " << eval_out.mean_iter << std::endl;
    fid << "med_iter, " << eval_out.med_iter << std::endl;
    fid << "mean_time, " << eval_out.mean_time << std::endl;
    fid << "med_time, " << eval_out.med_time << std::endl;
    fid << "mean_iou, " << eval_out.mean_iou << std::endl;
    fid << "med_iou, " << eval_out.med_iou;
    //fid << "mean_iou_visible, " << eval_out.mean_iou_visible << std::endl;
    //fid << "med_iou_visible, " << eval_out.med_iou_visible;

    fid.close();
    
    
    eval_out.energy.save(resultsDir + "/" + "test_energy.dat", arma::raw_ascii);
    eval_out.iterations.save(resultsDir + "/" + "test_iterations.dat", arma::raw_ascii);
    eval_out.time.save(resultsDir + "/" + "test_time.dat", arma::raw_ascii);
    eval_out.iou.save(resultsDir + "/" + "test_iou.dat", arma::raw_ascii);
    //eval_out.iou_visible.save(resultsDir + "/" + "test_iou_visible.dat", arma::raw_ascii);
    eval_out.preds.save(resultsDir + "/" + "test_preds.dat", arma::raw_ascii);
    
    // save the best weight
    w.save(resultsDir + "/" + "best_w.dat", arma::raw_ascii);
    
    // save the img names in the order they appear
    std::ofstream fid3;
    fid3.open(resultsDir + "/" + "test_fileNames.txt");
    for(int ii=0; ii<eval_out.filenames.size(); ii++){
            fid3 << eval_out.filenames[ii] << std::endl;
    }
    fid3.close();
}


MPI::Finalize(); // needed for Strutsvm
return 0;
}
