#ifndef CrossValidateC_hpp
#define CrossValidateC_hpp

#include <iostream>
#include <stdio.h>
#include <string>
#include <algorithm>
#include <cstdlib>
#include<fstream>
#include <cstdlib>
#include <random>


#include <mpi.h>

#include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"
#include "StructSVMCPnSlack.hpp"
#include "Evaluate.hpp"
#include "ReadDirectory.hpp"

#endif /* CrossValidateC_hpp */