//
//  Potentials.hpp
//  BranchAndBoundCpp
//
//  Created by Namdar  on 2015-10-20.
//  Copyright © 2015 Namdar . All rights reserved.
//

#ifndef Potentials_hpp
#define Potentials_hpp

#include <stdio.h>
#include "PotentialsHelpFunctions.hpp"
#include "ImageFeat.hpp"

#ifdef __APPLE__
#include <armadillo>
#else
#include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"
#endif

class Potentials{
    // This class contains
private:
    // THese are the values upper bounds for each potential
    arma::vec m_grass = arma::zeros<arma::vec>(4);
    arma::vec m_verLines = arma::zeros<arma::vec>(7);
    
    arma::vec m_horLines=arma::zeros<arma::vec>(10);
    
    // For  ellipsis. 3 dimensional
    arma::vec m_ellipsis = arma::zeros<arma::vec>(3);
    
    
public:
    
    Potentials(){}
    
    // Get Methods
    arma::vec GetGrass() const {return m_grass;}
    arma::vec GetVerLines() const { return m_verLines; }
    arma::vec GetHorLines() const { return m_horLines; }
    arma::vec GetEllipsis() const { return m_ellipsis; }
    
    // Set Grass potential
    void SetGrass(ImageFeat &img, arma::ivec &tblr, arma::vec &grassSign);
    // Set Lines potential
    void SetLines(ImageFeat &img, arma::ivec &tblr, arma::vec &verSign, arma::vec &horSign);
    // Set Ellipse potential
    void SetEllipsis(ImageFeat &img, arma::ivec &tblr, arma::vec &ellipSign);
    
    
};


#endif /* Potentials_hpp */
