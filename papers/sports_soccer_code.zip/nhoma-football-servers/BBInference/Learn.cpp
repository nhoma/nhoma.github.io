#include <string>
#include "StructSVMCPnSlack.hpp"
#include <mpi.h>



int main(int argc, char** argv) {


        InputData inp; 
        inp.dir = ""; 
        inp.OutputModel = "/u/namdar/soccer/Code/results/results"; // -o
        inp.InputModel = NULL; // -m
        inp.DataFile = NULL; // -f
        inp.MaxIterations = 100; // -i
        inp.ItCounter = 0; // -n
        inp.C = 1; // -c
        inp.time = -1; // -t
        
        inp.message = NULL; // -M
        inp.expDir = "exp"; // -r namdar added
        inp.feat = ""; // -e: a dictionary which defined what features are used
                                   // if not specified the program will exit.     
        
        ParseInput(argc, argv, inp);


        MPI::Init();

        learnSSVM(inp);
        
        MPI::Finalize();

        return 0;
}