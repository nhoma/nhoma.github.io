//
//  GrassPotential.cpp
//  BranchAndBoundCpp
//
//  Created by Namdar  on 2015-10-20.
//  Copyright © 2015 Namdar 
//

//#include <stdio.h>
#include "Potentials.hpp"


/////////////////////////////////////////////////////////////////


void Potentials::SetGrass(ImageFeat &img, arma::ivec &tblr, arma::vec &grassSign){
//input: w = I'm actually interested in the sign of w (= weight) 
// compute the grass potential
// (grassInside, nonGrassOutside, grassOutside, nonGrassInside)

    // create references matrices for grass and non-grass accumulators
    const arma::imat &grassAccum = img.GetGrassAccum();
    const arma::imat &nonGrassAccum = img.GetNonGrassAccum();

    //
    m_grass.zeros(4);

    // Total number of lines from each vanishing point which is the same as the
    // number of rows and cols of the accumulators
    int nRow = img.GetGrassAccum().n_rows;
    int nCol = img.GetNonGrassAccum().n_cols;
    
    
    
    // get total number of grass pixels and non-grass pixels
    double grassTotal = grassAccum(nRow - 1, nCol - 1);
    double nonGrassTotal = nonGrassAccum(nRow - 1, nCol - 1);
    
    // grass inside
    if( grassSign(0) > 0){ //postive weight
        double grassInside = accumLookUp(grassAccum, tblr(0), tblr(3),
                                      tblr(4), tblr(7));
        

        m_grass(0) = double(grassInside)/grassTotal;
        
    }
    else{ //nnegative weight
        double grassInside = accumLookUp(grassAccum, tblr(1), tblr(2),
                                      tblr(5), tblr(6));
        
        m_grass(0) = double(grassInside)/grassTotal;
    
    }


    // non-grass outside
    if( grassSign(1) > 0){ //postive weight
        double nonGrassOutside = nonGrassTotal -
                                            accumLookUp(nonGrassAccum, tblr(1),
                                                     tblr(2), tblr(5), tblr(6));

        m_grass(1) = double(nonGrassOutside)/nonGrassTotal;
        
    }
    else{ //negative weight
        double nonGrassOutside = nonGrassTotal -
                                            accumLookUp(nonGrassAccum, tblr(0),
                                                     tblr(3), tblr(4), tblr(7));

        m_grass(1) = double(nonGrassOutside)/nonGrassTotal;
    
    }

    
    
    // grass outside
    if( grassSign(2) > 0){ //postive weight
        double grassOutside = grassTotal -
                                        accumLookUp(grassAccum, tblr(1), tblr(2),
                                                      tblr(5), tblr(6));
                
        m_grass(2) = double(grassOutside)/grassTotal;
        
    }
    else{ //nnegative weight
        double grassOutside = grassTotal -
                                        accumLookUp(grassAccum, tblr(0), tblr(3),
                                                      tblr(4), tblr(7));
        
        m_grass(2) = double(grassOutside)/grassTotal;
    
    }


    // non-grass inside
    if( grassSign(3) > 0){ //postive weight
        double nonGrassInside = accumLookUp(nonGrassAccum, tblr(0),
                                                     tblr(3), tblr(4), tblr(7));

        m_grass(3) = double(nonGrassInside)/nonGrassTotal;
        
    }
    else{ //negative weight
        double nonGrassInside = accumLookUp(nonGrassAccum, tblr(1),
                                                     tblr(2), tblr(5), tblr(6));

        m_grass(3) = double(nonGrassInside)/nonGrassTotal;
    
    }
    
    
    /*
    std::cout << "Grass Potential: " << std::endl;
    std::cout << m_grass << std::endl;
    */
}



