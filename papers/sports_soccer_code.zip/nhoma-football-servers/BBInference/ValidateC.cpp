#include "ValidateC.hpp"



int main(int argc, char** argv)
{
// -e : specifies the features ,e.g. GLE
// -r : specifies the results directory, e.g. exp1
// -c: particular value of C

if(argc < 5){
    std::cout << "ERROR!! EXITING!! Have to pass some arguments. "
                << "Look at the code " << std::endl;
    exit(1);        
}


std::string features("");
std::string resultsDir("");
std::string baseDir("/u/namdar/soccer/Code/experiments4/");
arma::vec C;
int CProvided = 0;
int performTest = 0; // do inference on test set

// parse the input arguments
for(int k=1;k<argc;++k) {
    if(::strcmp(argv[k], "-r")==0 && k+1!=argc) { // 
        resultsDir = argv[++k];
    } else if(::strcmp(argv[k], "-e")==0 && k+1!=argc) {
        features = argv[++k];
    }
    else if(::strcmp(argv[k], "-c")==0 && k+1!=argc) {
        C = {std::atof(argv[++k])};
        CProvided = 1;
    }
    else if(::strcmp(argv[k], "-t")==0 && k+1!=argc) {
        performTest = std::atoi(argv[++k]);        
    }
    else{
        std::cout << "ERROR!! EXITING!! Wrong arguments " << std::endl;
    exit(1);        
    }
}

int numFeatures;
// get the number of features
if( features.compare("G") == 0){
    numFeatures = 4;
}
else if( features.compare("GL") == 0 ){
    numFeatures = 3;
}//
else if( features.compare("GLE") == 0 ){
    numFeatures = 4;
}
else if( features.compare("GVerLHorL") == 0 ){
    numFeatures = 4;
}
else if( features.compare("GVerLHorLE") == 0 ){
    numFeatures = 5;
}
else if( features.compare("GVerLVerMVerRHorLE") == 0 ){
    numFeatures = 7;
}
else if( features.compare("GVerLHorLE1E2E3") == 0 ){
    numFeatures = 7;
}
else if( features.compare("LE") == 0 ){
    numFeatures = 2;
}
else if( features.compare("GVerLVerMVerRHorLE1E2E3") == 0 ){
    numFeatures = 9;
}
else if( features.compare("GVerAllHorLE1E2E3") == 0 ){
    numFeatures = 13;
}
else if( features.compare("GVerSymHorLESym") == 0 ){
    numFeatures = 9;
}
else if( features.compare("GVerSymHorSymESym") == 0 ){
    numFeatures = 14;
}
else if( features.compare("GVerAllHorAllEAll") == 0 ){
    numFeatures = 22;
}
else if( features.compare("GVerLHorLEInteraction") == 0 ){
    numFeatures = 8;
}
else{
    std::cout << "ERROR!! EXITING. THE -e argument NOT SPECIFIED PROPERLY"<< std::endl;
    exit(1);
}

// set up the arguments to pass to learnSSVM
InputData inp; 
inp.dir = "";
inp.OutputModel = "/u/namdar/soccer/Code/results/results"; // -o
inp.InputModel = NULL; // -m
inp.DataFile = NULL; // -f
inp.ItCounter = 0; // -n
inp.time = -1; // -t
inp.message = NULL; // -M
// stuff I change most of the time
inp.expDir = resultsDir; // -r e.g. exp2
inp.feat = features; // -e      e.g. GLE  
//inp.MaxIterations = 10; // -i        
inp.MaxIterations = 20; // -i   more iterations for GVerLVerMVerRHorLE1E2E3     


// make a folder where the reuslts will be stored. It might already exist
std::string comm("");
comm = comm + "mkdir " + baseDir + resultsDir;
std::system(comm.c_str());
comm = "";

// save the experiment name in the exp directory
std::ofstream fid;
fid.open (baseDir + resultsDir + "/" + "features.txt");
fid << features;
fid.close();


//arma::vec C = { 1 , 3 };
//arma::vec C = { 0.001,0.005, 0.01,0.05,0.1,0.5,1, 1.5, 2, 2.5,3,3.5};
if(CProvided == 0){
    //C = {0.001, 0.005, 0.007, 0.0156,0.0312,0.0625,0.1250,
    //            0.2500,0.5000,1.0, 1.5, 2.0, 4.0, 8.0,10, 13, 16, 20,22,25,50,100};
    C = {0.001, 0.005, 0.007, 0.0156,0.0312,0.0625,0.1250,
                0.2500,0.5000,1.0, 1.5, 2.0, 4.0, 8.0,10, 13, 16};
}
//C = {8};
                
arma::mat validateWeights(C.n_elem, numFeatures);                
arma::vec validateIOU(C.n_elem);

arma::vec w;

arma::vec temp(1); // used for reading from files

int temp2;


MPI::Init(); // needed for Strutsvm

for(int ii=0; ii < C.n_elem; ++ii){

    std::cout << "C = " << C(ii) << std::endl;
    std::cout << features << C(ii) << std::endl;
    // with argc and argv like main(int argc, char** argv). Here argv has 9 words. 
    
    // change the C value and run the 
    inp.C = C(ii);
    temp2 = learnSSVM(inp); 
    
    //after learning the weights and saving it, read it;
    w.load(baseDir + resultsDir + "/" + "weights.dat");
    // save it to the matrix
    validateWeights.insert_rows(ii, w.t());
    
    // ssvm saves the weights in a file called weights.dat. Evaluate reads weights.dat
    // and features.txt and find the IOU for all images and mean IOU
    
    std::cout << "C = " << C(ii) << std::endl;
    std::cout << features << C(ii) << std::endl;
    
    if( performTest == 0){
        evaluate(resultsDir, "/u/namdar/soccer/Data/ValSet", 1);
    }
    else{
        evaluate(resultsDir, "/u/namdar/soccer/Data/TestSet", 1);
    }
    // read the mean IOU and save it to 
    
    temp.load(baseDir + resultsDir + "/" + "meanIOU.dat");
    validateIOU(ii) = temp(0);

}

MPI::Finalize(); // needed for Strutsvm


C.save(baseDir + resultsDir + "/" + "validateC.dat", arma::raw_ascii);
validateIOU.save(baseDir + resultsDir + "/" + "validateIOU.dat", arma::raw_ascii);
validateWeights.save(baseDir + resultsDir + "/" + "validateWeights.dat", arma::raw_ascii);




return 0;
}
