//
//  BranchAndBoundInference.hpp
//  BranchAndBoundCpp
//
//  Created by Namdar  on 2015-10-17.
//  Copyright © 2015 Namdar . All rights reserved.
//

#ifndef BranchAndBoundInference_hpp
#define BranchAndBoundInference_hpp

#include <stdio.h>
#include <queue>
#include <string.h>

#include "ImageFeat.hpp"
#include "RayIntervals.hpp"
#include "Potentials.hpp"
#include "InferenceLoss.hpp"

#include "Timer.h"

#ifdef __APPLE__
    #include <armadillo>
#else
        #include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"
#endif


struct BBOutput {
        double energy;
        int iterations;
        arma::ivec labeling;
        double time;
};


arma::ivec branchAndBoundInference(ImageFeat &img, arma::vec &w, std::string &experiment, int gtAvailable, std::string imgInfo);

BBOutput branchAndBoundInferenceMoreInfo(ImageFeat &img, arma::vec &w, std::string &experiment, int gtAvailable);

int branchAndBoundInference(ImageFeat &img, int gtAvailable);

double computeBound(ImageFeat &img, Potentials &pot, arma::ivec &tblr, arma::vec &w,
                InferenceLoss &loss, std::string &experiment, int gtAvailable);

#endif /* BranchAndBoundInference_hpp */
