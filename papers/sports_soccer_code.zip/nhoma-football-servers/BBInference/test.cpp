#include <iostream>
#include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"
//#include "/u/namdar/soccer/Code/External/armadillo-6.200.3/include/armadillo"
#include <cstdlib>

// g++ test.cpp -o test -std=c++11
// g++ test.cpp -o test -std=c++11 -L/ais/gobi4/namdar/soccer/Code/External/clipper/cpp -lpolyclipping
                                                                                          
// g++ test.cpp -o test -std=c++11 -Wall -I /u/namdar/soccer/Code/External/armadillo-7.400.4/include/ -lblas -llapack -fopenmp
// g++ test.cpp -o test -std=c++11 -Wall -lhdf5 -I /u/namdar/soccer/Code/External/armadillo-7.400.4/include/ -lblas -llapack -fopenmp 
#include <stdio.h>
#include<fstream>
#include<string.h>
#include <vector>
#include <math.h>

#include "/ais/gobi4/namdar/soccer/Code/External/clipper/cpp/clipper.hpp"
// http://www.angusj.com/delphi/clipper.php


using namespace ClipperLib;

//Paths subj;
//Paths clip;
Paths solution;

void addPoint(int x, int y, Path *path)
{
    IntPoint ip;
    ip.X = x;
    ip.Y = y;
    path->push_back(ip);
}




int main( int argc, const char** argv )
{
          
    Paths subj;
    
    Path p;
    addPoint(0,0, &p);
    addPoint(10,0, &p);
    addPoint(10,30, &p);
    addPoint(0,30, &p);
    addPoint(0,0, &p);
    subj.push_back(p);

    Paths clip;    
    Path p2;
    addPoint(0,0, &p2);
    addPoint(20,0, &p2);
    addPoint(20,30, &p2);
    addPoint(0,30, &p2);
    addPoint(0,0, &p2);
    clip.push_back(p2);
    
    Clipper c;
    
    c.AddPaths(subj, ptSubject, true);
    
    c.AddPaths(clip, ptClip, true);
    
    c.Execute(ctIntersection, solution, pftNonZero, pftNonZero);
    
    const Path temp= solution.at(0);
    
    double area = Area(solution.at(0));
    
    std::cout << "area: " << area << std::endl;
    
    printf("solution size = %d\n",(int)solution.size());
    for (unsigned i=0; i<solution.size(); i++)
    {
        Path p3 = solution.at(i);
        
        for (unsigned j=0; j<p3.size(); j++)
        {
            IntPoint ip = p3.at(j);
            printf("%d = %lld, %lld\n",j, ip.X,ip.Y);
        }
        
    }
    
    return 0;
}