#include "Evaluate.hpp"






EvalOutput evaluate(std::string data_dir, arma::vec w,
                std::string features, std::string pattern,  int gtAvailable){

// read all the image files in the img directory. save their paths

std::vector<std::string> fileNames;
TraverseDirectory(data_dir, pattern, fileNames,1);
int num_imgs = fileNames.size();

// remove the valX from the end of fileNames
for(int ii=0; ii< num_imgs; ++ii){
    fileNames[ii] = fileNames[ii].substr(0,fileNames[ii].find_last_of("."));
    //std::cout << fileNames[ii] << std::endl;
}



// add a zero to the end of w to correspond to loss potential
w.insert_rows(w.n_elem, arma::zeros(1));


// output of evaluation
EvalOutput eval_output;
eval_output.mean_iou = 0;
eval_output.med_iou = 0;
eval_output.iou.set_size(num_imgs);
//eval_output.iou_visible.set_size(num_imgs);
eval_output.filenames = fileNames;


// vector that holds the predictions
arma::ivec predY;
BBOutput output;



// create four vectors that will contain the TBLR lines. Each vector will be of
// the form [a;b;c] corresponding to ax+by+c = 0
arma::vec T;
arma::vec B;
arma::vec L;
arma::vec R;

arma::vec TL; // top left point
arma::vec TR; // top right point
arma::vec BR; // bottom right point
arma::vec BL; // bottom right point


arma::mat H; // homography matrix
arma::mat H_inv; // inverse homography matrix

arma::vec rect(4); // each row corresponds to x1,x2,y1,y2 which
                                // are the coordinates defining the rectangle
                                // of the projected field
              
// a vector containing the IOUs for all the images               
arma::vec IOU(num_imgs);
//arma::vec IOU_visible(num_imgs);

                                
// initialize the image info which will be used to read the image features
std::string imgInfo;

// holds all the predictions and gts for the images                              
arma::imat preds(num_imgs,4);
arma::imat gts(num_imgs, 4);                                
arma::vec time(num_imgs);
arma::vec energy(num_imgs);
arma::ivec iterations(num_imgs);

ImageFeat img;

std::string imgName;


// we have annotated gt or not
//int gtAvailable = 0; 
                                
for(int ii = 0; ii < num_imgs; ++ii){
        
        std::cout << "Image :" << ii+1 << "/" << num_imgs << std::endl;        
        
        
  
        // the path to an image  
        imgInfo = fileNames[ii];
      
                                    
        //ImageFeat img = ImageFeat(imgInfo,gtAvailable);
                
        img.assignData(imgInfo,gtAvailable);                
        
                                  
        // do branch and bound
        output = branchAndBoundInferenceMoreInfo(img, w, features, gtAvailable);
        
        predY = output.labeling;
        iterations(ii) = output.iterations;
        time(ii) = output.time;
        energy(ii) = output.energy;    
            
        if(1){ // display information
                std::cout << imgInfo << std::endl;        
                std::cout << "Prediction" << std::endl;
                std::cout << predY << std::endl;
                std::cout << "Truth" << std::endl;
                std::cout << img.GetYGT() << std::endl;
                std::cout << "------------" << std::endl;
                std::cout << "Time" << std::endl;
                std::cout << output.time << std::endl;
                std::cout << "------------" << std::endl;
                std::cout << "Iterations" << std::endl;
                std::cout << output.iterations << std::endl;
                std::cout << "------------" << std::endl;
        }
            
            
        for(int jj=0; jj <4; ++jj){
                preds(ii,jj) = predY(jj);
        }
            
            
        if(gtAvailable == 1){
                // save the prediction in preds
                for(int jj=0; jj <4; ++jj){
                        gts(ii, jj) = img.GetYGT()(jj);
                }
        
        
                // for testing let prediction equal GT
                // predY = img.GetYGT();
                // Now that I have the predictions, Let's find the intersection points of the lines
                
                T = img.GetSpecificHorLine(predY(0)-1); // have to add -1 for indexing issues
                B = img.GetSpecificHorLine(predY(1)-1);
                L = img.GetSpecificVerLine(predY(2)-1);
                R = img.GetSpecificVerLine(predY(3)-1);
                
                // now find the intersection points.
                // a rectangle can be specified by two x coordinate values and 2 y
                // cooridinate values
                TL = cross(T,L);
                TR = cross(T,R);
                BR = cross(B,R);
                BL = cross(B,L);
                
                TL = TL/TL(2);
                TR = TR/TR(2);
                BR = BR/BR(2);
                BL = BL/BL(2);
                
                
                                
                // load the homography matrix
                H.load(imgInfo+".homographyMatrix");
                //H_inv.load(imgInfo+".invHomographyMatrix");
                
                                            
                // intersection over union metric        
                IOU(ii) = unionIntersectionMetric(TL, TR, BR, BL, H);
                std::cout << "IOU" << std::endl;
                std::cout << IOU(ii) << std::endl;                
                
                /* iou visible
                IOU_visible(ii) = IOUVisibleImage(TL, TR, BR, BL,H);
                
                std::cout << "IOU VISIBLE: " << std::endl;
                std::cout << IOU_visible(ii) << std::endl;
                */


        }        
        
        
}


if(gtAvailable == 1){
        
        eval_output.iou = IOU;
        
        //arma::vec mean_iou(1); // used for writing to file
        
        // find mean IOU
        eval_output.mean_iou = arma::mean(IOU);
        std::cout <<  "Mean Interesction over Union = " << eval_output.mean_iou <<  std::endl;
        eval_output.med_iou = arma::median(IOU);
        std::cout <<  "Median Interesction over Union = " << eval_output.med_iou <<  std::endl;
        
        //eval_output.iou_visible = IOU_visible;        
        // find mean IOU
        //eval_output.mean_iou_visible = arma::mean(IOU_visible);
        //std::cout <<  "Mean Interesction over Union Visible = " << eval_output.mean_iou_visible <<  std::endl;
        
        //arma::vec med_iou(1); // used for writing to file
        //eval_output.med_iou_visible = arma::median(IOU_visible);
        //std::cout <<  "Median Interesction over Union Visible = " << eval_output.med_iou_visible <<  std::endl;

                
}



eval_output.preds = preds;

eval_output.mean_energy = arma::mean(energy);
eval_output.med_energy = arma::median(energy);
eval_output.energy = energy;

eval_output.mean_iter = arma::mean(iterations);
eval_output.med_iter = arma::median(iterations);
eval_output.iterations = iterations;

eval_output.mean_time = arma::mean(time);
eval_output.med_time = arma::median(time);
eval_output.time = time;


return eval_output;

}

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
using namespace ClipperLib;

void addPoint(int x, int y, Path *path)
{
    IntPoint ip;
    ip.X = x;
    ip.Y = y;
    path->push_back(ip);
}



double unionIntersectionMetric(arma::vec TL, arma::vec TR, arma::vec BR, arma::vec BL, arma::mat H){
// this function computes the intersection/union of a test image
// rect:corresponds to x1,x2,y1,y2 which
// are the coordinates defining the rectangle of the projected field

double score = 0;
double inter; //area of intersection
double uni; // area of union

//model cooridinates
double x1 = 0;
double x2 = 114.83;
double y1 = 0;
double y2 = 74.37;


// find the projection of these points on the model field. reassign them
// TL and BR
TL = H*TL;
TR = H*TR;                
BR = H*BR;
BL = H*BL;

// normalize the projected points
TL = TL/TL(2);
TR = TR/TR(2);
BR = BR/BR(2);
BL = BL/BL(2);


Paths truth;

Path p;
addPoint(x1, y1, &p);
addPoint(x2, y1, &p);
addPoint(x2, y2, &p);
addPoint(x1, y2, &p);
addPoint(x1, y1, &p);
truth.push_back(p);


Paths proj;

Path p2;
addPoint(TL(0), TL(1), &p2);
addPoint(TR(0), TR(1), &p2);
addPoint(BR(0), BR(1), &p2);
addPoint(BL(0), BL(1), &p2);
addPoint(TL(0), TL(1), &p2);
proj.push_back(p2);

Clipper c;

c.AddPaths(truth, ptSubject, true);
c.AddPaths(proj, ptClip, true);

Paths inter_path;
Paths uni_path;
c.Execute(ctIntersection, inter_path, pftNonZero, pftNonZero);
c.Execute(ctUnion, uni_path, pftNonZero, pftNonZero);

inter = Area(inter_path.at(0));
uni = Area(uni_path.at(0));
//std::cout << inter << std::endl;


//std::cout << uni << std::endl;

score = inter/uni;

return score;

}




double IOUVisibleImage(arma::vec TL, arma::vec TR, arma::vec BR, arma::vec BL,
                                arma::mat H){
// this function computes the intersection/union of the visible parrt of the field
// rect:corresponds to x1,x2,y1,y2 which
// are the coordinates defining the rectangle of the projected field


double score = 0;
double inter; //area of intersection
double uni; // area of union

//model cooridinates
double x1 = 0;
double x2 = 114.83;
double y1 = 0;
double y2 = 74.37;

// find the projection of these points on the model field. reassign them
// TL and BR
TL = H*TL;
TR = H*TR;                
BR = H*BR;
BL = H*BL;

// normalize the projected points
TL = TL/TL(2);
TR = TR/TR(2);
BR = BR/BR(2);
BL = BL/BL(2);


arma::vec im_gt_1;
arma::vec im_gt_2;
arma::vec im_gt_3;
arma::vec im_gt_4;

im_gt_1 = {0, 0, 1.0};
im_gt_2 = {1280, 0, 1.0};
im_gt_3 = {1280, 720, 1.0};
im_gt_4 = {0, 720, 1.0};

im_gt_1 = H*im_gt_1;
im_gt_2 = H*im_gt_2;
im_gt_3 = H*im_gt_3;
im_gt_4 = H*im_gt_4;

im_gt_1 = im_gt_1/im_gt_1(2);
im_gt_2 = im_gt_2/im_gt_2(2);
im_gt_3 = im_gt_3/im_gt_3(2);
im_gt_4 = im_gt_4/im_gt_4(2);

Paths gt;
Path p_gt;
addPoint(x1, y1, &p_gt);
addPoint(x2, y1, &p_gt);
addPoint(x2, y2, &p_gt);
addPoint(x1, y2, &p_gt);
addPoint(x1, y1, &p_gt);
gt.push_back(p_gt);



Paths im;
Path p_im;
addPoint(im_gt_1(0), im_gt_1(1), &p_im);
addPoint(im_gt_2(0), im_gt_2(1), &p_im);
addPoint(im_gt_3(0), im_gt_3(1), &p_im);
addPoint(im_gt_4(0), im_gt_4(1), &p_im);
addPoint(im_gt_1(0), im_gt_1(1), &p_im);
im.push_back(p_im);


Paths est;
Path p_est;
addPoint(TL(0), TL(1), &p_est);
addPoint(TR(0), TR(1), &p_est);
addPoint(BR(0), BR(1), &p_est);
addPoint(BL(0), BL(1), &p_est);
addPoint(TL(0), TL(1), &p_est);
est.push_back(p_est);

Clipper c1;
c1.AddPaths(gt, ptSubject, true);
c1.AddPaths(im, ptClip, true);
Paths gt_path;
c1.Execute(ctIntersection, gt_path, pftNonZero, pftNonZero);

Clipper c2;
c2.AddPaths(est, ptSubject, true);
c2.AddPaths(im, ptClip, true);
Paths est_path;
c2.Execute(ctIntersection, est_path, pftNonZero, pftNonZero);


Clipper c3;
c3.AddPaths(est_path, ptSubject, true);
c3.AddPaths(gt_path, ptClip, true);
Paths inter_path;
Paths uni_path;
c3.Execute(ctIntersection, inter_path, pftNonZero, pftNonZero);
c3.Execute(ctUnion, uni_path, pftNonZero, pftNonZero);

inter = Area(inter_path.at(0));
uni = Area(uni_path.at(0));

//std::cout << inter << std::endl;
//std::cout << uni << std::endl;

score = inter/uni;


return score;

}







