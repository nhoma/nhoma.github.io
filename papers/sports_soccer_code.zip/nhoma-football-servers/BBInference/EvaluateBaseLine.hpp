#ifndef EvaluateBaseLine_hpp
#define EvaluateBaseLine_hpp

#include <iostream>
#include <stdio.h>
#include <string>
#include <algorithm>
#include <dirent.h>
#include <fnmatch.h>
#include <vector>
#include <fstream>
#include "ReadDirectory.hpp"

#include "/ais/gobi4/namdar/soccer/Code/External/clipper/cpp/clipper.hpp" // http://www.angusj.com/delphi/clipper.php
#include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"

struct EvalOutput {
        
        double mean_iou;
        double med_iou;

                        
        arma::imat preds;
        std::vector<std::string> filenames;
                
};



EvalOutput evaluate(std::string data_dir, std::string pattern,  int gtAvailable);
double unionIntersectionMetric(arma::vec TL, arma::vec TR, arma::vec BR, arma::vec BL, arma::mat H);



#endif /* EvaluateBaseLine_hpp */