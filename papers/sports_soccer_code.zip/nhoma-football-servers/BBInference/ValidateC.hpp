#ifndef ValidateC_hpp
#define ValidateC_hpp

#include <iostream>
#include <stdio.h>
#include <string>
#include <algorithm>
#include <cstdlib>
#include<fstream>

#include <mpi.h>

#include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"
#include "StructSVMCPnSlack.hpp"
#include "Evaluate.hpp"

#endif /* ValidateC_hpp */