#!/bin/bash

./ValidateC -e GVerLHorLE -r expGVerLHorLE_Test -c 12 -t 1
./ValidateC -e GVerLHorLE1E2E3 -r expGVerLHorLE1E2E3_Test -c 20 -t 1
./ValidateC -e GVerLVerMVerRHorLE1E2E3 -r expGVerLVerMVerRHorLE1E2E3_Test -c 6 -t 1
./ValidateC -e GVerLVerMVerRHorLE -r expGVerLVerMVerRHorLE_Test -c 0.0005 -t 1
