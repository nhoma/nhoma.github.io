//
//  LinesPotential.cpp
//  BranchAndBoundCpp
//
//  Created by Namdar  on 2015-10-22.
//  Copyright © 2015 Namdar . All rights reserved.
//

#include <stdio.h>
#include "Potentials.hpp"



void Potentials::SetLines(ImageFeat &img, arma::ivec &tblr, arma::vec &verSign, arma::vec &horSign){
    
    
    // create the matrices and tensors references needed for the line potentials
    const arma::imat &vpHorLinesAccum = img.GetVpHorLinesAccum();
    const arma::imat &vpVerLinesAccum = img.GetVpVerLinesAccum();
    
    const arma::icube &horRayPos = img.GetHorRayPos();
    const arma::icube &verRayPos = img.GetVerRayPos();

    //
    
    const arma::ivec &initialTblr = img.GetInitialTblr();

    // initilize the m_verLines and m_horLines
    m_verLines.zeros(7);
    m_horLines.zeros(10);
    
    //
    
    //tblr = {23, 23, 118, 118, 5, 5, 266, 266};
    
    int y1Min = tblr(0);
    int y1Max = tblr(1);
    
    int y2Min = tblr(2);
    int y2Max = tblr(3);
    
    int y3Min = tblr(4);
    int y3Max = tblr(5);
    
    int y4Min = tblr(6);
    int y4Max = tblr(7);

    //int nbhd = 2;
    int nbhd = 1;
    
    // some initial declarations for the vector containing the TBLR
    arma::uvec T;
    arma::uvec B;
    arma::uvec L;
    arma::uvec R;

    arma::vec counts;
    
    // some helper variables
    int tempT;
    int tempB;
    int tempL;
    int tempR;

    //////////////////// Vertical Lines /////////////////////////////
    /////////////////////////////////////////////////////////////////
    
    // Left Goalline correspoding to y3

    L = arma::linspace<arma::uvec>(y3Min-nbhd, y3Max-nbhd, y3Max - y3Min+1);
    R = L+2*nbhd;
    
    //std::cout << "L: " << L << std::endl;
    //std::cout << "R: " << R << std::endl;
    
    if( verSign(0) > 0 ){
        T = y1Min;
        B = y2Max;
    
        counts = accumLookUpLines(vpVerLinesAccum, T, B, L, R);
        m_verLines(0) = counts.max();
        //std::cout << m_verLines(0) << std::endl;
    }
    else{
        
        T = y1Max;
        B = y2Min;
    
        counts = accumLookUpLines(vpVerLinesAccum, T, B, L, R);
        m_verLines(0) = counts.min();
    }
    

    
    // Vertical Line 1, l1
    // vertical line 1 is constrained above by horizontal line 2 and below by
    // horizontal line 3. Let's find their line numbers given the hypothesis set
    // Y
    
    tempL = getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 1);
    //std::cout << tblr << std::endl;  
    //std::cout << "tempL " << tempL << std::endl;  
    
    
    if( tempL == 0 ){
        tempL = y3Min;
    }
    
    
    tempR = getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 1);
    //std::cout << "tempR " << tempR << std::endl;  
    
    if( tempR == 0){
        tempR = y4Max;
    }
    
    
    L = arma::linspace<arma::uvec>(tempL-nbhd, tempR-nbhd, tempR - tempL+1);
    
    R = L + 2*nbhd;
    
    
    if( verSign(1) > 0){ // positive weight
        
        tempT =  getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 2);
    
        if( tempT == 0){
            tempT = y1Min;
        }
    
        tempB =  getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 3);
    
        if( tempB == 0){
            tempB = y2Max;
        }
        
        T = tempT;
        B = tempB;
        
        counts = accumLookUpLines(vpVerLinesAccum, T, B, L, R);
        m_verLines(1) = counts.max();
    }
    else{ // negative weight

        tempT =  getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 2);
        
        if( tempT == 0){
            tempT = y1Max;
        }
        
        tempB =  getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 3);
        
        if( tempB == 0){
            tempB = y2Min;
        }
                
        T = tempT;
        B = tempB;
        
        counts = accumLookUpLines(vpVerLinesAccum, T, B, L, R);
        m_verLines(1) = counts.min();
        
        if( tempB < tempT){
            m_verLines(1) = 0;
        }

    
    }
    
    
    // Vertical Line 2, l2
    //vertical line 3 is constrained above by horizontal line 1 and below by
    // horizontal line 4. Let's find their line numbers given the hypothesis set
    // Y
    
    
    tempL = getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 2);
    
    
    if( tempL == 0 ){
        tempL = y3Min;
    }
    
    
    tempR = getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 2);
    
    if( tempR == 0){
        tempR = y4Max;
    }
    
    L = arma::linspace<arma::uvec>(tempL-nbhd, tempR-nbhd, tempR - tempL+1);
    R = L + 2*nbhd;
    
    
    if( verSign(2) > 0){ // positive weight
        
        tempT =  getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 1);
        
        if( tempT == 0){
            tempT = y1Min;
        }
        
        tempB =  getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 4);
        
        if( tempB == 0){
            tempB = y2Max;
        }
        
        T = tempT;
        B = tempB;
        
        counts = accumLookUpLines(vpVerLinesAccum, T, B, L, R);
        m_verLines(2) = counts.max();
    }
    else{ // negative weight
        
        tempT =  getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 1);
        
        if( tempT == 0){
            tempT = y1Max;
        }
        
        tempB =  getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 4);
        
        if( tempB == 0){
            tempB = y2Min;
        }
        
        T = tempT;
        B = tempB;
        
        counts = accumLookUpLines(vpVerLinesAccum, T, B, L, R);
        m_verLines(2) = counts.min();
        
        if( tempB < tempT){
            m_verLines(2) = 0;
        }
        
    }

    // Vertical Line 3, l3, midline
    // vertical line 3 is constrained above by y1 and below by y2

    tempL = getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 3);
    
    
    if( tempL == 0 ){
        tempL = y3Min;
    }
    
    
    tempR = getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 3);
    
    if( tempR == 0){
        tempR = y4Max;
    }
    
    L = arma::linspace<arma::uvec>(tempL-nbhd, tempR-nbhd, tempR - tempL+1);
    R = L + 2*nbhd;
    
    
    if( verSign(3) > 0){ // positive weight
        
        T = y1Min;
        B = y2Max;
        
        counts = accumLookUpLines(vpVerLinesAccum, T, B, L, R);
        m_verLines(3) = counts.max();
    }
    else{ // negative weight
        
        T = y1Max;
        B = y2Min;
        
        m_verLines(3) = counts.min();
        
        
    }
    

    // Vertical Line 4, l4
    // vertical line 4 is constrained above by horizontal line 1 and below by
    // horizontal line 4. Let's find their line numbers given the hypothesis set
    // Y

    tempL = getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 4);
    
    
    if( tempL == 0 ){
        tempL = y3Min;
    }
    
    
    tempR = getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 4);
    
    if( tempR == 0){
        tempR = y4Max;
    }
    
    L = arma::linspace<arma::uvec>(tempL-nbhd, tempR-nbhd, tempR - tempL+1);
    R = L + 2*nbhd;
    
    
    if( verSign(4) > 0){ // positive weight
        
        tempT =  getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 1);
        
        if( tempT == 0){
            tempT = y1Min;
        }
        
        tempB =  getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 4);
        
        if( tempB == 0){
            tempB = y2Max;
        }
        
        T = tempT;
        B = tempB;
        
        counts = accumLookUpLines(vpVerLinesAccum, T, B, L, R);
        m_verLines(4) = counts.max();
    }
    else{ // negative weight
        
        tempT =  getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 1);
        
        if( tempT == 0){
            tempT = y1Max;
        }
        
        tempB =  getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 4);
        
        if( tempB == 0){
            tempB = y2Min;
        }
        
        T = tempT;
        B = tempB;
        
        counts = accumLookUpLines(vpVerLinesAccum, T, B, L, R);
        m_verLines(4) = counts.min();

        if( tempB < tempT){
            m_verLines(4) = 0;
        }
        
        
    }

    // Vertical Line 5, l5
    // vertical line 5 is constrained above by horizontal line 2 and below by
    // horizontal line 3. Let's find their line numbers given the hypothesis set
    // Y

    
    tempL = getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 5);
    
    if( tempL == 0 ){
        tempL = y3Min;
    }
    
    
    tempR = getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 5);
    
    if( tempR == 0){
        tempR = y4Max;
    }
    
    
    
    
    L = arma::linspace<arma::uvec>(tempL-nbhd, tempR-nbhd, tempR - tempL+1);
    R = L + 2*nbhd;
    
    
    if( verSign(5) > 0){ // positive weight
        
        tempT =  getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 2);
        
        if( tempT == 0){
            tempT = y1Min;
        }
        
        tempB =  getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 3);
        
        if( tempB == 0){
            tempB = y2Max;
        }
        
        T = tempT;
        B = tempB;
        
        counts = accumLookUpLines(vpVerLinesAccum, T, B, L, R);
        m_verLines(5) = counts.max();
    }
    else{ // negative weight
        
        tempT =  getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 2);
        
        if( tempT == 0){
            tempT = y1Max;
        }
        
        tempB =  getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 3);
        
        if( tempB == 0){
            tempB = y2Min;
        }
        
        T = tempT;
        B = tempB;
        
        counts = accumLookUpLines(vpVerLinesAccum, T, B, L, R);
        m_verLines(5) = counts.min();
        
        if( tempB < tempT){
            m_verLines(5) = 0;
        }

    }
    
    
    // Right Goalline correspoding to y3
    
    L = arma::linspace<arma::uvec>(y4Min-nbhd, y4Max-nbhd, y4Max - y4Min+1);
    R = L+2*nbhd;
    
    if( verSign(6) > 0 ){
        T = y1Min;
        B = y2Max;
        
        counts = accumLookUpLines(vpVerLinesAccum, T, B, L, R);
        m_verLines(6) = counts.max();
        //std::cout << m_verLines(0) << std::endl;
    }
    else{
        
        T = y1Max;
        B = y2Min;
        
        counts = accumLookUpLines(vpVerLinesAccum, T, B, L, R);
        m_verLines(6) = counts.min();
    }

    
    ////////////////// Horizontal Lines /////////////////////////////
    /////////////////////////////////////////////////////////////////
    
    // Upper Sideline correspoding to y1
    
    T = arma::linspace<arma::uvec>(y1Min-nbhd, y1Max-nbhd, y1Max - y1Min+1);
    B = T+2*nbhd;
    
    if( horSign(0) > 0 ){
        L = y3Min;
        R = y4Max;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(0) = counts.max();
        //std::cout << m_verLines(0) << std::endl;
    }
    else{
        
        L = y3Max;
        R = y4Min;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(0) = counts.min();
    }

    
    // line 1, first line after y1 on the left
    
    
    tempT = getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 1);
    
    
    if( tempT == 0 ){
        tempT = y1Min;
    }
    
    
    tempB = getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 1);
    
    if( tempB == 0){
        tempB = y2Max;
    }
    
    //std::cout << tblr << std::endl;
    //std::cout << tempT << std::endl;
    //std::cout << tempB << std::endl;
    
    T = arma::linspace<arma::uvec>(tempT-nbhd, tempB-nbhd, tempB - tempT+1);
    B = T + 2*nbhd;
    
    
    if( horSign(1) > 0){ // positive weight
        
        tempL =  y3Min;
        
        tempR =  getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 2);
        
        if( tempR == 0){
            tempR = y4Max;
        }
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(1) = counts.max();
    }
    else{ // negative weight
        
        tempL =  y3Max;
        
        tempR =  getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 2);
        
        if( tempR == 0){
            tempR = y4Min;
        }
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(1) = counts.min();
        
        
    }

    // line 2, second line after y1 on the left
    
    tempT = getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 2);
    
    
    if( tempT == 0 ){
        tempT = y1Min;
    }
    
    
    tempB = getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 2);
    
    if( tempB == 0){
        tempB = y2Max;
    }
    
    T = arma::linspace<arma::uvec>(tempT-nbhd, tempB-nbhd, tempB - tempT+1);
    B = T + 2*nbhd;
    
    
    if( horSign(2) > 0){ // positive weight
        
        tempL =  y3Min;
        
        tempR =  getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 1);
        
        if( tempR == 0){
            tempR = y4Max;
        }
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(2) = counts.max();
        //std::cout << m_horLines(2) << std::endl;
    }
    else{ // negative weight
        
        tempL =  y3Max;
        
        tempR =  getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 1);
        
        if( tempR == 0){
            tempR = y4Min;
        }
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(2) = counts.min();
        
        
    }

    // line 3, third line after y1 on the left
    
    
    tempT = getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 3);
    
    
    if( tempT == 0 ){
        tempT = y1Min;
    }
    
    
    tempB = getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 3);
    
    if( tempB == 0){
        tempB = y2Max;
    }
    
    T = arma::linspace<arma::uvec>(tempT-nbhd, tempB-nbhd, tempB - tempT+1);
    B = T + 2*nbhd;
    
    
    if( horSign(3) > 0){ // positive weight
        
        tempL =  y3Min;
        
        tempR =  getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 1);
        
        if( tempR == 0){
            tempR = y4Max;
        }
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(3) = counts.max();
    }
    else{ // negative weight
        
        tempL =  y3Max;
        
        tempR =  getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 1);
        
        if( tempR == 0){
            tempR = y4Min;
        }
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(3) = counts.min();
        
        
    }
    
    // line 4, Fourth line after y1 on the left
    
    tempT = getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 4);
    
    
    if( tempT == 0 ){
        tempT = y1Min;
    }
    
    
    tempB = getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 4);
    
    if( tempB == 0){
        tempB = y2Max;
    }
    
    T = arma::linspace<arma::uvec>(tempT-nbhd, tempB-nbhd, tempB - tempT+1);
    B = T + 2*nbhd;
    
    
    if( horSign(4) > 0){ // positive weight
        
        tempL =  y3Min;
        
        tempR =  getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 2);
        
        if( tempR == 0){
            tempR = y4Max;
        }
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(4) = counts.max();
    }
    else{ // negative weight
        
        tempL =  y3Max;
        
        tempR =  getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 2);
        
        if( tempR == 0){
            tempR = y4Min;
        }
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(4) = counts.min();
        
        
    }

    // line 5, first line after y1 on the right
  
    tempT = getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 1);
    
    
    if( tempT == 0 ){
        tempT = y1Min;
    }
    
    
    tempB = getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 1);
    
    if( tempB == 0){
        tempB = y2Max;
    }
    
    T = arma::linspace<arma::uvec>(tempT-nbhd, tempB-nbhd, tempB - tempT+1);
    B = T + 2*nbhd;
    
    
    if( horSign(5) > 0){ // positive weight
        
        tempL =  getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 4);
        
        if( tempL == 0){
            tempL = y4Max;
        }
        
        tempR =  y4Max;

        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(5) = counts.max();
    }
    else{ // negative weight
        
        tempL =  getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 4);
        
        if( tempL == 0){
            tempL = y4Max;
        }
        
        tempR =  y4Min;
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(5) = counts.min();
        
        
    }
    
    // line 6, second line after y1 on the right
    
    tempT = getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 2);
    
    
    if( tempT == 0 ){
        tempT = y1Min;
    }
    
    
    tempB = getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 2);
    
    if( tempB == 0){
        tempB = y2Max;
    }
    
    T = arma::linspace<arma::uvec>(tempT-nbhd, tempB-nbhd, tempB - tempT+1);
    B = T + 2*nbhd;
    
    
    if( horSign(6) > 0){ // positive weight
        
        tempL =  getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 5);
        
        if( tempL == 0){
            tempL = y4Max;
        }
        
        tempR =  y4Max;
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(6) = counts.max();
    }
    else{ // negative weight
        
        tempL =  getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 5);
        
        if( tempL == 0){
            tempL = y4Max;
        }
        
        tempR =  y4Min;
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(6) = counts.min();
        
        
    }

    // line 7, third line after y1 on the right


    tempT = getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 3);
    
    
    if( tempT == 0 ){
        tempT = y1Min;
    }
    
    
    tempB = getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 3);
    
    if( tempB == 0){
        tempB = y2Max;
    }
    
    T = arma::linspace<arma::uvec>(tempT-nbhd, tempB-nbhd, tempB - tempT+1);
    B = T + 2*nbhd;
    
    
    if( horSign(7) > 0){ // positive weight
        
        tempL =  getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 5);
        
        if( tempL == 0){
            tempL = y4Max;
        }
        
        tempR =  y4Max;
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(7) = counts.max();
    }
    else{ // negative weight
        
        tempL =  getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 5);
        
        if( tempL == 0){
            tempL = y4Max;
        }
        
        tempR =  y4Min;
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(7) = counts.min();
        
        
    }

    // line 4, Fourth line after y1 on the right
    
    tempT = getRayPosFromCR(horRayPos, y1Min, y2Min, initialTblr, 4);
    
    
    if( tempT == 0 ){
        tempT = y1Min;
    }
    
    
    tempB = getRayPosFromCR(horRayPos, y1Max, y2Max, initialTblr, 4);
    
    if( tempB == 0){
        tempB = y2Max;
    }
    
    T = arma::linspace<arma::uvec>(tempT-nbhd, tempB-nbhd, tempB - tempT+1);
    B = T + 2*nbhd;
    
    
    if( horSign(8) > 0){ // positive weight
        
        tempL =  getRayPosFromCR(verRayPos, y3Min, y4Min, initialTblr, 4);
        
        if( tempL == 0){
            tempL = y4Max;
        }
        
        tempR =  y4Max;
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(8) = counts.max();
    }
    else{ // negative weight
        
        tempL =  getRayPosFromCR(verRayPos, y3Max, y4Max, initialTblr, 4);
        
        if( tempL == 0){
            tempL = y4Max;
        }
        
        tempR =  y4Min;
        
        L = tempL;
        R = tempR;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(8) = counts.min();
        
        
    }

    // Lower Sideline correspoding to y2
    
    T = arma::linspace<arma::uvec>(y2Min-nbhd, y2Max-nbhd, y2Max - y2Min+1);
    B = T+2*nbhd;
    
    if( horSign(9) > 0 ){
        L = y3Min;
        R = y4Max;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(9) = counts.max();
        //std::cout << m_verLines(0) << std::endl;
    }
    else{
        
        L = y3Max;
        R = y4Min;
        
        counts = accumLookUpLines(vpHorLinesAccum, T, B, L, R);
        m_horLines(9) = counts.min();
    }
    
    
    int nRow = vpHorLinesAccum.n_rows;
    int nCol = vpHorLinesAccum.n_cols;
    
    
 
    m_verLines = m_verLines/double(vpVerLinesAccum( nRow-1, nCol-1));
    m_horLines = m_horLines/double(vpHorLinesAccum( nRow-1, nCol-1));
    
    /*
    std::cout << "m_verLines" << std::endl;
    std::cout << m_verLines << std::endl;
    std::cout << "sum m_verLines" << std::endl;
    std::cout << sum(m_verLines) << std::endl;

    std::cout << "-------------------" << std::endl;
    std::cout << "m_horLines" << std::endl;
    std::cout << m_horLines << std::endl;
    std::cout << "sum m_horLines" << std::endl;
    std::cout << sum(m_horLines) << std::endl;
    */
    
}























