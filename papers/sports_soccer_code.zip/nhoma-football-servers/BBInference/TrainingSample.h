/*  This file is part of Structured Prediction (SP) - http://www.alexander-schwing.de/
 *
 *  Structured Prediction (SP) is free software: you can
 *  redistribute it and/or modify it under the terms of the GNU General
 *  Public License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Structured Prediction (SP) is distributed in the hope
 *  that it will be useful, but WITHOUT ANY WARRANTY; without even the
 *  implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *  PURPOSE. See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Structured Prediction (SP).
 *  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Copyright (C) 2010-2013  Alexander G. Schwing  [http://www.alexander-schwing.de/]
 */

//Author: Alexander G. Schwing

/*  ON A PERSONAL NOTE: I spent a significant amount of time to go through
 *  both, theoretical justifications and coding of this framework.
 *  I hope the package is useful for your task. Any citations, requests, 
 *  feedback, donations and support would be greatly appreciated.
 *  Thank you for contacting me!
 */


// My Includes:
#ifdef __APPLE__
#include <armadillo>
#else
#include "/u/namdar/soccer/Code/External/armadillo-7.400.4/include/armadillo"
#include "Potentials.hpp"
#include "ImageFeat.hpp"
#include "InferenceLoss.hpp"
#include "BranchAndBoundInference.hpp"
#endif



//////////////// 
struct SampleParams {
	std::string fn;
	std::string feat; // namdar added
};

//////////////
struct TrainingDataParams {
	std::vector<struct SampleParams*> SampleData;
};



////////////////
class TrainingSample {
	struct SampleParams* sample;
	std::vector<int> labeling;
	
	std::string m_imgInfo;
	
	//// my additions
	arma::ivec m_tempLabeling;
	// ground truth labels
	std::vector<int> gt;	
	// potential functions(features) assiciated with ground truth labels
	std::vector<double> phi_gt;
	ImageFeat m_img;
	Potentials m_pot = Potentials(); // potentials
	// tblr is a an 8-dim vector of T,B,L,R
	arma::ivec m_tblr;
	// Thess will be used for potential signs. Might have to change it
    arma::vec grassSign;
    arma::vec verSign;
	arma::vec horSign;
	arma::vec ellipSign;
	
	
	// grass potential
	arma::vec grass;
	
	// The weight vector
	arma::vec m_weight;
	
	InferenceLoss m_loss = InferenceLoss();
	
    
public:
	TrainingSample() {};
	~TrainingSample() {};
	
	//
	int Load(struct SampleParams* sample) {
		
		this->sample = sample;
		int numFeatures;
		
		
		
		// have to change this based on the experiment
		if( sample->feat.compare("G") == 0){
			numFeatures = 4;
		}
		else if( sample->feat.compare("GL") == 0 ){
			numFeatures = 5;
		}//
		else if( sample->feat.compare("GLE") == 0 ){
			numFeatures = 6;
		}
		else if( sample->feat.compare("GVerLHorL") == 0 ){
			numFeatures = 6;
		}
		else if( sample->feat.compare("GVerLHorLE") == 0 ){
			numFeatures = 7;
		}
		else if( sample->feat.compare("GVerLVerMVerRHorLE") == 0 ){
			numFeatures = 7;
		}
		else if( sample->feat.compare("GVerLHorLE1E2E3") == 0 ){
			
			numFeatures = 9;
		}
		else if( sample->feat.compare("LE") == 0 ){
			numFeatures = 2;
		}
		else if( sample->feat.compare("GVerLVerMVerRHorLE1E2E3") == 0 ){
			numFeatures = 11;
		}
		else if( sample->feat.compare("GVerAllHorLE1E2E3") == 0 ){
			numFeatures = 13;
		}
		else if( sample->feat.compare("GVerSymHorLESym") == 0 ){
			numFeatures = 9;
		}
		else if( sample->feat.compare("GVerSymHorSymESym") == 0 ){
			numFeatures = 14;
		}
		else if( sample->feat.compare("GVerAllHorAllEAll") == 0 ){
			numFeatures = 22;
		}
		else if( sample->feat.compare("GVerLHorLEInteraction") == 0 ){
			numFeatures = 8;
		}
		else{
			std::cout << "ERROR!! EXITING. THE -e argument NOT SPECIFIED PROPERLY"<< std::endl;
			exit(1);
		}
		
		
		
		// the path to img without the extensions
		std::string imgInfo = sample->fn.substr(0,sample->fn.find_last_of("."));
		m_imgInfo = imgInfo;
		std::cout << imgInfo << std::endl;
		
		// get the image features associated with imgInfo
		m_img = ImageFeat(imgInfo, 1); // 1 says GT available.
		
		//assign gt and other required data
		arma::ivec gtTemp = m_img.GetYGT();
		gt = arma::conv_to< std::vector<int> >::from(gtTemp);
	
		phi_gt.assign(numFeatures, 0.0);
		 
		FeatureVector(gt, phi_gt);
		
        return numFeatures;
	}
	
	int MarginRescaling(std::vector<double>& w, double time) {
		//compute margin rescaling and assign labeling		
		
		if( sample->feat.compare("G") == 0){
			//m_weight = {w[0], w[1], 1}; // 1 is the weight for the loss
			m_weight = {w[0], w[1], w[2], w[3],1}; // 1 is the weight for the loss	
		}
		else if( sample->feat.compare("GL") == 0 ){
			m_weight = {w[0], w[1], w[2], w[3],//grass
						w[4], 1}; 
			
		} 
		else if( sample->feat.compare("GLE") == 0 ){
			m_weight = {w[0], w[1], w[2], w[3],//grass
						w[4],
						w[5],
						1}; 
		}
		
		else if( sample->feat.compare("GVerLHorL") == 0 ){
			m_weight = {w[0], w[1],
						w[2],
						w[3],
						1}; 
		}		
		else if( sample->feat.compare("GVerLHorLE") == 0 ){
			m_weight = {w[0], w[1], w[2], w[3],//grass
						w[4],
						w[5],
						w[6],
						1}; 
		} 

		else if( sample->feat.compare("GVerLVerMVerRHorLE") == 0 ){ 
			m_weight = {w[0], w[1], //grass
						w[2], w[3], w[4],
						w[5],
						w[6],
						1}; 
		} 
		else if( sample->feat.compare("GVerLHorLE1E2E3") == 0 ){ 

			m_weight = {w[0], w[1], w[2], w[3],//grass
						w[4],
						w[5],
						w[6],w[7], w[8],
						1};

		}
		else if( sample->feat.compare("LE") == 0 ){
			m_weight = {w[0], w[1], 1}; 
		}
		else if( sample->feat.compare("GVerLVerMVerRHorLE1E2E3") == 0 ){ 
			m_weight = {w[0], w[1], w[2], w[3],//grass
						w[4], w[5], w[6], //verL verM verR
						w[7], // horL
						w[8], w[9], w[10], // Ellipse
						 1};  
		}
		else if( sample->feat.compare("GVerAllHorLE1E2E3") == 0 ){ 
			m_weight = {w[0], w[1], //grass
						w[2],w[3], w[4], w[5], w[6], w[7], w[8], // VerAll
						w[9], // HorL
						w[10], w[11], w[12], //ellipses
						1};  
		} 
		else if( sample->feat.compare("GVerSymHorLESym") == 0 ){ 
			m_weight = {w[0], w[1], //grass
						w[2],w[3], w[4], w[5], //  symmetric ver
						w[6], // HorL
						w[7], w[8], //ellipses
						1};   
		}
		else if( sample->feat.compare("GVerSymHorSymESym") == 0 ){ 
			m_weight = {w[0], w[1], //w[0], w[1], //grass
						w[2],w[3], w[4], w[5], //  symmetric ver
						w[6], w[7], w[8], w[9], w[10], w[11], // symmetric Hor
						w[12], w[13], // symm ellipses
						1};   
		}
		else if( sample->feat.compare("GVerAllHorAllEAll") == 0 ){ 
			m_weight = {w[0], w[1], //grass
						w[2],w[3], w[4], w[5], w[6], w[7], w[8], 
						w[9], w[10], w[11], w[12], w[13], w[14], w[15], w[16], w[17], w[18], 
						w[19], w[20], w[21], 
						1};  
		}
		else if( sample->feat.compare("GVerLHorLEInteraction") == 0 ){
			m_weight = {w[0], w[1], //grass
						w[2], // verL
						w[3], // horL
						w[4], //E
						w[5],
						w[6],
						w[7],
						1}; 
		}
		
		m_tempLabeling = branchAndBoundInference(m_img, m_weight, sample->feat, 1, m_imgInfo); // 1 says GT available
		
		labeling = arma::conv_to< std::vector<int> >::from(m_tempLabeling);
			
        return 0;
	}
	
	
	// This function, given a labeling updates the phi vector. Actually it
	// updates the memory location given by the pointer
	int FeatureVector(std::vector<int>& y, std::vector<double>& phi) {
		//compute feature vector phi from labeling y
		grassSign.ones(4);
		verSign.ones(7);
		horSign.ones(10);
		ellipSign.ones(3);
		
		m_tblr = {y[0], y[0], y[1], y[1], y[2], y[2], y[3], y[3]};
		

		
		if( sample->feat.compare("G") == 0){ // only grass
			m_pot.SetGrass(m_img, m_tblr, grassSign); // the 1 referes to the sign. // Not important when not computing upper bound						  
			grass = m_pot.GetGrass();
			
			//phi[0] = grass(0) - grass(2);			
			//phi[1] = grass(1) - grass(3);
			phi[0] = grass(0);
			phi[1] = grass(1);
			phi[2] = grass(2);
			phi[3] = grass(3);
			
		}
		else if( sample->feat.compare("GL") == 0 ){ // grass + sum(verlines+horlines)
			
			m_pot.SetGrass(m_img, m_tblr, grassSign); 
			m_pot.SetLines(m_img, m_tblr, verSign, horSign);
			
			grass = m_pot.GetGrass();
			
			phi[0] = grass(0);
			phi[1] = grass(1);
			phi[2] = grass(2);
			phi[3] = grass(3);
			phi[4] = sum(m_pot.GetHorLines())+ sum(m_pot.GetVerLines());			
		}
	
		else if( sample->feat.compare("GLE") == 0 ){ // grass + sum(verlines+horlines)+sum(ellipse)
			
			m_pot.SetGrass(m_img, m_tblr, grassSign); 
			m_pot.SetLines(m_img, m_tblr, verSign, horSign);
			m_pot.SetEllipsis(m_img, m_tblr, ellipSign);
			
			grass = m_pot.GetGrass();
		    
			phi[0] = grass(0);
			phi[1] = grass(1);
			phi[2] = grass(2);
			phi[3] = grass(3);
			
			phi[4] = sum(m_pot.GetVerLines()) + sum(m_pot.GetHorLines());
			phi[5] = sum(m_pot.GetEllipsis());
		}
						
		else if( sample->feat.compare("GVerLHorL") == 0 ){ // grass + sum(verlines)+sum(horlines)
			
			m_pot.SetGrass(m_img, m_tblr, grassSign); 
			m_pot.SetLines(m_img, m_tblr, verSign, horSign);
			
			grass = m_pot.GetGrass();
		    
			phi[0] = grass(0);
			phi[1] = grass(1);
			phi[2] = grass(2);
			phi[3] = grass(3);
			
			phi[4] = sum(m_pot.GetVerLines());
			
			phi[5] = sum(m_pot.GetHorLines());
		}

		else if( sample->feat.compare("GVerLHorLE") == 0 ){ // grass + sum(verlines)+sum(horlines)+sum(ellipse)
			
			m_pot.SetGrass(m_img, m_tblr, grassSign); 
			m_pot.SetLines(m_img, m_tblr, verSign, horSign);
			m_pot.SetEllipsis(m_img, m_tblr, ellipSign);			
			
			grass = m_pot.GetGrass();
		    
			phi[0] = grass(0);
			phi[1] = grass(1);
			phi[2] = grass(2);
			phi[3] = grass(3);
			
			
			phi[4] = sum(m_pot.GetVerLines());
			
			phi[5] = sum(m_pot.GetHorLines());
			
			phi[6] = sum(m_pot.GetEllipsis());
		}

		else if( sample->feat.compare("GVerLVerMVerRHorLE") == 0 ){ // grass + sum(verlines on left)
														//sum(verlines on middle)+ sum(verlines on left)
														// + sum(horlines)+sum(ellipse)
			
			m_pot.SetGrass(m_img, m_tblr, grassSign);  
			m_pot.SetLines(m_img, m_tblr, verSign, horSign);
			m_pot.SetEllipsis(m_img, m_tblr, ellipSign);			
			
			arma::vec verLines;
			
			verLines = m_pot.GetVerLines();
			
			grass = m_pot.GetGrass();
		    
			phi[0] = grass(0) - grass(2);
			phi[1] = grass(1) - grass(3);
			
			phi[2] = verLines(0)+verLines(1)+verLines(2);
			phi[3] = verLines(3);
			phi[4] = verLines(4)+verLines(5)+verLines(6);			
			
			phi[5] = sum(m_pot.GetHorLines());
			
			phi[6] = sum(m_pot.GetEllipsis());
			
		}
		else if( sample->feat.compare("LE") == 0 ){ // grass + sum(verlines+horlines)+sum(ellipse)
			
			m_pot.SetLines(m_img, m_tblr, verSign, horSign);
			m_pot.SetEllipsis(m_img, m_tblr, ellipSign);
			
			phi[0] = sum(m_pot.GetVerLines()) + sum(m_pot.GetHorLines());
			phi[1] = sum(m_pot.GetEllipsis());
		}
		else if( sample->feat.compare("GVerLHorLE1E2E3")  == 0 ){  // G + verL + horL + separate ellipses
			

            m_pot.SetGrass(m_img, m_tblr, grassSign);  
			m_pot.SetLines(m_img, m_tblr, verSign, horSign);
			m_pot.SetEllipsis(m_img, m_tblr, ellipSign);			
        
        
            arma::vec ellip;
            
            ellip = m_pot.GetEllipsis();
			
			grass = m_pot.GetGrass();
		    
			//phi[0] = grass(0) - grass(2);
			//phi[1] = grass(1) - grass(3);
			phi[0] = grass(0);
			phi[1] = grass(1);
			phi[2] = grass(2);
			phi[3] = grass(3);
			
			phi[4] = sum(m_pot.GetVerLines());
			
			phi[5] = sum(m_pot.GetHorLines());
			
			phi[6] = ellip(0);
			phi[7] = ellip(1);
			phi[8] = ellip(2);
			
		
		}
		else if( sample->feat.compare("GVerLVerMVerRHorLE1E2E3") == 0 ){ // grass + sum(verlines on left)
														//sum(verlines on middle)+ sum(verlines on left)
														// + sum(horlines)+different ellipses
			            			
            m_pot.SetGrass(m_img, m_tblr, grassSign); 
			m_pot.SetLines(m_img, m_tblr, verSign, horSign);
			m_pot.SetEllipsis(m_img, m_tblr, ellipSign);			
			
			arma::vec verLines;
			verLines = m_pot.GetVerLines();
			
			arma::vec ellip;
            ellip = m_pot.GetEllipsis();
            			
			grass = m_pot.GetGrass();
			
			phi[0] = grass(0);
			phi[1] = grass(1);
			phi[2] = grass(2);
			phi[3] = grass(3);
			
			
			phi[4] = verLines(0)+verLines(1)+verLines(2);
			phi[5] = verLines(3);
			phi[6] = verLines(4)+verLines(5)+verLines(6);			
			
			phi[7] = sum(m_pot.GetHorLines());
			
			phi[8] = ellip(0);
			phi[9] = ellip(1);
			phi[10] = ellip(2);
		
		}
		else if( sample->feat.compare("GVerAllHorLE1E2E3") == 0 ){ // grass + allVerLines
														// + sum(horlines)+different ellipses
            			
            m_pot.SetGrass(m_img, m_tblr, grassSign); 
			m_pot.SetLines(m_img, m_tblr, verSign, horSign);
			m_pot.SetEllipsis(m_img, m_tblr, ellipSign);			
			
			arma::vec verLines;
			verLines = m_pot.GetVerLines();
			
			arma::vec ellip;
            ellip = m_pot.GetEllipsis();
            			
			grass = m_pot.GetGrass();
			
			phi[0] = grass(0) - grass(2);
			phi[1] = grass(1) - grass(3);
			
			phi[2] = verLines(0);
			phi[3] = verLines(1);
			phi[4] = verLines(2);
			phi[5] = verLines(3);
			phi[6] = verLines(4);
			phi[7] = verLines(5);
			phi[8] = verLines(6);
			
			phi[9] = sum(m_pot.GetHorLines());
			
			phi[10] = ellip(0);
			phi[11] = ellip(1);
			phi[12] = ellip(2);
		
		}
		else if( sample->feat.compare("GVerSymHorLESym") == 0 ){ // grass + verSym
														// + sum(horlines)+different ellipses
            			
            m_pot.SetGrass(m_img, m_tblr, grassSign); 
			m_pot.SetLines(m_img, m_tblr, verSign, horSign);
			m_pot.SetEllipsis(m_img, m_tblr, ellipSign);			
			
			arma::vec verLines;
			verLines = m_pot.GetVerLines();
			
			arma::vec ellip;
            ellip = m_pot.GetEllipsis();
            			
			grass = m_pot.GetGrass();
			
			phi[0] = grass(0) - grass(2);
			phi[1] = grass(1) - grass(3);
			
			phi[2] = verLines(0) + verLines(6);
			phi[3] = verLines(1) + verLines(5);
			phi[4] = verLines(2) + verLines(4);
			phi[5] = verLines(3);
			
			phi[6] = sum(m_pot.GetHorLines());
			
			phi[7] = ellip(0) + ellip(2);
			phi[8] = ellip(1);

					
			
		}
		else if( sample->feat.compare("GVerSymHorSymESym") == 0 ){ // grass + verSym
														// + sum(horlines)+different ellipses
            			
            m_pot.SetGrass(m_img, m_tblr, grassSign); 
			m_pot.SetLines(m_img, m_tblr, verSign, horSign);
			m_pot.SetEllipsis(m_img, m_tblr, ellipSign);			
			
			arma::vec verLines;
			verLines = m_pot.GetVerLines();
			
			arma::vec horLines;
			horLines = m_pot.GetHorLines();
			
			arma::vec ellip;
            ellip = m_pot.GetEllipsis();
            			
			grass = m_pot.GetGrass();
			
			phi[0] = grass(0) - grass(2);
			phi[1] = grass(1) - grass(3);
			//phi[0] = grass(0);
			//phi[1] = grass(1);
			
			
			phi[2] = verLines(0) + verLines(6);
			phi[3] = verLines(1) + verLines(5);
			phi[4] = verLines(2) + verLines(4);
			phi[5] = verLines(3);
			
			phi[6] = horLines(0);
			phi[7] = horLines(1) + horLines(5);
			phi[8] = horLines(2) + horLines(6);
			phi[9] = horLines(3) + horLines(7);
			phi[10] = horLines(4) + horLines(8);
			phi[11] = horLines(9);
			
			phi[12] = ellip(0) + ellip(2);
			phi[13] = ellip(1);
			

		
		}
		else if( sample->feat.compare("GVerAllHorAllEAll") == 0 ){ // grass + verSym
														// + sum(horlines)+different ellipses
            			
            m_pot.SetGrass(m_img, m_tblr, grassSign); 
			m_pot.SetLines(m_img, m_tblr, verSign, horSign);
			m_pot.SetEllipsis(m_img, m_tblr, ellipSign);			
			
			arma::vec verLines;
			verLines = m_pot.GetVerLines();
			
			arma::vec horLines;
			horLines = m_pot.GetHorLines();
			
			arma::vec ellip;
            ellip = m_pot.GetEllipsis();
            			
			grass = m_pot.GetGrass();
			
			phi[0] = grass(0) - grass(2);
			phi[1] = grass(1) - grass(3);
			
			phi[2] = verLines(0) ;
			phi[3] = verLines(1) ;
			phi[4] = verLines(2) ;
			phi[5] = verLines(3) ;
			phi[6] = verLines(4) ;
			phi[7] = verLines(5) ;
			phi[8] = verLines(6) ;
						
			phi[9] = horLines(0) ;
			phi[10] = horLines(1) ;
			phi[11] = horLines(2) ;
			phi[12] = horLines(3) ;
			phi[13] = horLines(4) ;
			phi[14] = horLines(5) ;
			phi[15] = horLines(6) ;
			phi[16] = horLines(7) ;
			phi[17] = horLines(8) ;
			phi[18] = horLines(9) ;
			
			phi[19] = ellip(0);
			phi[20] = ellip(1);
			phi[21] = ellip(2);


		
		}
		else if( sample->feat.compare("GVerLHorLEInteraction") == 0 ){ // grass + sum(verlines)+sum(horlines)+sum(ellipse)
			
			m_pot.SetGrass(m_img, m_tblr, grassSign); 
			m_pot.SetLines(m_img, m_tblr, verSign, horSign);
			m_pot.SetEllipsis(m_img, m_tblr, ellipSign);			
			
			arma::vec verLines;
			verLines = m_pot.GetVerLines();
			
			arma::vec horLines;
			horLines = m_pot.GetHorLines();
			
			arma::vec ellip;
            ellip = m_pot.GetEllipsis();
			
			grass = m_pot.GetGrass();
		    
			phi[0] = grass(0) - grass(2);
			phi[1] = grass(1) - grass(3);
			
			
			phi[2] = sum(verLines);
			
			phi[3] = sum(horLines);
			
			phi[4] = sum(ellip);
			
			phi[5] = ellip[0]*verLines[2];
			phi[6] = ellip[1]*verLines[3];
			phi[7] = ellip[2]*verLines[4];
		}
		
		return 0;
		
	}
	
	
	
	double Loss() {
		double loss = 0.0;
		//compute loss of labeling w.r.t. gt
		m_tblr = {labeling[0], labeling[0],
			  labeling[1], labeling[1],
			  labeling[2], labeling[2],
			  labeling[3], labeling[3]};
		
		m_loss.SetLoss(m_img, m_tblr, 1); // 1 says GT available
		loss = (double)m_loss.GetLoss();
		
		return loss;
	}
	
	
	
	int AddFeatureDiffAndLoss(std::vector<double>& featureDiffAndLoss, std::vector<double>& w) {
		int numFeatures = int(featureDiffAndLoss.size())-1;
		std::vector<double> phi_y(numFeatures, 0.0);
		FeatureVector(labeling, phi_y);
		for(int k=0;k<numFeatures;++k) {
			featureDiffAndLoss[k] += phi_gt[k] - phi_y[k];
		}
		featureDiffAndLoss[numFeatures] += Loss();
		return 0;
	}
	
};