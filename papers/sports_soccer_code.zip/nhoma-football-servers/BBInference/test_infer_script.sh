#!/bin/bash

./ValidateC -e G -r expG_Test -c 0.0005 -t 1
./ValidateC -e GL -r expGL_Test -c 1.5 -t 1
./ValidateC -e LE -r expLE_Test -c 0.0625 -t 1
./ValidateC -e GLE -r expGLE_Test -c 1.5 -t 1
