#include "RealDepDemo.hpp"






void RealDepDemo(std::string resultsDir, std::string imgDir){
// The evaluate function goes into .../experiments/exp#/ (exp# given by -r argument )
// and reads the weight vector (from weights.dat) and features used (from features.txt)
// Then depending on what type of images it wants to compute the features for (train/val/test) (given by -i argument)
// it goes to imgDir/val and finds the predictions and IOU for each image
// It then saves the predictions and IOU for each image in .../experiments/exp#/
// ./Evaluate -i /u/namdar/soccer/Data/ValSet -r exp2




std::string baseDir("/u/namdar/soccer/Code/experiments4/");


//read the features
std::string features(""); 


std::ifstream fid;
fid.open (baseDir + resultsDir + "/" + "features.txt");
std::getline(fid, features);
fid.close();

std::cout << "The features are: " << features << std::endl;

// read all the image files in the img directory. save their paths
std::string pattern = "*.jpg";
std::vector<std::string> fileNames;
TraverseDirectory(imgDir, pattern, fileNames);

// open up the list of failed images
arma::ivec failed;
std::cout << "here" << std::endl;
bool status = failed.load(imgDir + "/" + "failed.txt");
if(status == false){
        std::cout << "No Failed files" << std::endl;
        failed = {-1};

}



//read the weights. If file not there exit
arma::vec w;

status = w.load(baseDir + resultsDir + "/" + "weights.dat");
if(status == false){
        std::cout << "ERROR!! EXITING!! either exp name wrong or experiment"
                << " not done!" << std::endl;
        exit(1);

}

// add a zero to the end of w to correspond to loss potential
w.insert_rows(w.n_elem, arma::zeros(1));

// vector that holds the predictions
BBOutput predY;


// specify the number of test images
int numImg = fileNames.size();


// create four vectors that will contain the TBLR lines. Each vector will be of
// the form [a;b;c] corresponding to ax+by+c = 0
arma::vec T;
arma::vec B;
arma::vec L;
arma::vec R;

                                
// initialize the image info which will be used to read the image features
std::string imgInfo;

// holds all the predictions and gts for the images                              
arma::imat preds(numImg,4);
arma::imat iterations(numImg, 1);
arma::mat energy(numImg,1);


int gtAvailable = 0;

 
 
                                
for(int ii = 0; ii < numImg; ++ii){
        
        imgInfo = imgDir + "/" + std::to_string(ii+1);
        
        std::cout << imgInfo << std::endl;        
        
        
        if( any(failed == ii+1) == 0){
            // do branch and bound for the original featured
            ImageFeat img = ImageFeat(imgInfo,gtAvailable);

            predY = branchAndBoundInferenceMoreInfo(img, w, features, gtAvailable);
            
            for(int jj=0; jj <4; ++jj){
                preds(ii,jj) = predY.labeling(jj);
            }
             
             iterations(ii,0) = predY.iterations;  
        }
        else{
            
            
            predY.energy = 0;
            predY.iterations = 0;
            predY.labeling = {-1,-1,-1,-1};
            
            iterations(ii,0) = -1;
            
            // no features for this image, so set all the labelings to -1
            preds(ii,0) = -1;
            preds(ii,1) = -1;
            preds(ii,2) = -1;
            preds(ii,3) = -1;
        
        }
        
        
        energy(ii,0) = predY.energy; 
        
        
        
        
        
        
        
        
        
        if(1){ // display information
                std::cout << imgInfo << std::endl;        
                
                std::cout << "Prediction" << std::endl;
                std::cout << predY.labeling << std::endl;
                
                std::cout << "Prediction Energy" << std::endl;
                std::cout << predY.energy << std::endl;
                
                std::cout << "Prediction Iterations" << std::endl;
                std::cout << predY.iterations << std::endl;
                        
        }
        
        
}



// save the img names in the order they appear
std::ofstream fid2;
fid2.open(baseDir + resultsDir + "/" + "fileNames.txt");
        
for(int ii=0; ii < numImg; ii++){
        fid2 << ii+1 << std::endl;
}
        
fid2.close();


// save all the predictions
preds.save(baseDir + resultsDir + "/" + "preds.txt", arma::raw_ascii);

// save the number of iterations
iterations.save(baseDir + resultsDir + "/" + "iterations.txt", arma::raw_ascii);

// save all the predictions
energy.save(baseDir + resultsDir + "/" + "energy.txt", arma::raw_ascii);


return;

}

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////




void TraverseDirectory(const std::string& path, std::string& pattern, std::vector<std::string>& fileNames) {
        DIR *dir, *tstdp;
    struct dirent *dp;

    //open the directory
    if((dir  = opendir(path.c_str())) == NULL)
    {
                std::cout << "Error opening " << path << std::endl;
        return;
    }

    while ((dp = readdir(dir)) != NULL)
    {
        tstdp=opendir(dp->d_name);
                
                if(tstdp) {
                        closedir(tstdp);
                       
                } else {
                        if(fnmatch(pattern.c_str(), dp->d_name, 0)==0) {
                                std::string tmp(path);
                                tmp.append("/").append(dp->d_name);
                                fileNames.push_back(tmp);
                                std::cout << fileNames.back() << std::endl;
                        }
                }
    }

    closedir(dir);
    return;

}


