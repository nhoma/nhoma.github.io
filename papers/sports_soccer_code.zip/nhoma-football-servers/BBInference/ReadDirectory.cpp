#include "ReadDirectory.hpp"


void TraverseDirectory(const std::string& path, const std::string& pattern,
						std::vector<std::string>& fileNames,
						bool printFilenames) {
	DIR *dir, *tstdp;
	struct dirent *dp;

	//open the directory
	if ((dir = opendir(path.c_str())) == NULL)
	{
		std::cout << "Error opening " << path << std::endl;
		return;
	}

	while ((dp = readdir(dir)) != NULL)
	{
		tstdp = opendir(dp->d_name);

		if (tstdp) {
			closedir(tstdp);
		} else {
			if (fnmatch(pattern.c_str(), dp->d_name, 0) == 0) {
				std::string tmp(path);
				tmp.append("/").append(dp->d_name);
				fileNames.push_back(tmp);
				if( printFilenames > 0){
					std::cout << fileNames.back() << std::endl;
				}
			}
		}
	}

	closedir(dir);
	return;

}
