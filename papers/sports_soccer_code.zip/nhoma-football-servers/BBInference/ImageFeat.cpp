//
//  ImageFeat.cpp
//  BranchAndBoundCpp
//
//  Created by Namdar  on 2015-10-17.
//  Copyright © 2015 Namdar . All rights reserved.
//

#include "ImageFeat.hpp"


////////////////////////// Constructors //////////////////////////
ImageFeat::ImageFeat(){}

ImageFeat::ImageFeat(std::string imgInfo, int gtAvailable){
    
    m_gt_available = gtAvailable;
    m_imgInfo = imgInfo; 
    
        
    m_fieldWid = 114.83;
    m_fieldHeight = 74.37;

    m_grassAccum.load(imgInfo + ".grassAccum");
    
    m_nonGrassAccum.load(imgInfo + ".nonGrassAccum");
    
    m_vpHor.load(imgInfo + ".vpHor");
    
    m_vpVer.load(imgInfo + ".vpVer");
    

    
    //load the line equations
    m_vpHorLines.load(imgInfo + ".vpHorLines");
    
    m_vpVerLines.load(imgInfo + ".vpVerLines");
    
    
    // load file and convert mat file to ivec
    
    m_initialTblr.load(imgInfo + ".initialTblr");
        
    
    // load the accumlators for the lines from vanishing points
    m_vpHorLinesAccum.load(imgInfo + ".vpHorLinesAccum");
    
    m_vpVerLinesAccum.load(imgInfo + ".vpVerLinesAccum");
    
    
    
    if( gtAvailable == 1){
        // uncomment the below when you have the ground truth
        // load the ground truth labels
        m_yGT.load(imgInfo + ".labelsGT");
    
    }
    else{
        m_yGT = {0,0,0,0};
    }

    
    // load the accumlators for the ellipsis
    m_ellipsisAccum.load(imgInfo + ".ellipsisAccum");
    
    m_circleAccum.load(imgInfo + ".circleAccum");
    
    
    
    // ellipsis cross ratios
    
    m_verRayPosEllipseTemp.load(imgInfo + ".verEllipsisCR");
    
    m_verRayPosEllipse = arma::icube(m_initialTblr(5)-m_initialTblr(4)+1,
                                    m_initialTblr(7)-m_initialTblr(6)+1,
                                    8);
    int ind = m_initialTblr(7)-m_initialTblr(6)+1;
    for (int ii = 0; ii <8; ii++) {
        m_verRayPosEllipse.slice(ii) = m_verRayPosEllipseTemp.cols(ii*ind,(ii+1)*ind-1);
    }
    
    
    m_horRayPosEllipseTemp.load(imgInfo + ".horEllipsisCR");
    
    m_horRayPosEllipse = arma::icube(m_initialTblr(1)-m_initialTblr(0)+1,
                             m_initialTblr(3)-m_initialTblr(2)+1,
                             4);
    ind = m_initialTblr(3)-m_initialTblr(2)+1;
    for (int ii = 0; ii <4; ii++) {
        m_horRayPosEllipse.slice(ii) = m_horRayPosEllipseTemp.cols(ii*ind,(ii+1)*ind-1);
    }
    

    // lines cross ratios
    m_verRayPosTemp.load(imgInfo + ".verLinesCR");
    
    m_verRayPos = arma::icube(m_initialTblr(5)-m_initialTblr(4)+1,
                                    m_initialTblr(7)-m_initialTblr(6)+1,
                                    5);

    ind = m_initialTblr(7)-m_initialTblr(6)+1;
    for (int ii = 0; ii <5; ii++) {
        m_verRayPos.slice(ii) = m_verRayPosTemp.cols(ii*ind,(ii+1)*ind-1);
    }

    
    m_horRayPosTemp.load(imgInfo + ".horLinesCR");
    
    m_horRayPos = arma::icube(m_initialTblr(1)-m_initialTblr(0)+1,
                                    m_initialTblr(3)-m_initialTblr(2)+1,
                                    4);

    ind = m_initialTblr(3)-m_initialTblr(2)+1;
    for (int ii = 0; ii <4; ii++) {
        m_horRayPos.slice(ii) = m_horRayPosTemp.cols(ii*ind,(ii+1)*ind-1);
    }
    
    if(gtAvailable == 1){
        // get the field and non-field accumulators
        m_fieldAccum.load(imgInfo + ".fieldAccum");
        m_nonFieldAccum.load(imgInfo + ".nonFieldAccum");
    }
    
    
}





arma::vec ImageFeat::GetSpecificVerLine(int rowNum){
    return m_vpVerLines.row(rowNum).t();
}

arma::vec ImageFeat::GetSpecificHorLine(int rowNum){
    return m_vpHorLines.row(rowNum).t();
}



void ImageFeat::assignData(std::string imgInfo, int gtAvailable){
    
    m_gt_available = gtAvailable;
    m_imgInfo = imgInfo; 
    
        
    m_fieldWid = 114.83;
    m_fieldHeight = 74.37;

    m_grassAccum.load(imgInfo + ".grassAccum");
    
    m_nonGrassAccum.load(imgInfo + ".nonGrassAccum");
    
    m_vpHor.load(imgInfo + ".vpHor");
    
    m_vpVer.load(imgInfo + ".vpVer");
    

    
    //load the line equations
    m_vpHorLines.load(imgInfo + ".vpHorLines");
    
    m_vpVerLines.load(imgInfo + ".vpVerLines");
    
    
    // load file and convert mat file to ivec
    
    m_initialTblr.load(imgInfo + ".initialTblr");
        
    
    // load the accumlators for the lines from vanishing points
    m_vpHorLinesAccum.load(imgInfo + ".vpHorLinesAccum");
    
    m_vpVerLinesAccum.load(imgInfo + ".vpVerLinesAccum");
    
    
    
    if( gtAvailable == 1){
        // uncomment the below when you have the ground truth
        // load the ground truth labels
        m_yGT.load(imgInfo + ".labelsGT");
    
    }
    else{
        m_yGT = {0,0,0,0};
    }

    
    // load the accumlators for the ellipsis
    m_ellipsisAccum.load(imgInfo + ".ellipsisAccum");
    
    m_circleAccum.load(imgInfo + ".circleAccum");
    
    
    
    // ellipsis cross ratios
    
    m_verRayPosEllipseTemp.load(imgInfo + ".verEllipsisCR");
    
    m_verRayPosEllipse = arma::icube(m_initialTblr(5)-m_initialTblr(4)+1,
                                    m_initialTblr(7)-m_initialTblr(6)+1,
                                    8);
    int ind = m_initialTblr(7)-m_initialTblr(6)+1;
    for (int ii = 0; ii <8; ii++) {
        m_verRayPosEllipse.slice(ii) = m_verRayPosEllipseTemp.cols(ii*ind,(ii+1)*ind-1);
    }
    
    
    m_horRayPosEllipseTemp.load(imgInfo + ".horEllipsisCR");
    
    m_horRayPosEllipse = arma::icube(m_initialTblr(1)-m_initialTblr(0)+1,
                             m_initialTblr(3)-m_initialTblr(2)+1,
                             4);
    ind = m_initialTblr(3)-m_initialTblr(2)+1;
    for (int ii = 0; ii <4; ii++) {
        m_horRayPosEllipse.slice(ii) = m_horRayPosEllipseTemp.cols(ii*ind,(ii+1)*ind-1);
    }
    

    // lines cross ratios
    m_verRayPosTemp.load(imgInfo + ".verLinesCR");
    
    m_verRayPos = arma::icube(m_initialTblr(5)-m_initialTblr(4)+1,
                                    m_initialTblr(7)-m_initialTblr(6)+1,
                                    5);

    ind = m_initialTblr(7)-m_initialTblr(6)+1;
    for (int ii = 0; ii <5; ii++) {
        m_verRayPos.slice(ii) = m_verRayPosTemp.cols(ii*ind,(ii+1)*ind-1);
    }

    
    m_horRayPosTemp.load(imgInfo + ".horLinesCR");
    
    m_horRayPos = arma::icube(m_initialTblr(1)-m_initialTblr(0)+1,
                                    m_initialTblr(3)-m_initialTblr(2)+1,
                                    4);

    ind = m_initialTblr(3)-m_initialTblr(2)+1;
    for (int ii = 0; ii <4; ii++) {
        m_horRayPos.slice(ii) = m_horRayPosTemp.cols(ii*ind,(ii+1)*ind-1);
    }
    
    if(gtAvailable == 1){
        // get the field and non-field accumulators
        m_fieldAccum.load(imgInfo + ".fieldAccum");
        m_nonFieldAccum.load(imgInfo + ".nonFieldAccum");
    }
    
    
}





void ImageFeat::save_as_binary(){
    
    
    
    m_grassAccum.save(m_imgInfo + ".grassAccum");
    
    m_nonGrassAccum.save(m_imgInfo + ".nonGrassAccum");
    
    m_vpHor.save(m_imgInfo + ".vpHor");
    m_vpVer.save(m_imgInfo + ".vpVer");

    
    //load the line equations
    m_vpHorLines.save(m_imgInfo + ".vpHorLines");
    m_vpVerLines.save(m_imgInfo + ".vpVerLines");

    // load file and convert mat file to ivec
    m_initialTblr.save(m_imgInfo + ".initialTblr");
    
    
    
    
    // load the accumlators for the lines from vanishing points
    m_vpHorLinesAccum.save(m_imgInfo + ".vpHorLinesAccum");
    m_vpVerLinesAccum.save(m_imgInfo + ".vpVerLinesAccum");
    
    
    if( m_gt_available == 1){

        m_yGT.save(m_imgInfo + ".labelsGT");
        
    }
    
    // load the accumlators for the ellipsis
    m_ellipsisAccum.save(m_imgInfo + ".ellipsisAccum");
    m_circleAccum.save(m_imgInfo + ".circleAccum");

    
    // ellipsis cross ratios
    
    m_verRayPosEllipseTemp.load(m_imgInfo + ".verEllipsisCR");
    m_verRayPosEllipseTemp.save(m_imgInfo + ".verEllipsisCR");
    
    
    m_horRayPosEllipseTemp.load(m_imgInfo + ".horEllipsisCR");
    m_horRayPosEllipseTemp.save(m_imgInfo + ".horEllipsisCR");
    

    // lines cross ratios
    m_verRayPosTemp.load(m_imgInfo + ".verLinesCR");
    m_verRayPosTemp.save(m_imgInfo + ".verLinesCR");

    
    m_horRayPosTemp.load(m_imgInfo + ".horLinesCR");
    m_horRayPosTemp.save(m_imgInfo + ".horLinesCR");
    
    if(m_gt_available == 1){
        // get the field and non-field accumulators
        m_fieldAccum.save(m_imgInfo + ".fieldAccum");
        m_nonFieldAccum.save(m_imgInfo + ".nonFieldAccum");
    }



}