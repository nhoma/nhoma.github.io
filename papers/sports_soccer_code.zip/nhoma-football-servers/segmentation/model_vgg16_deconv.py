import tflearn
import numpy as np
import tensorflow as tf




def vgg16_deconv(x_inp_placeholder,
    path_to_vgg = "/ais/gobi4/namdar/soccer/data/cvpr/trained_models/vgg16_weights.npz",
    ):



    # read the vgg weights
    vgg_weights = np.load(path_to_vgg)

    #def vgg16(num_class, placeholderX=None):

    x = tflearn.conv_2d(x_inp_placeholder, 64, 3, activation='relu',
                        weights_init = tf.constant(vgg_weights['conv1_1_W']),
                        bias_init = tf.constant(vgg_weights['conv1_1_b']),
                        scope='conv1_1')


    x = tflearn.batch_normalization(x, scope='batchnorm1_1')

    x = tflearn.conv_2d(x, 64, 3, activation='relu',
                        weights_init=tf.constant(vgg_weights['conv1_2_W']),
                        bias_init=tf.constant(vgg_weights['conv1_2_b']),
                        scope='conv1_2')

    x = tflearn.batch_normalization(x, scope='batchnorm1_2')

    x = tflearn.max_pool_2d(x, 2, strides=2, name='maxpool1')

    x = tflearn.conv_2d(x, 128, 3, activation='relu',
                        weights_init=tf.constant(vgg_weights['conv2_1_W']),
                        bias_init=tf.constant(vgg_weights['conv2_1_b']),
                        scope='conv2_1')

    x = tflearn.batch_normalization(x, scope='batchnorm2_1')

    x = tflearn.conv_2d(x, 128, 3, activation='relu',
                        weights_init=tf.constant(vgg_weights['conv2_2_W']),
                        bias_init=tf.constant(vgg_weights['conv2_2_b']),
                        scope='conv2_2')

    x = tflearn.batch_normalization(x, scope='batchnorm2_2')

    x = tflearn.max_pool_2d(x, 2, strides=2, name='maxpool2')

    x = tflearn.conv_2d(x, 256, 3, activation='relu',
                        weights_init=tf.constant(vgg_weights['conv3_1_W']),
                        bias_init=tf.constant(vgg_weights['conv3_1_b']),
                        scope='conv3_1')

    x = tflearn.batch_normalization(x, scope='batchnorm3_1')


    x = tflearn.conv_2d(x, 256, 3, activation='relu',
                        weights_init=tf.constant(vgg_weights['conv3_2_W']),
                        bias_init=tf.constant(vgg_weights['conv3_2_b']),
                        scope='conv3_2')

    x = tflearn.batch_normalization(x, scope='batchnorm3_2')

    x = tflearn.conv_2d(x, 256, 3, activation='relu',
                        weights_init=tf.constant(vgg_weights['conv3_3_W']),
                        bias_init=tf.constant(vgg_weights['conv3_3_b']),
                        scope='conv3_3')

    x = tflearn.batch_normalization(x, scope='batchnorm3_3')

    x = tflearn.max_pool_2d(x, 2, strides=2, name='maxpool3')

    x = tflearn.conv_2d(x, 512, 3, activation='relu',
                        weights_init=tf.constant(vgg_weights['conv4_1_W']),
                        bias_init=tf.constant(vgg_weights['conv4_1_b']),
                        scope='conv4_1')

    x = tflearn.batch_normalization(x, scope='batchnorm4_1')

    x = tflearn.conv_2d(x, 512, 3, activation='relu',
                        weights_init=tf.constant(vgg_weights['conv4_2_W']),
                        bias_init=tf.constant(vgg_weights['conv4_2_b']),
                        scope='conv4_2')

    x = tflearn.batch_normalization(x, scope='batchnorm4_2')

    x = tflearn.conv_2d(x, 512, 3, activation='relu',
                        weights_init=tf.constant(vgg_weights['conv4_3_W']),
                        bias_init=tf.constant(vgg_weights['conv4_3_b']),
                        scope='conv4_3')

    x = tflearn.batch_normalization(x, scope='batchnorm4_3')

    x = tflearn.max_pool_2d(x, 2, strides=2, name='maxpool4')

    x = tflearn.conv_2d(x, 512, 3, activation='relu',
                        weights_init=tf.constant(vgg_weights['conv5_1_W']),
                        bias_init=tf.constant(vgg_weights['conv5_1_b']),
                        scope='conv5_1')

    x = tflearn.batch_normalization(x, scope='batchnorm5_1')

    x = tflearn.conv_2d(x, 512, 3, activation='relu',
                        weights_init=tf.constant(vgg_weights['conv5_2_W']),
                        bias_init=tf.constant(vgg_weights['conv5_2_b']),
                        scope='conv5_2')

    x = tflearn.batch_normalization(x, scope='batchnorm5_2')

    x = tflearn.conv_2d(x, 512, 3, activation='relu',
                        weights_init=tf.constant(vgg_weights['conv5_3_W']),
                        bias_init=tf.constant(vgg_weights['conv5_3_b']),
                        scope='conv5_3')
    x = tflearn.max_pool_2d(x, 2, strides=2, name='maxpool5')

    x = tflearn.conv_2d(x, 4096, filter_size=[6,10],
                        padding='valid', activation='relu',
                        weights_init='xavier',
                        scope='fc6')



    x = tflearn.dropout(x, 0.5, name='dropout1')

    W_new = np.expand_dims(vgg_weights['fc7_W'], axis=0)
    W_new = np.expand_dims(W_new, axis=0)
    x = tflearn.conv_2d(x, 4096, 1, activation='relu',
                        weights_init=tf.constant(W_new),
                        bias_init=tf.constant(vgg_weights['fc7_b']),
                        scope='fc7')


    x = tflearn.dropout(x, 0.5, name='dropout2')

    # deconv layers
    # first upsample
    x = tflearn.conv_2d_transpose(x,
                                  nb_filter=512,
                                  filter_size=[6,10],
                                  output_shape=[6,10],
                                  padding='valid',
                                  activation='relu',
                                  scope='upsample1')

    x = tflearn.batch_normalization(x, scope='batchnorm_d_1')

    # second upsample
    x = tflearn.conv_2d_transpose(x, nb_filter=512,
                                  filter_size=3,
                                  output_shape=[12,20],
                                  strides=[1,2,2,1],
                                  activation='relu',
                                  scope='upsample2')

    x = tflearn.batch_normalization(x, scope='batchnorm_d_2')
    '''
    x = tflearn.conv_2d_transpose(x, nb_filter=512,
                                  filter_size=3,
                                  output_shape=[12, 20],
                                  strides=[1, 1, 1, 1],
                                  activation='relu',
                                  scope='deconv2_1')
    '''


    # third upsample
    x = tflearn.conv_2d_transpose(x, nb_filter=256,
                                  filter_size=3,
                                  output_shape=[23, 40],
                                  strides=[1, 2, 2, 1],
                                  activation='relu',
                                  scope='upsample3')

    x = tflearn.batch_normalization(x, scope='batchnorm_d_3')


    '''
    x = tflearn.conv_2d_transpose(x, nb_filter=128,
                                  filter_size=3,
                                  output_shape=[23, 40],
                                  strides=[1, 1, 1, 1],
                                  activation='relu',
                                  scope='deconv3_1')
    '''


    # fourth upsample

    x = tflearn.conv_2d_transpose(x, nb_filter=128,
                                  filter_size=3,
                                  output_shape=[45, 80],
                                  strides=[1, 2, 2, 1],
                                  activation='relu',
                                  scope='upsample4')

    x = tflearn.batch_normalization(x, scope='batchnorm_d_4')

    # fifth upsample

    x = tflearn.conv_2d_transpose(x, nb_filter=128,
                                  filter_size=3,
                                  output_shape=[90, 160],
                                  strides=[1, 2, 2, 1],
                                  activation='relu',
                                  scope='upsample5')
    x = tflearn.batch_normalization(x, scope='batchnorm_d_5')

    # sixth upsample

    x = tflearn.conv_2d_transpose(x, nb_filter=64,
                                  filter_size=3,
                                  output_shape=[180, 320],
                                  strides=[1, 2, 2, 1],
                                  activation='relu',
                                  scope='upsample6')

    x = tflearn.batch_normalization(x, scope='batchnorm_d_6')

    x = tflearn.conv_2d_transpose(x, nb_filter=6,
                                  filter_size=3,
                                  output_shape=[180, 320],
                                  strides=[1, 1, 1, 1],
                                  activation='relu',
                                  scope='deconv6_1')



    return x




def get_gt_one_hot_node(y_true_placeholder):



    y_true_reshaped = tf.reshape(y_true_placeholder, shape=(-1, 1))

    y_true_hot = tf.contrib.layers.one_hot_encoding(
        tf.to_int32(y_true_reshaped), 6)
    y_true_hot = tf.squeeze(y_true_hot, squeeze_dims=[1])

    return y_true_hot
