import tflearn
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
print("Getting the predictions:")
from matplotlib.backends.backend_pdf import PdfPages

# import the custom code
from read_data import read_data_sets
from model_vgg16_deconv import vgg16_deconv
from iou_metric import iou_metric

#import IOUMetric

# set up some hyper parameters

num_classes = 6
num_epoch = 500

path_to_vgg = "/ais/gobi4/namdar/soccer/data/cvpr/trained_models/vgg16_weights.npz"
path_to_checkpoints = "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/model_weights/vgg16_deconv/checkpoint"
best_checkpoint = path_to_checkpoints+"-6500"
path_to_figures =  "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/saved_figures/"
model_name = "vgg16_simple"

# read the data

_, val, _ = read_data_sets()


# define placeholder for input and output
x_inp = tflearn.input_data(
    shape=[None, val.img_size[0], val.img_size[1], 3],
    name='input')


# get the forward pass of the model
x = vgg16_deconv(x_inp)

saver = tf.train.Saver()

with tf.Session() as sess:

    #sess = tf.InteractiveSession()
    #sess = trainer.session


    saver.restore(sess, best_checkpoint)
    print("Model restored.")

    print("Getting the predictions:")

    tflearn.config.is_training (is_training=False, session=sess)

    preds = sess.run(x, feed_dict={x_inp: val.images})

    preds_max = np.argmax(preds, axis=3)

    print("Got the predictions:")
    # The PDF document
    pdf_pages = PdfPages(path_to_figures+model_name+".pdf")



    for ii in range(10):

        fig = plt.figure(figsize=(8, 12))

        for jj in range(5):

            plt.subplot(5, 2, 2 * jj + 1)
            # plt.imshow(players.train.images[i,:,:,:].squeeze(), vmin=0, vmax=1)
            plt.imshow(val.images[ii*5+jj])
            cur_axes = plt.gca()
            cur_axes.axes.get_xaxis().set_visible(False)
            cur_axes.axes.get_yaxis().set_visible(False)

            plt.subplot(5, 2, 2 * jj + 2)
            plt.imshow(preds_max[ii*5+jj])
            cur_axes = plt.gca()
            cur_axes.axes.get_xaxis().set_visible(False)
            cur_axes.axes.get_yaxis().set_visible(False)

        pdf_pages.savefig(fig)

        plt.close(fig)

    pdf_pages.close()


    print("Plotted all the figures!")
