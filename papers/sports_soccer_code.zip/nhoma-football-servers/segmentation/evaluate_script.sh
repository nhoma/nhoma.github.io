#!/bin/bash
source activate tf0.10
#python training_vgg16_dilation_hockey_upp_circle.py
python evaluating_vgg16_dilation_hockey_upp_circle.py
