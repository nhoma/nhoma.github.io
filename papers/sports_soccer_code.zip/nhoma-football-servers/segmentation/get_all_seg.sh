#!/bin/bash
source activate tf0.10
python get_segmentation_for_all_data_hockey.py
