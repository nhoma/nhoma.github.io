#!/bin/bash
source activate tf0.10
python training_vgg16_dilation_hockey_upp_circle_more_data.py
#python get_segmentation_for_all_data_hockey.py
