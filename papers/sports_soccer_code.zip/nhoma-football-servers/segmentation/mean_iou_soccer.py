import tflearn

import numpy as np
import tensorflow as tf
import os



# import the custom code
from read_data import read_data_sets
from model_vgg16_dilation_only_conv import vgg16_dilation, get_gt_one_hot_node

from iou_metric import iou_metric_per_class, iou_metric


num_classes = 6

path_to_vgg = "/ais/gobi4/namdar/soccer/data/cvpr/trained_models/vgg16_weights.npz"
path_to_checkpoints = "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/model_weights/vgg16_dilation_circle/"
#path_to_checkpoints = "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/model_weights/vgg16_dilation_penalty_4/"
checkpoint_num = "5254"
best_checkpoint = path_to_checkpoints+"checkpoint-"+checkpoint_num


# read the data


_, _, test = read_data_sets(rescale_factor=0.25)



datta = test

# define placeholder for input and output
x_inp = tflearn.input_data(
    shape=[None, datta.img_size[0], datta.img_size[1], 3],
    name='input')

# placeholder for the groundtruth
y_true = tf.placeholder(tf.float32,
                        shape=(None, datta.label_size[0], datta.label_size[1]))



# get the forward pass of the model
x = vgg16_dilation(x_inp)
#x = tf.pow(x, tf.constant([3,9,3,3,3,1,3,1,1], shape=(1,num_classes),dtype=tf.float32))
x = tf.pow(x, tf.constant([3,3,3,3,1,1], shape=(1,6),dtype=tf.float32))

# reshape the
y_pred = tf.reshape(x, shape=(-1, num_classes))


# get a one-hot encoding for the ground truth images
y_true_hot = get_gt_one_hot_node(y_true)


IOU = iou_metric_per_class(y_pred, y_true_hot,num_classes=num_classes)

sum_iou_per_class = np.zeros(shape = (1,num_classes), dtype=np.float32)

saver = tf.train.Saver()



with tf.Session() as sess:

    saver.restore(sess, best_checkpoint)
    print("Model restored.")

    tflearn.config.is_training (is_training=False, session=sess)

    for ii in range(datta.num_examples):
        print("Image: " + str(ii + 1) + "/" + str(datta.num_examples))
        [preds, iou] = sess.run([x,IOU], feed_dict={
            x_inp: datta.images[[ii ]], y_true: datta.labels[[ii]]})

        iou = iou[0]

        sum_iou_per_class += iou

mean_iou_per_class = sum_iou_per_class/datta.num_examples

total_mean_iou = np.mean(mean_iou_per_class)

print("The mean IOU for all the classes is: " + str(mean_iou_per_class))
print("Total mean IOU: " + str(total_mean_iou))

