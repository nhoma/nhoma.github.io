import tflearn
import numpy as np
import tensorflow as tf
from atrous_conv_2d import atrous_conv_2d



def vgg16_dilation(x_inp_placeholder,
    path_to_vgg = "/ais/gobi4/namdar/soccer/data/cvpr/trained_models/vgg16_weights.npz",
    ):

    #x_inp_placeholder = x_inp

    # read the vgg weights
    #path_to_vgg = "/ais/gobi4/namdar/soccer/data/cvpr/trained_models/vgg16_weights.npz"
    vgg_weights = np.load(path_to_vgg)

    #def vgg16(num_class, placeholderX=None):

    '''
    init = tf.initialize_all_variables()
    sess = tf.InteractiveSession()
    sess.run(init)
    temp = sess.run(x, feed_dict={x_inp: train.images[[0]]})
    print(temp.shape)
    '''

    ## Block 1
    x = tflearn.conv_2d(x_inp_placeholder, 64, 3, activation='relu',
                        weights_init = tf.constant(vgg_weights['conv1_1_W']),
                        bias_init = tf.constant(vgg_weights['conv1_1_b']),
                        scope='conv1_1')

    x = tflearn.batch_normalization(x, scope='batchnorm1_1')

    x = tflearn.conv_2d(x, 64, 3, activation='relu',
                        weights_init=tf.constant(vgg_weights['conv1_2_W']),
                        bias_init=tf.constant(vgg_weights['conv1_2_b']),
                        scope='conv1_2')

    x = tflearn.batch_normalization(x, scope='batchnorm1_2')


    ## Block 2

    x = atrous_conv_2d(x, 128, 3, rate=2,
                        padding='same',
                        activation='relu',
                        weights_init=tf.constant(vgg_weights['conv2_1_W']),
                        bias_init=tf.constant(vgg_weights['conv2_1_b']),
                        scope='conv2_1')

    x = tflearn.batch_normalization(x, scope='batchnorm2_1')

    x = atrous_conv_2d(x, 128, 3, rate=2,
                        padding='same',
                        activation='relu',
                        weights_init=tf.constant(vgg_weights['conv2_2_W']),
                        bias_init=tf.constant(vgg_weights['conv2_2_b']),
                        scope='conv2_2')

    x = tflearn.batch_normalization(x, scope='batchnorm2_2')

    ## Block 3
    x = atrous_conv_2d(x, 256, 3, activation='relu', rate=4,
                        padding='same',
                        weights_init=tf.constant(vgg_weights['conv3_1_W']),
                        bias_init=tf.constant(vgg_weights['conv3_1_b']),
                        scope='conv3_1')

    x = tflearn.batch_normalization(x, scope='batchnorm3_1')


    x = atrous_conv_2d(x, 256, 3, activation='relu', rate=4,
                        padding='same',
                        weights_init=tf.constant(vgg_weights['conv3_2_W']),
                        bias_init=tf.constant(vgg_weights['conv3_2_b']),
                        scope='conv3_2')

    x = tflearn.batch_normalization(x, scope='batchnorm3_2')

    x = atrous_conv_2d(x, 256, 3, activation='relu', rate=4,
                        padding='same',
                        weights_init=tf.constant(vgg_weights['conv3_3_W']),
                        bias_init=tf.constant(vgg_weights['conv3_3_b']),
                        scope='conv3_3')

    x = tflearn.batch_normalization(x, scope='batchnorm3_3')

    '''
    ## block 4
    x = atrous_conv_2d(x, 512, 3, activation='relu', rate=8,
                        padding='same',
                        weights_init=tf.constant(vgg_weights['conv4_1_W']),
                        bias_init=tf.constant(vgg_weights['conv4_1_b']),
                        scope='conv4_1')

    x = tflearn.batch_normalization(x, scope='batchnorm4_1')

    x = atrous_conv_2d(x, 512, 3, activation='relu', rate=8,
                        padding='same',
                        weights_init=tf.constant(vgg_weights['conv4_2_W']),
                        bias_init=tf.constant(vgg_weights['conv4_2_b']),
                        scope='conv4_2')

    x = tflearn.batch_normalization(x, scope='batchnorm4_2')

    x = atrous_conv_2d(x, 512, 3, activation='relu', rate=8,
                        padding='same',
                        weights_init=tf.constant(vgg_weights['conv4_3_W']),
                        bias_init=tf.constant(vgg_weights['conv4_3_b']),
                        scope='conv4_3')

    x = tflearn.batch_normalization(x, scope='batchnorm4_3')
    '''

    ## new block
    x = atrous_conv_2d(x, 6, 3, activation='relu', rate=8,
                       padding='same',
                       scope='new_conv4_1')


    x = tflearn.batch_normalization(x, scope='batchnorm4_1')

    x = atrous_conv_2d(x, 6, 3, activation='relu', rate=16,
                       padding='same',
                       scope='new_conv4_2')

    x = tflearn.batch_normalization(x, scope='batchnorm4_2')

    x = atrous_conv_2d(x, 6, 3, activation='relu', rate=32,
                       padding='same',
                       scope='new_conv4_3')

    x = tflearn.batch_normalization(x, scope='batchnorm4_3')

    ## last Conv layers
    x = tflearn.conv_2d(x, 6, 3, activation='relu',
                        scope='conv5_1')

    x = tflearn.batch_normalization(x, scope='batchnorm5_1')

    x = tflearn.conv_2d(x, 6, 1, activation='relu',
                        scope='conv5_2')


    return x






def get_gt_one_hot_node(y_true_placeholder):



    y_true_reshaped = tf.reshape(y_true_placeholder, shape=(-1, 1))

    y_true_hot = tf.contrib.layers.one_hot_encoding(
        tf.to_int32(y_true_reshaped), 6)
    y_true_hot = tf.squeeze(y_true_hot, squeeze_dims=[1])

    return y_true_hot
