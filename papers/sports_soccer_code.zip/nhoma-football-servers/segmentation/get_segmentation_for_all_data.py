# get the grass and line segmentations from the best trained model for the whole
# dataset

import tflearn
import matplotlib.image as image
import numpy as np
import tensorflow as tf
import scipy.io as sio



# import the custom code
from read_data import read_data_sets
from model_vgg16_dilation_only_conv import vgg16_dilation, get_gt_one_hot_node


path_to_checkpoint = "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/model_weights/vgg16_dilation_circle/"
checkpoint = "checkpoint-"




train, val, test = read_data_sets(rescale_factor=0.25)

# define placeholder for input and output
x_inp = tflearn.input_data(
    shape=[None, val.img_size[0], val.img_size[1], 3],
    name='input')



# get the forward pass of the model
x = vgg16_dilation(x_inp)
x = tf.pow(x, tf.constant([3,3,3,3,1,1], shape=(1,6),dtype=tf.float32))



saver = tf.train.Saver()

with tf.Session() as sess:

    print("Getting the predictions:")
    #sess = tf.InteractiveSession()
    #sess = trainer.session

    saver.restore(sess, path_to_checkpoint+checkpoint)
    tflearn.config.is_training(is_training=False, session=sess)

    for datta in [train, val, test]:

        for ii in range(datta.num_examples):

            preds = sess.run(x, feed_dict={x_inp: datta.images[[ii ]]})
            preds_max = np.argmax(preds, axis=3)
            preds_max = np.int8(preds_max[0])

            print("Saving: " + str(ii+1)+"/"+str(datta.num_examples))
            sio.savemat(datta.img_paths[ii] + "_seg_pred", {'preds':preds_max})
            image.imsave(datta.img_paths[ii] + "_seg_pred.png", preds_max)

    print("Saved all the predictions!")





