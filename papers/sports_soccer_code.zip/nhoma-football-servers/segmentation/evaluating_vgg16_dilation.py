import tflearn
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf

from matplotlib.backends.backend_pdf import PdfPages

# import the custom code
from read_data import read_data_sets
#from model_vgg16_dilation_more_layers import vgg16_dilation, get_gt_one_hot_node
from model_vgg16_dilation_only_conv import vgg16_dilation, get_gt_one_hot_node

from iou_metric import iou_metric_per_class

# set up some hyper parameters
num_classes = 6

path_to_vgg = "/ais/gobi4/namdar/soccer/data/cvpr/trained_models/vgg16_weights.npz"
path_to_checkpoints = "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/model_weights/vgg16_dilation/"
#path_to_checkpoints = "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/model_weights/vgg16_dilation_penalty_4/"
checkpoint_num = "7400"
best_checkpoint = path_to_checkpoints+"checkpoint-"+checkpoint_num
path_to_figures =  "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/saved_figures/"
model_name = "vgg16_simple_mIOU_"+checkpoint_num

# read the data

_, val, _ = read_data_sets(rescale_factor=0.25)


# define placeholder for input and output
x_inp = tflearn.input_data(
    shape=[None, val.img_size[0], val.img_size[1], 3],
    name='input')

# placeholder for the groundtruth
y_true = tf.placeholder(tf.float32,
                        shape=(None, val.label_size[0], val.label_size[1]))



# get the forward pass of the model
x = vgg16_dilation(x_inp)
x = tf.pow(x, tf.constant([3,3,3,1,1,1], shape=(1,6),dtype=tf.float32))

# reshape the
y_pred = tf.reshape(x, shape=(-1, num_classes))


# get a one-hot encoding for the ground truth images
y_true_hot = get_gt_one_hot_node(y_true)


IOU = iou_metric_per_class(y_pred, y_true_hot)

mean_iou_per_class = np.zeros(shape = (1,6), dtype=np.float32)

saver = tf.train.Saver()

with tf.Session() as sess:

    #sess = tf.InteractiveSession()
    #sess = trainer.session


    saver.restore(sess, best_checkpoint)
    print("Model restored.")

    print("Getting the predictions:")

    tflearn.config.is_training (is_training=False, session=sess)

    # The PDF document
    pdf_pages = PdfPages(path_to_figures+model_name+".pdf")

    for ii in range(10):

        fig = plt.figure(figsize=(8, 12))

        for jj in range(5):
            plt.subplot(5, 2, 2 * jj + 1)
            # plt.imshow(players.train.images[i,:,:,:].squeeze(), vmin=0, vmax=1)
            plt.imshow(val.images[ii * 5 + jj])
            cur_axes = plt.gca()
            cur_axes.axes.get_xaxis().set_visible(False)
            cur_axes.axes.get_yaxis().set_visible(False)

            [preds, iou] = sess.run([x,IOU], feed_dict={
                x_inp: val.images[[ii * 5 + jj]], y_true: val.labels[[ii * 5 + jj]]})

            iou = iou[0]

            mean_iou_per_class += iou

            preds_max = np.argmax(preds, axis=3)

            plt.subplot(5, 2, 2 * jj + 2)
            plt.imshow(preds_max[0])
            plt.title(['{:.2f}'.format(kk) for kk in iou])
            cur_axes = plt.gca()
            cur_axes.axes.get_xaxis().set_visible(False)
            cur_axes.axes.get_yaxis().set_visible(False)

        pdf_pages.savefig(fig)

        plt.close(fig)

    pdf_pages.close()

    print("Plotted all the figures!")

mean_iou_per_class = mean_iou_per_class/50

print("The mean IOU for all the classes is: " + str(mean_iou_per_class))

print("Plotted all the figures!")