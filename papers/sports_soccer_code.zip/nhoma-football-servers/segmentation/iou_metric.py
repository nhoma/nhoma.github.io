import tensorflow as tf


def iou_metric_per_class(pred, target, num_classes=6):

    pred = tf.one_hot(tf.argmax(pred, dimension=1), num_classes)
    intersection = tf.mul(pred, target)
    intersection = tf.reduce_sum(intersection, reduction_indices=0, keep_dims=True)

    union = tf.reduce_sum(pred, reduction_indices=0, keep_dims=True) + \
            tf.reduce_sum(target, reduction_indices=0,
                          keep_dims=True) - intersection

    div = tf.div(intersection, union)

    IOU = tf.select(tf.is_nan(div), tf.ones_like(div)*0, div )

    return IOU



def iou_metric(pred, target, num_classes=6):


    IOU = iou_metric_per_class(pred, target, num_classes)

    IOU = tf.reduce_mean(IOU)

    return IOU