import tflearn
#import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf

# import the custom code
from read_data import read_data_sets
from model_vgg16_dilation import vgg16_dilation, get_gt_one_hot_node
from iou_metric import iou_metric

#import IOUMetric

# set up some hyper parameters

num_classes = 6
num_epoch = 500
initital_learning_rate = 0.0005
path_to_vgg = "/ais/gobi4/namdar/soccer/data/cvpr/trained_models/vgg16_weights.npz"
path_to_checkpoints = "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/model_weights/vgg16_dilation/"
path_to_best_checkpoint = "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/model_weights/vgg16_dilation_best/"
path_to_logs = "/ais/gobi4/namdar/soccer/data/cvpr/segmentation/tf_logs/vgg16_dilation/"
latest_checkpoint = "checkpoint-961"

train, val, _ = read_data_sets(rescale_factor=0.5)


# read the vgg weights



#tf.reset_default_graph()

# define placeholder for input and output
x_inp = tflearn.input_data(
    shape=[None, train.img_size[0], train.img_size[1], 3],
    name='input')

# placeholder for the groundtruth
y_true = tf.placeholder(tf.float32,
                        shape=(None, train.label_size[0], train.label_size[1]))

# get the forward pass of the model
x = vgg16_dilation(x_inp)

# reshape the
y_pred = tf.reshape(x, shape=(-1, num_classes))



# get a one-hot encoding for the ground truth images
y_true_hot = get_gt_one_hot_node(y_true)

# define the loss
loss = tflearn.softmax_categorical_crossentropy(y_pred, y_true_hot)

# define the optimizer
#optimizer_op = tf.train.RMSPropOptimizer(0.01)
optimizer_op = tf.train.RMSPropOptimizer(learning_rate=initital_learning_rate)



#IOU
IOU = iou_metric(y_pred, y_true_hot)

print("IOU Defined!")


train_op = tflearn.TrainOp(loss,
                           optimizer=optimizer_op,
                           metric= IOU,
                           batch_size=12)




trainer = tflearn.Trainer(train_ops=train_op,
                          checkpoint_path=path_to_checkpoints,
                          max_checkpoints=5,
                          keep_checkpoint_every_n_hours=0.5,
                          tensorboard_dir=path_to_logs)

print("Trainer Initialized!")

trainer.restore(path_to_checkpoints+latest_checkpoint)

trainer.fit(feed_dicts={x_inp: train.images, y_true: train.labels},
            val_feed_dicts={x_inp: val.images, y_true: val.labels},
            show_metric=True,
            n_epoch=num_epoch)



'''
trainer.save('./saved/epoch250')

ind = 10
ind = ind + 1
temp = trainer.session.run(x, feed_dict={x_inp: val.images[[ind]] })

temp_max = np.argmax(temp, axis=3)


plt.imshow(val.images[ind,:,:,:])
plt.figure()
#plt.imshow(temp[ind, :, :, chan])
plt.imshow(temp_max[0])
plt.colorbar()

print(temp.shape)



init = tf.initialize_all_variables()
#with tf.Session() as sess:
sess = tf.Session()
sess.run(init)

temp = sess.run(y_pred, feed_dict={x_inp: train.images[[0]] })
print(temp.shape)


temp1 = sess.run(y_true_reshaped, feed_dict={y_true: train.labels[[0]] })


temp2 = sess.run(y_true_hot, feed_dict={y_true: train.labels[[0]] })



init = tf.initialize_all_variables()
sess = tf.InteractiveSession()
sess.run(init)
temp = sess.run(x, feed_dict={x_inp: train.images[[0]]})


#plt.figure()
plt.imshow(train.images[0,:,:,:])
plt.imshow(train.labels[0,:,:])



plt.colorbar()


#return x

# define the loss function


# define the training
'''


