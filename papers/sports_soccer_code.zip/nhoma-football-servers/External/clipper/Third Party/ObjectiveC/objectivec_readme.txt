
An Objective C wrapper for Clipper by John Swensen (http://www.swengames.com/) can be downloaded from:

https://github.com/jpswensen/ClipperCocoa