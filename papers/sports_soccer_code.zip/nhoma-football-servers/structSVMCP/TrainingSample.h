/*  This file is part of Structured Prediction (SP) - http://www.alexander-schwing.de/
 *
 *  Structured Prediction (SP) is free software: you can
 *  redistribute it and/or modify it under the terms of the GNU General
 *  Public License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Structured Prediction (SP) is distributed in the hope
 *  that it will be useful, but WITHOUT ANY WARRANTY; without even the
 *  implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *  PURPOSE. See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Structured Prediction (SP).
 *  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Copyright (C) 2010-2013  Alexander G. Schwing  [http://www.alexander-schwing.de/]
 */

//Author: Alexander G. Schwing

/*  ON A PERSONAL NOTE: I spent a significant amount of time to go through
 *  both, theoretical justifications and coding of this framework.
 *  I hope the package is useful for your task. Any citations, requests, 
 *  feedback, donations and support would be greatly appreciated.
 *  Thank you for contacting me!
 */


// My Includes:
#ifdef __APPLE__
#include <armadillo>
#else
#include "/u/namdar/soccer/Code/External/armadillo-6.200.3/include/armadillo"
#include "/u/namdar/soccer/Code/BBInference/Potentials.hpp"
#include "/u/namdar/soccer/Code/BBInference/ImageFeat.cpp"
#endif



//////////////// 
struct SampleParams {
	std::string fn;
	
};

//////////////
struct TrainingDataParams {
	std::vector<struct SampleParams*> SampleData;
};



////////////////
class TrainingSample {
	struct SampleParams* sample;
	std::vector<int> labeling;
	// ground truth labels
	std::vector<int> gt;	
	// potential functions(features) assiciated with ground truth labels
	std::vector<double> phi_gt;
	ImageFeat m_img;
	Potentials m_pot = Potentials(); // potentials
	// tblr is a an 8-dim vector of T,B,L,R
	arma::vec m_tblr;
	// This will be used in the line potential. Might have to change it
	arma::vec verSign;

	arma::vec horSign;
	
    
public:
	TrainingSample() {};
	~TrainingSample() {};
	
	//
	int Load(struct SampleParams* sample) {
		
	//	std::cout << "Got Here" << std::endl;
		
		this->sample = sample;
		int numFeatures = 3;
        
		// the path to img without the extensions
		std::string imgInfo = sample->fn.substr(0,sample->fn.find_last_of("."));
		
		// get the image features associated with imgInfo
		m_img = ImageFeat(imgInfo);
		
		//assign gt and other required data
		arma::ivec gtTemp = m_img.GetYGT();
		gt = arma::conv_to< std::vector<int> >::from(gtTemp);
	//	std::cout << gt[3] << std::endl;	
		
	//	phi_gt.assign(numFeatures, 0.0);
		// 
		FeatureVector(gt, phi_gt);
		
        return numFeatures;
	}
	
	/*
	//
	int MarginRescaling(std::vector<double>& w, double time) {
		//compute margin rescaling and assign labeling
		
        return 0;
	}
	*/
	
	// This function, given a labeling updates the phi vector. Actually it
	// updates the memory location given by the pointer
	int FeatureVector(std::vector<int>& y, std::vector<double>& phi) {
		//compute feature vector phi from labeling y
		verSign.ones(7);
		horSign.ones(10);
		m_tblr = {(double)y[0], (double)y[0], (double)y[1], (double)y[1],
			(double)y[2], (double)y[2], (double)y[3], (double)y[3]};
		
		std::cout << m_tblr << std::endl;
		m_pot.SetGrass(m_img, m_tblr);
	//	m_pot.SetLines(m_img, m_tblr, verSign, horSign);
	//	m_pot.SetEllipsis(m_img, m_tblr);
		std::cout << "HERE" << std::endl;
	//	std::cout << sum(m_pot.GetVerLines()) << std::endl;
		        
		return 0;
	}
	
	/*
	//
	double Loss() {
		double loss = 0.0;
		//compute loss of labeling w.r.t. gt
		return loss;
	}
	
	//
	int AddFeatureDiffAndLoss(std::vector<double>& featureDiffAndLoss, std::vector<double>& w) {
		int numFeatures = int(featureDiffAndLoss.size())-1;
		std::vector<double> phi_y(numFeatures, 0.0);
		FeatureVector(labeling, phi_y);
		for(int k=0;k<numFeatures;++k) {
			featureDiffAndLoss[k] += phi_gt[k] - phi_y[k];
		}
		featureDiffAndLoss[numFeatures] += Loss();
		return 0;
	}
	*/
};